$Id: readme.txt,v 1.1 2003/09/15 12:49:36 dvojtise Exp $

Color editor for eclipse
This is my prefered one (Didier)
have a look and feel similar to eclipse java code
propose a html generation (usefull to create tutorials)
html generation available as a standalone console tool (usefull for improving the color template)

available here : http://colorer.sourceforge.net/
local copy for irisa members : /udd/triskell/Soft/eclipse/plugin/colorer