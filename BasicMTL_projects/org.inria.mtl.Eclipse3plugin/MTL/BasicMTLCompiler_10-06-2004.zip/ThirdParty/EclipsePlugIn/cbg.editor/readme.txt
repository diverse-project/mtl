$Id: readme.txt,v 1.1 2003/09/15 12:49:35 dvojtise Exp $
This a a syntax colorer editor for Eclipse.

use these files to have a support for mtl files 


Plugin available here : http://gstaff.org/colorEditor/
local copy for irisa members : /udd/triskell/Soft/eclipse/plugin/colorEditor