This directory defines the libraries that compose the kernel of BasicMTL
To determine if a library should go there, answer the question : can I do transformations whitout this library ?