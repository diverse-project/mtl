/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2000 Sun
 * Microsystems, Inc. All Rights Reserved.
 */

package org.openide.awt;

import javax.swing.JPopupMenu;
import javax.swing.SwingUtilities;
import java.awt.Component;
import java.awt.Point;

import org.openide.modules.Dependency;
import org.openide.modules.SpecificationVersion;

/** A subclass of JPopupMenu which ensures that the popup menus do
 * not stretch off the edges of the screen.
 *
 */
public class JPopupMenuPlus extends JPopupMenu {
    
    public JPopupMenuPlus() {
        //fix for issue 32633
        if (needHackUI()) {
            setUI(new NbPopupMenuUI());
        }
    }

    /*
     * Override the show() method to ensure that the popup will be
     * on the screen.
     */
    public void show(Component invoker, int x, int y) {
        if (isVisible()) return;

        // HACK[pnejedly]: Notify all the items in the menu we're going to show
        JInlineMenu.prepareItemsInContainer(this);
        // End of HACK

        Point p = new Point(x, y);
        SwingUtilities.convertPointToScreen (p, invoker);
        Point newPt = JPopupMenuUtils.getPopupMenuOrigin(this, p);
        SwingUtilities.convertPointFromScreen (newPt, invoker);
        super.show(invoker, newPt.x, newPt.y);
    }
    
    /** Determine if this is JDK 1.3, in which case the replacement UI class
     *  NbPopupMenuUI is needed to handle accessibility issues.  */
    static final boolean needHackUI () {
        //Testing for 1.4.1 rather than 1.4, since eliminating NbPopupMenuUI
        //has not been tested on 1.3
        return (Dependency.JAVA_SPEC.compareTo(
            new SpecificationVersion("1.4")) < 0); // NOI18N
    }
}
