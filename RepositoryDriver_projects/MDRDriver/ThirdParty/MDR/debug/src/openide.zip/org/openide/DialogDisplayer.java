/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2003 Sun
 * Microsystems, Inc. All Rights Reserved.
 */

package org.openide;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import javax.swing.*;

import org.openide.util.Lookup;

/** Permits dialogs to be displayed.
 * @author Jesse Glick
 * @since 3.14
 */
public abstract class DialogDisplayer {

    /** Get the default dialog displayer.
     * @return the default instance from lookup
     */
    public static DialogDisplayer getDefault() {
        DialogDisplayer dd = (DialogDisplayer)Lookup.getDefault().lookup(DialogDisplayer.class);
        if (dd == null) {
            dd = new Trivial();
        }
        return dd;
    }

    /** Subclass constructor. */
    protected DialogDisplayer() {}

    /** Notify the user of something in a message box, possibly with feedback.
     * <p>To support both GUI and non-GUI use, this method may be called
     * from any thread (providing you are not holding any locks), and
     * will block the caller's thread. In GUI mode, it will be run in the AWT
     * event thread automatically. If you wish to hold locks, or do not
     * need the result object immediately or at all, please make this call
     * asynchronously (e.g. from the request processor).
     * @param descriptor description of the notification
     * @return the option that caused the message box to be closed
     */
    public abstract Object notify(NotifyDescriptor descriptor);
    
    /** Get a new standard dialog.
     * The dialog is designed and created as specified in the parameter.
     * Anyone who wants a dialog with standard buttons and
     * standard behavior should use this method.
     * <p><strong>Do not cache</strong> the resulting dialog if it
     * is modal and try to reuse it! Always create a new dialog
     * using this method if you need to show a dialog again.
     * Otherwise previously closed windows can reappear.
     * @param descriptor general description of the dialog
     * @return the new dialog
     */
    public abstract Dialog createDialog(DialogDescriptor descriptor);
    
    /**
     * Minimal implementation suited for standalone usage.
     * @see "#30031"
     */
    private static final class Trivial extends DialogDisplayer {
        
        public Object notify(NotifyDescriptor nd) {
            JDialog dialog = new JDialog((Frame)null, nd.getTitle(), true);
            prep(dialog, nd, null, null);
            dialog.show();
            return nd.getValue() != null ? nd.getValue() : NotifyDescriptor.CLOSED_OPTION;
        }
        
        public Dialog createDialog(DialogDescriptor dd) {
            JDialog dialog = new JDialog((Frame)null, dd.getTitle(), dd.isModal());
            prep(dialog, dd, dd.getClosingOptions(), dd.getButtonListener());
            return dialog;
        }
        
        private static void prep(JDialog dialog, NotifyDescriptor nd, Object[] closingOptions, ActionListener buttonListener) {
            dialog.getContentPane().setLayout(new BorderLayout());
            dialog.getContentPane().add(message2Component(nd.getMessage()), BorderLayout.CENTER);
            dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
            JPanel buttonPanel = new JPanel();
            buttonPanel.setLayout(new FlowLayout());
            Object[] options = nd.getOptions();
            if (options == null) {
                switch (nd.getOptionType()) {
                case NotifyDescriptor.DEFAULT_OPTION:
                case NotifyDescriptor.OK_CANCEL_OPTION:
                    options = new Object[] {
                        NotifyDescriptor.OK_OPTION,
                        NotifyDescriptor.CANCEL_OPTION,
                    };
                    break;
                case NotifyDescriptor.YES_NO_OPTION:
                    options = new Object[] {
                        NotifyDescriptor.YES_OPTION,
                        NotifyDescriptor.NO_OPTION,
                    };
                    break;
                case NotifyDescriptor.YES_NO_CANCEL_OPTION:
                    options = new Object[] {
                        NotifyDescriptor.YES_OPTION,
                        NotifyDescriptor.NO_OPTION,
                        NotifyDescriptor.CANCEL_OPTION,
                    };
                    break;
                default:
                    throw new IllegalArgumentException();
                }
            }
            for (int i = 0; i < options.length; i++) {
                buttonPanel.add(option2Button(options[i], nd, makeListener(options[i], nd, closingOptions, dialog, buttonListener)));
            }
            options = nd.getAdditionalOptions();
            if (options != null) {
                for (int i = 0; i < options.length; i++) {
                    buttonPanel.add(option2Button(options[i], nd, makeListener(options[i], nd, closingOptions, dialog, buttonListener)));
                }
            }
            dialog.getContentPane().add(buttonPanel, BorderLayout.SOUTH);
            dialog.pack();
            dialog.setBounds(org.openide.util.Utilities.findCenterBounds(dialog.getSize()));
        }
        
        /**
         * Given a message object, create a displayable component from it.
         */
        private static Component message2Component(Object message) {
            if (message instanceof Component) {
                return (Component)message;
            } else if (message instanceof Object[]) {
                Object[] sub = (Object[])message;
                JPanel panel = new JPanel();
                panel.setLayout(new FlowLayout());
                for (int i = 0; i < sub.length; i++) {
                    panel.add(message2Component(sub[i]));
                }
                return panel;
            } else if (message instanceof Icon) {
                return new JLabel((Icon)message);
            } else {
                return new JLabel(message.toString());
            }
        }
        
        private static Component option2Button(Object option, NotifyDescriptor nd, ActionListener l) {
            if (option instanceof AbstractButton) {
                AbstractButton b = (AbstractButton)option;
                b.addActionListener(l);
                return b;
            } else if (option instanceof Component) {
                return (Component)option;
            } else if (option instanceof Icon) {
                return new JLabel((Icon)option);
            } else {
                String text;
                if (option == NotifyDescriptor.OK_OPTION) {
                    text = "OK"; // XXX I18N
                } else if (option == NotifyDescriptor.CANCEL_OPTION) {
                    text = "Cancel"; // XXX I18N
                } else if (option == NotifyDescriptor.YES_OPTION) {
                    text = "Yes"; // XXX I18N
                } else if (option == NotifyDescriptor.NO_OPTION) {
                    text = "No"; // XXX I18N
                } else if (option == NotifyDescriptor.CLOSED_OPTION) {
                    throw new IllegalArgumentException();
                } else {
                    text = option.toString();
                }
                JButton b = new JButton(text);
                b.addActionListener(l);
                return b;
            }
        }
        
        private static ActionListener makeListener(final Object option, final NotifyDescriptor nd, final Object[] closingOptions, final Dialog dialog, final ActionListener buttonListener) {
            return new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    if (buttonListener != null) {
                        buttonListener.actionPerformed(e);
                    } else {
                        nd.setValue(option);
                    }
                    if (closingOptions == null || Arrays.asList(closingOptions).contains(option)) {
                        dialog.setVisible(false);
                    }
                }
            };
        }
        
    }

}
