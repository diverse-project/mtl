/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrtoolkit.looks.reflect;


import org.netbeans.modules.mdrtoolkit.looks.reflect.*;
import org.netbeans.modules.mdrtoolkit.looks.reflect.actions.*;
import java.util.*;
import java.awt.*;
import javax.jmi.reflect.*;
import javax.jmi.model.*;

import org.openide.util.actions.SystemAction;
import org.openide.util.SharedClassObject;

import org.openidex.nodes.looks.*;
/**
 *
 * @author  ms118741
 * @version 
 */
public class RefGetValueWrapperLook extends AcceptorLook.Type {

    /** Creates new RefObjectLook */
    public RefGetValueWrapperLook() {
        super( new Delegate(), RefGetValueWrapper.class, true );
    }

    public String toString() {
        return "MOF/RefGetValueWrapper::ALL"; // NOI18N
    }

    private static class Delegate extends BaseObjectLook {
    
        public String getName( Look.NodeSubstitute substitute ) {
            return Utils.getRefObjectName( ((RefGetValueWrapper)substitute.getRepresentedObject()).getMetaFeature() );
        }

        public Object[] getChildObjects( Look.NodeSubstitute substitute ) {
            ArrayList result = new ArrayList();
            Object value =  ((RefGetValueWrapper)substitute.getRepresentedObject()).getFeatured().refGetValue( 
                            (StructuralFeature) ((RefGetValueWrapper)substitute.getRepresentedObject()).getMetaFeature() );
            Object collectionValue = null;
            if (value instanceof Collection) {
                for (Iterator itValue = ((Collection)value).iterator(); itValue.hasNext(); ) {
                    collectionValue = itValue.next();
                    if ((!result.contains( collectionValue )) && (collectionValue != null)) {
                        result.add( collectionValue );
                    }
                }
            } else {
                if ( (!result.contains( value )) && (value != null) ) {
                    result.add( value );
                }
            }
            return result.toArray();
        }
    }
}
