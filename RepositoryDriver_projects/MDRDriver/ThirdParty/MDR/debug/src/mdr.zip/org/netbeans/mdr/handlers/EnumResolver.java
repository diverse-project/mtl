/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.mdr.handlers;

import java.util.*;
import java.lang.reflect.*;
import java.io.*;

import javax.jmi.model.Classifier;
import javax.jmi.model.EnumerationType;
import javax.jmi.model.TypedElement;
import javax.jmi.reflect.*;

import org.netbeans.mdr.util.*;
import org.netbeans.mdr.persistence.StorageException;
import org.netbeans.mdr.storagemodel.*;

/**
 *
 * @author  mmatula
 * @version 
 */
public final class EnumResolver  {
    private static final String ENUMIMPL_SUFFIX = "Enum";
    private static final Hashtable enumCache = new Hashtable(50);

    // resolves enum. class based on the enum interface
    private static Class getEnumClass(Class ifc) throws IllegalArgumentException {
        try {
            String rawName = ifc.getName() + ENUMIMPL_SUFFIX;
            return BaseObjectHandler.resolveInterface(rawName);
        } catch (ClassNotFoundException ex) {
            throw new IllegalArgumentException("Invalid inteface: " + ifc);
        }
    }
    
    /** Returns a correct instance of an enumeration class representing the requested literal
     * @param ifcName Name of JMI interface generated for the enumeration.
     * @param label Name of the requested literal.
     * @return Instance of an enumeration class representing the literal.
     */
    public static synchronized RefEnum resolveEnum(String ifcName, String label) {
        String enumKey = label + ":" + ifcName;
        RefEnum enum = (RefEnum) enumCache.get(enumKey);
        
        if (enum == null) {
            try {
                Class cl = BaseObjectHandler.resolveInterface(ifcName + ENUMIMPL_SUFFIX);
                Field f = cl.getField(org.netbeans.mdr.handlers.gen.TagSupport.mapEnumLiteral(label));
                enum = (RefEnum) f.get(null);
                enumCache.put(enumKey, enum);
            } catch (NoSuchFieldException e) {
                throw new InvalidNameException(label, "Invalid literal name '" + label + "' for enumeration " + ifcName);
            } catch (Exception e) {
                throw (DebugException) Logger.getDefault().annotate(new DebugException(), e);
            }
        }
        
        return enum;
    }
    
}
