/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.mdr.storagemodel;

import java.util.*;
import java.lang.reflect.Array;

import org.netbeans.mdr.util.DebugException;
import org.netbeans.mdr.persistence.StorageException;
import org.netbeans.mdr.util.Logger;

/**
 * Read-only collection. Wraps an inner collection all entries of which are
 * MOF IDs. The accessor methods of this collection return the objects from
 * storage instead of their IDs.
 *
 * @author  mm109185
 */
class CachedCollection implements Collection {
    private final Collection innerCollection;
    private final MdrStorage storage;
    
    /** Creates a new CachedCollection.
     *
     * @param storage the storage to resolve MOF IDs
     * @param innerCollection the collection of MOF IDs
     */
    public CachedCollection(MdrStorage storage, Collection innerCollection) {
        this.innerCollection = innerCollection;
        this.storage = storage;
    }

    public boolean retainAll(Collection collection) {
        throw new UnsupportedOperationException();
    }

    public boolean contains(Object obj) {
        return innerCollection.contains(obj);
    }

    public Object[] toArray(Object[] obj) {
        Object[] value = toArray();
        Object[] result = obj;
        if (value.length > result.length) {
            if (value.getClass() == result.getClass()) {
                return value;
            } else {
                result = (Object[]) Array.newInstance(obj.getClass(), value.length);
            }
        }
        for (int i = 0; i < result.length; i++) {
            result[i] = (i < value.length) ? value[i] : null;
        }
        return result;
    }

    public Iterator iterator() {
        return new CachedIterator(innerCollection.iterator());
    }

    public boolean removeAll(Collection collection) {
        throw new UnsupportedOperationException();
    }

    public Object[] toArray() {
        Object[] array = innerCollection.toArray();

        try {
            for (int i = 0; i < array.length; i++) {
                array[i] = storage.getObject((org.netbeans.mdr.persistence.MOFID) array[i]);
            }
        } catch (Exception e) {
            throw (DebugException) Logger.getDefault().annotate(new DebugException(), e);
        }

        return array;
    }

    public boolean remove(Object obj) {
        throw new UnsupportedOperationException();
    }

    public void clear() {
        throw new UnsupportedOperationException();
    }

    public boolean addAll(Collection collection) {
        throw new UnsupportedOperationException();
    }

    public int size() {
        return innerCollection.size();
    }

    public boolean containsAll(Collection collection) {
        return innerCollection.containsAll(collection);
    }

    public boolean add(Object obj) {
        throw new UnsupportedOperationException();
    }

    public boolean isEmpty() {
        return innerCollection.isEmpty();
    }
    
    private class CachedIterator implements Iterator {
        private final Iterator innerIterator;
        
        private CachedIterator(Iterator innerIterator) {
            this.innerIterator = innerIterator;
        }
        
        public boolean hasNext() {
            return innerIterator.hasNext();
        }

        public Object next() {
            try {
                return storage.getObject((org.netbeans.mdr.persistence.MOFID) innerIterator.next());
            } catch (StorageException e) {
                throw (DebugException) Logger.getDefault().annotate(new DebugException(), e);
            }
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }
    }
}
