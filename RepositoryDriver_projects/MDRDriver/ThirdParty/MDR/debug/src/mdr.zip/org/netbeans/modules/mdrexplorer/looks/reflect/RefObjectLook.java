/*
 *                 Sun Public License Notice
 *
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 *
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrexplorer.looks.reflect;

import org.netbeans.modules.mdrexplorer.looks.reflect.properties.*;
import org.netbeans.modules.mdrexplorer.looks.reflect.actions.*;
import java.util.*;
import javax.jmi.reflect.*;
import javax.jmi.model.*;
import org.openide.util.actions.SystemAction;
import org.netbeans.api.looks.*;
import org.netbeans.spi.looks.*;
import org.openide.nodes.*;

/**
 *
 * @author  ms118741, Tomas Zezula
 * @version
 */
public class RefObjectLook extends BaseObjectLook {
    
    /** Creates new RefObjectLook */
    public RefObjectLook() {
        super(Utils.getLocalizedString("TXT_RefObjectLook"));
    }
    
    public String toString() {
        return "MOF/RefObject::ALL"; // NOI18N
    }
    
    
    public String getName( Look.NodeSubstitute substitute ) {
        return Utils.getRefObjectName(substitute) + " [" + Utils.getRefObjectMetaName(substitute) + "]";
    }
    
    public String getDisplayName(Look.NodeSubstitute substitute) {
        return this.getName(substitute);
    }
    
    public Object[] getChildObjects( Look.NodeSubstitute substitute ) {
        int count = this.getBrowserChildCount();
        Collection c = Utils.getRefObjectChildObjects( substitute, count);
        return c.toArray();
    }
    
    public javax.swing.Action[] getActions( Look.NodeSubstitute substitute ) {
        javax.swing.Action[] superActions = super.getActions(substitute);
        if (superActions == null) {
            superActions = new javax.swing.Action[0];
        }
        javax.swing.Action[] actions = new javax.swing.Action[superActions.length + 3];
        actions[0] = SystemAction.get( DeleteObjectAction.class);
        actions[1] = SystemAction.get(SaveXMIAction.class);
        actions[2] = SystemAction.get(Map2JavaAction.class);
        System.arraycopy(superActions, 0, actions, 3, superActions.length);
        return actions;
    }
    
    public Node.PropertySet[] getPropertySets( Look.NodeSubstitute substitute ) {
        return RefObjectProps.getPropertySets( (RefObject)substitute.getRepresentedObject() );
    }
}
