/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrtoolkit.looks.reflect;

import org.netbeans.modules.mdrtoolkit.looks.reflect.properties.*;

import java.util.*;
import java.awt.*;
import javax.jmi.reflect.*;
import javax.jmi.model.*;

import org.openide.util.actions.SystemAction;
import org.openide.util.SharedClassObject;

import org.openidex.nodes.looks.*;
import org.openidex.nodes.looks.*;
import org.openide.nodes.*;

/**
 *
 * @author  ms118741
 * @version 
 */
public class Utils {

    private static final String META = "META_";
    private static final String NAME = "name";
    private static final String NAME_SEPARATOR = ".";
    private static final String NO_VALUE = "NoValue";

    /** Creates new Utils */
    public Utils() {
    }

    public static String getRefObjectName(Look.NodeSubstitute substitute) {
        return getRefObjectName( (RefObject)substitute.getRepresentedObject() );
    }
    public static String getRefObjectName(RefObject refObject) {
            String result = null;

            RefObject metaObject = refObject.refClass().refMetaObject();
            try {
                RefObject attribute = ((MofClass)metaObject).lookupElementExtended( NAME );
                if (attribute instanceof Attribute) {
                    Object value = ((RefFeatured)refObject).refGetValue( (StructuralFeature) attribute );
                    result = (value == null) ? NO_VALUE : value.toString();
                }
            } catch (NameNotFoundException e) {
                if (result == null) {
                    result = META + ((MofClass)refObject.refMetaObject()).getName();
                }
            }
            return result;
    }
    
    public static String getRefObjectMetaName(Look.NodeSubstitute substitute) {
        RefObject object = (RefObject) substitute.getRepresentedObject();
        
        return resolveFullyQualifiedName(((ModelElement) object.refMetaObject()).getQualifiedName());
    }

    public static java.util.List getRefObjectChildObjects(Look.NodeSubstitute substitute) {
        return getRefObjectChildObjects( (RefObject)substitute.getRepresentedObject() );
    }
    public static java.util.List getRefObjectChildObjects(RefObject refObject) {
        return getAllReferenceWrappers(refObject);
    }

    public static java.util.List getAllAttributeWrappers(RefObject refObject) {
        return getAllFeaturedWrappers(refObject, true);
    }

    public static java.util.List getAllReferenceWrappers(RefObject refObject) {
        return getAllFeaturedWrappers(refObject, false);
    }
    public static java.util.List getAllFeaturedWrappers(RefObject refObject, boolean attributes) {
        ArrayList result = new ArrayList();
        RefObject metaObject = refObject.refMetaObject();
        if (metaObject instanceof GeneralizableElement) {
            java.util.List superTypes = ((GeneralizableElement)metaObject).allSupertypes();
            RefObject superType = null;
            for (Iterator it = superTypes.iterator(); it.hasNext(); ) {
                superType = (RefObject)it.next();
                if (attributes) {
                    result.addAll( getAllAttributes( superType, (RefFeatured)refObject ) );
                } else {
                    result.addAll( getAllReferences( superType, (RefFeatured)refObject ) );
                }
            }
            if (attributes) {
                result.addAll( getAllAttributes( metaObject , (RefFeatured)refObject ) );
            } else {
                result.addAll( getAllReferences( metaObject , (RefFeatured)refObject ) );
            }
        }
        return result;
    }

    public static String resolveFullyQualifiedName(java.util.List fullyQualifiedName) {
        String result = "";
        if (fullyQualifiedName != null) {
            for (Iterator it = fullyQualifiedName.iterator(); it.hasNext(); ) {
                result += it.next();
                if (it.hasNext()) {
                    result += NAME_SEPARATOR;
                }
            }
        }
        return result;
    }

    public static Node.PropertySet[] getAssocLinkEndPropertySets(RefBaseObject assocEnd, Look.NodeSubstitute substitute) {
        Node.PropertySet[] featuredProps = Look.NO_PROPERTY_SETS;
        Node.PropertySet[] refObjectProps = Look.NO_PROPERTY_SETS;
        Node.PropertySet[] refBaseObjectProps = Look.NO_PROPERTY_SETS;

        if (assocEnd instanceof RefFeatured) {
            featuredProps = RefFeaturedProps.getPropertySets( (RefFeatured)assocEnd, substitute );
        }
        if (assocEnd instanceof RefObject) {
            refObjectProps = RefObjectProps.getPropertySets( (RefObject)assocEnd );
        }
        if (assocEnd instanceof RefBaseObject) {
            refBaseObjectProps = RefBaseObjectProps.getPropertySets( assocEnd );
        }

        Node.PropertySet[] result = new Node.PropertySet[featuredProps.length + refObjectProps.length + refBaseObjectProps.length];
        System.arraycopy(featuredProps, 0, result, 0, featuredProps.length);
        System.arraycopy(refObjectProps, 0, result, featuredProps.length, refObjectProps.length);
        System.arraycopy(refBaseObjectProps, 0, result, refObjectProps.length + featuredProps.length, refBaseObjectProps.length);
        return result;
    }
    // * * * * * * * *     P R I V A T E    M E T H O D S        * * * * * * * *
    // * * * * * * * *     P R I V A T E    M E T H O D S        * * * * * * * *
    // * * * * * * * *     P R I V A T E    M E T H O D S        * * * * * * * *

    private static Collection getAllReferences(RefObject superType, RefFeatured featured) {
        return getAllFeatures(superType, featured, false);
    }
    private static Collection getAllAttributes(RefObject superType, RefFeatured featured) {
        return getAllFeatures(superType, featured, true);
    }
    private static Collection getAllFeatures(RefObject superType, RefFeatured featured, boolean attributes) {
        ArrayList result = new ArrayList();
        RefObject containedObject = null;
        Object value = null;
        Object collectionValue = null;
        Collection contents = null;
        if ( superType instanceof Namespace ) {
            contents = ((Namespace)superType).getContents();
            for (Iterator itContents = contents.iterator(); itContents.hasNext(); ) {
                containedObject = (RefObject)itContents.next();
                if (attributes) {
                    if (containedObject instanceof Attribute) {
                        result.add( new RefGetValueWrapper( featured, containedObject ) );
                    }
                } else {
                    if (containedObject instanceof Reference) {
                        result.add( new RefGetValueWrapper( featured, containedObject ) );
                    }
                }
            }
        }
        return result;
    }


}
