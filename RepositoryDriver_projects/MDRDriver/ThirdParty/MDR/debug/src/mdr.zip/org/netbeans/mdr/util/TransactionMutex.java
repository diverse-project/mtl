/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.mdr.util;

import java.util.HashMap;
import org.netbeans.api.mdr.events.TransactionEvent;
import org.netbeans.mdr.NBMDRepositoryImpl;
import org.netbeans.mdr.storagemodel.MdrStorage;
import org.netbeans.mdr.persistence.StorageException;

/** This class implements mutex that controls storage transactions as well as 
 * MDR events firing.
 *
 * @author  Martin Matula
 * @version 0.1
 */
public class TransactionMutex {

    /* -------------------------------------------------------------------- */
    /* -- Private attributes ---------------------------------------------- */
    /* -------------------------------------------------------------------- */

    /**  The single writer thread or <code>null</code>. */
    private Thread writer = null;
    
    /** Counter of locks in the single writer thread. */
    private volatile int counter = 0;
    
    /** Maps reader threads to the counter of read locks acquired by them, i.e.
     *  to the counter of nested read transactions currently in process in
     *  the reader thread.
     *
     *  <p>Used to check if a write transaction is nested within a read
     *     transaction.
     */
    private final HashMap readers = new HashMap(10);
    
    /** transaction status */
    private volatile boolean fail = false;
    
    // storage
    private final MdrStorage storage;
    
    // events notifier
    private final EventNotifier notifier;

    // the repository (used as event source for transaction events)
    private final NBMDRepositoryImpl repository;
    
    /* -------------------------------------------------------------------- */
    /* -- Constructor (public) -------------------------------------------- */
    /* -------------------------------------------------------------------- */

    /** Creates new TransactionMutex */
    public TransactionMutex(MdrStorage storage, EventNotifier notifier, NBMDRepositoryImpl repository) {
        this.storage = storage;
        this.notifier = notifier;
        this.repository = repository;
    }

    /* -------------------------------------------------------------------- */
    /* -- Getters (public) ------------------------------------------------ */
    /* -------------------------------------------------------------------- */
    
    public boolean willFail() {
        return fail;
    }
    
    /**
     * Returns <code>true</code> if there is a write transaction going on.
     */
    public boolean pendingChanges() {
        return counter > 0;
    }
 
    /* -------------------------------------------------------------------- */
    /* -- transaction lock methods ---------------------------------------- */
    /* -------------------------------------------------------------------- */
     
    /**
     *  Enters a new transaction. If an existing lock hinders the transaction
     *  from being started, the method waits on the current object until the
     *  lock is removed.
     *
     *  @param writeAccess if <code>true</code>, a write transaction is entered,
     *          otherwise a read transaction
     *  @exception DebugException if a writable lock is requested
     *              in a read-only lock
     */
    public synchronized void enter(boolean writeAccess) {
//        Logger.getDefault().notify(Logger.INFORMATIONAL, new DebugException("enter: " + writeAccess));
        Thread thread = Thread.currentThread();
        int size;
        while ((counter > 0 && writer != thread) ||
               (writeAccess && !readers.isEmpty())) {
//               (writeAccess && (((size = readers.size()) > 1) ||
//               (size == 1 && readers.get(thread) == null)))) {
                   
            // reader cannot enter a write transaction as it would not be possible to
            // prevent deadlocks (when two readers decide to enter write, they would
            // lock each other)
            if (readers.get(thread) != null) throw new DebugException("Writable lock nested in read-only lock.");
            try {
                this.wait();
            } catch (InterruptedException e) {
                Logger.getDefault().notify(Logger.INFORMATIONAL, e);
            }               
        }
        
        if (writeAccess || counter > 0) {
            if ( counter == 0 ) {
                writer = thread;
                TransactionEvent event = new TransactionEvent(
                    repository,
                    TransactionEvent.EVENT_TRANSACTION_START
                );
                notifier.REPOSITORY.firePlannedChange(storage, event);
            }
            counter++;
        } else {
            Counter rCount = (Counter) readers.get(thread);
            if (rCount == null) {
                readers.put(thread, new Counter());
            } else {
                rCount.inc();
            }
        }
    }
    
    /**
     * Leave a transaction. Equivalent to {@link #leave(boolean) leave(false)}.
     */
    public synchronized void leave() {
        leave(false);
    }
    
    /**
     * Leave a transaction. If an outermost (i.e. not nested) write 
     * transaction is left, the listeners are informed and the transaction
     * is committed resp. rolled back. Finally all waiting threads are
     * notified.
     *
     * @param fail  <code>false</code> indicates transaction
     *           success, <code>true</code> its failure. Failure is allowed
     *           only if the outermost transaction is a write transaction.
     * @exception DebugException if a transaction shall be left which was
     *              not entered or if failure was indicated in read mode
     */
    public synchronized void leave(boolean fail) {
//        Logger.getDefault().notify(Logger.INFORMATIONAL, new DebugException("leave: " + fail));
        try {
            if (counter > 0) {
                this.fail |= fail;
                if ((--counter) == 0) {
                    // left the last write lock -> commit/rollback and send events
                    try {
                        TransactionEvent event = new TransactionEvent(
                            repository,
                            TransactionEvent.EVENT_TRANSACTION_END
                        );
                        notifier.REPOSITORY.firePlannedChange(storage, event);
                        if (this.fail) {
                            notifier.fireCancelled();
                            storage.rollback();
//                            Logger.getDefault().notify(Logger.INFORMATIONAL, new DebugException("rollback"));
                        } else {
                            notifier.fireChanged();
                            storage.commit();
                            //Logger.getDefault().log("commited");
//                            Logger.getDefault().notify(Logger.INFORMATIONAL, new DebugException("commit"));
                        }
                    } catch (StorageException e) {
                        try { 
                            Logger.getDefault().notify(Logger.INFORMATIONAL, e);
                            storage.rollback();
                        } catch (StorageException fatal) {
                            throw new DebugException("Fatal I/O error: " + fatal.toString());
                        }
                    } finally {
                        writer = null;
                        this.fail = false;
                    }
                }
            } else {
                Thread thread = Thread.currentThread();
                Counter rCount = (Counter) readers.get(thread);
                if (rCount == null) {
                    throw new DebugException("Error: leave() without enter().");
                } else {
                    if (rCount.dec() == 0) {
                        readers.remove(thread);
                    }
                }
                if (fail) throw new DebugException("Cannot fail when in read mode.");
            }
        } finally {
            this.notifyAll();
        }
    }
    
    /* -------------------------------------------------------------------- */
    /* -- TransactionMutex.Counter (private inner class) ------------------ */
    /* -------------------------------------------------------------------- */
    
    /**
     * Instances <code>Counter</code> are integers with {@link #dec() decrement}
     * and {@link #inc() increment} methods.
     */
    private static class Counter {
        private int value = 1;
        
        /**
         *  Creates a new counter, initializing it to <code>1</code>.
         */
        public Counter() {
        }
        
        /**
         * Returns the counter value.
         */
        public int intValue() {
            return value;
        }
        
        /**
         * Decrements the counter by <code>1</code>
         *
         * @return the new counter value
         * @exception Exception if the minimal counter value, namely
         *     <code>0</code>, was already reached
         */
        public int dec() {
            if (value <= 0) throw new DebugException("Couter underflow: " + value);
            return (--value);
        }
        
        /**
         * Increments the counter by <code>1</code>.
         *
         * @return the new counter value
         */
        public int inc() {
            return (++value);
        }
    }
}
