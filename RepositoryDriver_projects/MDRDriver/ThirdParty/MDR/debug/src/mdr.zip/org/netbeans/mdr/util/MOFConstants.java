/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.mdr.util;

/**
 * Constants from the MOF model.
 *
 * @author  mmatula
 * @version 
 */
public interface MOFConstants {
    public static final String MODEL = "Model";
    public static final String MODEL_ASSOCIATION_END = "Model.AssociationEnd";
    public static final String MODEL_ATTRIBUTE = "Model.Attribute";
    public static final String MODEL_REFERENCE = "Model.Reference";
    public static final String MODEL_OPERATION = "Model.Operation";

    public static final String SH_MODEL_NAMESPACE_CONTENTS = "contents";
    public static final String SH_MODEL_GENERALIZABLE_ELEMENT_SUPERTYPES = "supertypes";
    public static final String SH_MODEL_GENERALIZABLE_ELEMENT_VISIBILITY = "visibility";
    public static final String SH_MODEL_GENERALIZABLE_ELEMENT_IS_ABSTRACT = "isAbstract";
    public static final String SH_MODEL_GENERALIZES_SUPERTYPE = "supertype";
    public static final String SH_MODEL_REFERS_TO_REFERENCED_END = "referencedEnd";
    public static final String SH_MODEL_CONTAINS_CONTAINER = "container";
    public static final String SH_MODEL_IS_OF_TYPE_TYPE = "type";
    public static final String SH_MODEL_MODEL_ELEMENT_NAME = "name";
    public static final String SH_MODEL_MODEL_ELEMENT_CONTAINER = "container";
    public static final String SH_MODEL_TYPED_ELEMENT_TYPE = "type";
    public static final String SH_MODEL_ATTRIBUTE_IS_DERIVED = "isDerived";
    public static final String SH_MODEL_IMPORT_IS_CLUSTERED = "isClustered";
    public static final String SH_MODEL_IMPORT_IMPORTED_NAMESPACE = "importedNamespace";
    public static final String SH_MODEL_STRUCTURAL_FEATURE_MULTIPLICITY = "multiplicity";

    public static final String SH_MODEL_ATTRIBUTE = "Attribute";
    public static final String SH_MODEL_REFERENCE = "Reference";
    public static final String SH_MODEL_OPERATION = "Operation";
    public static final String SH_MODEL_PARAMETER = "Parameter";
    public static final String SH_MODEL_PARAMETER_DIRECTION_KIND = "direction";
    public static final String SH_MODEL_MULTIPLICITY_TYPE_UPPER = "upper";
    public static final String SH_MODEL_MULTIPLICITY_TYPE_IS_ORDERED = "isOrdered";
    public static final String SH_MODEL_MULTIPLICITY_TYPE_IS_UNIQUE = "isUnique";
    public static final String SH_MODEL_MULTIPLICITY_TYPE_LOWER = "lower";
    public static final String SH_MODEL_STRUCTURAL_FEATURE_IS_CHANGEABLE = "isChangeable";
    public static final String SH_MODEL_FEATURE_SCOPE = "scope";
    public static final String SH_MODEL_CLASS = "Class";
    public static final String SH_MODEL_ASSOCIATION = "Association";
    public static final String SH_MODEL_CONSTANT = "Constant";
    public static final String SH_MODEL_EXCEPTION = "Exception";
    public static final String SH_MODEL_ASSOCIATION_IS_DERIVED = "isDerived";
    public static final String SH_MODEL_PACKAGE = "Package";
    public static final String SH_MODEL_ENUMERATION_TYPE = "EnumerationType";
    public static final String SH_MODEL_STRUCTURE_TYPE = "StructureType";
    public static final String SH_MODEL_STRUCTURE_FIELD = "StructureField";
    public static final String SH_MODEL_COLLECTION_TYPE = "CollectionType";
    public static final String SH_MODEL_ALIAS_TYPE = "AliasType";
    public static final String SH_MODEL_PRIMITIVE_TYPE = "PrimitiveType";
    public static final String SH_MODEL_ASSOCIATION_END = "AssociationEnd";
    public static final String SH_MODEL_ASSOCIATION_END_IS_NAVIGABLE = "isNavigable";
    public static final String SH_MODEL_ASSOCIATION_END_IS_CHANGEABLE = "isChangeable";
    public static final String SH_MODEL_ASSOCIATION_END_MULTIPLICITY = "multiplicity";
    public static final String SH_MODEL_OPERATION_EXCEPTIONS = "exceptions";
    public static final String SH_MODEL_IMPORT = "Import";
    public static final String SH_MODEL_ATTACHES_TO = "AttachesTo";
//    public static final String SH_MODEL_ATTACHES_TO_TAG = "tag";
    public static final String SH_MODEL_ATTACHES_TO_MODEL_ELEMENT = "modelElement";
    public static final String SH_MODEL_TAG_TAG_ID = "tagId";
    public static final String SH_MODEL_TAG_VALUES = "values";

    public static final String MODEL_FEATURE_SCOPE = "Model.Feature.scope";
    public static final String MODEL_CONTAINS = "Model.Contains";
    public static final String MODEL_MODEL_ELEMENT_NAME = "Model.ModelElement.name";
    public static final String MODEL_ATTRIBUTE_IS_DERIVED = "Model.Attribute.isDerived";
    public static final String MODEL_ASSOCIATION_END_MULTIPLICITY = "Model.AssociationEnd.multiplicity";
    public static final String MODEL_STRUCTURAL_FEATURE_MULTIPLICITY = "Model.StructuralFeature.multiplicity";
    public static final String MODEL_MULTIPLICITY_TYPE_UPPER = "Model.MultiplicityType.upper";
    public static final String MODEL_MULTIPLICITY_TYPE_IS_ORDERED = "Model.MultiplicityType.isOrdered";
    public static final String MODEL_MULTIPLICITY_TYPE_IS_UNIQUE = "Model.MultiplicityType.isUnique";
    public static final String MODEL_MULTIPLICITY_TYPE_LOWER = "Model.MultiplicityType.lower";
    public static final String MODEL_GENERALIZABLE_ELEMENT_IS_ABSTRACT = "Model.GeneralizableElement.isAbstract";
    public static final String MODEL_CLASS_IS_SINGLETON = "Model.Class.isSingleton";
    public static final String MODEL_GENERALIZABLE_ELEMENT_SUPERTYPES = "Model.GeneralizableElement.supertypes";
    public static final String MODEL_CLASS = "Model.Class";
    public static final String MODEL_ASSOCIATION = "Model.Association";
    public static final String MODEL_NAMESPACE_CONTENTS = "Model.Namespace.contents";
    public static final String MODEL_ASSOCIATION_END_AGGREGATION = "Model.AssociationEnd.aggregation";
    public static final String MODEL_MULTIPLICITY_TYPE = "Model.MultiplicityType";
    public static final String MODEL_PACKAGE = "Model.Package";
    public static final String MODEL_TYPED_ELEMENT_TYPE = "Model.TypedElement.type";
    public static final String MODEL_REFERENCE_REFERENCED_END = "Model.Reference.referencedEnd";
    public static final String MODEL_ALIAS_TYPE = "Model.AliasType";
    public static final String MODEL_ENUMERATION_TYPE = "Model.EnumerationType";
    public static final String MODEL_STRUCTURE_TYPE = "Model.StructureType";
    public static final String MODEL_STRUCTURE_FIELD = "Model.StructureField";
    public static final String MODEL_PRIMITIVE_TYPE = "Model.PrimitiveType";
    public static final String MODEL_COLLECTION_TYPE = "Model.CollectionType";
    public static final String DATATYPES = "PrimitiveTypes";
    public static final String DATATYPES_BOOLEAN = "PrimitiveTypes.Boolean";
    public static final String DATATYPES_BYTE = "PrimitiveTypes.Byte";
    public static final String DATATYPES_CHARACTER = "PrimitiveTypes.Character";
    public static final String DATATYPES_DOUBLE = "PrimitiveTypes.Double";
    public static final String DATATYPES_FLOAT = "PrimitiveTypes.Float";
    public static final String DATATYPES_INTEGER = "PrimitiveTypes.Integer";
    public static final String DATATYPES_LONG = "PrimitiveTypes.Long";
    public static final String DATATYPES_OBJECT = "PrimitiveTypes.Object";
    public static final String DATATYPES_SHORT = "PrimitiveTypes.Short";
    public static final String DATATYPES_STRING = "PrimitiveTypes.String";
    
    public static final String SCOPE_CLASSIFIER = "classifier_level";
    public static final String SCOPE_INSTANCE = "instance_level";
}

