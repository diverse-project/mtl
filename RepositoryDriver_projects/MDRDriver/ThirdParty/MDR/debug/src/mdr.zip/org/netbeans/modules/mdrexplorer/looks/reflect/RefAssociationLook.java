/*
 *                 Sun Public License Notice
 *
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 *
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrexplorer.looks.reflect;

import org.netbeans.modules.mdrexplorer.looks.reflect.actions.*;
import java.util.Collection;
import javax.jmi.reflect.*;
import javax.jmi.model.Association;
import java.util.*;
import org.netbeans.api.mdr.MDRObject;
import org.netbeans.api.mdr.MDRepository;
import org.netbeans.api.looks.*;
import org.netbeans.modules.mdrexplorer.looks.DataRestWrapper;
/** Implements MOF models defaut view.
 *
 * @author  Petr Hrebejk, Tomas Zezula
 */
public class RefAssociationLook extends BaseObjectLook {
    
    /** Creates new PackageProxy
     */
    public RefAssociationLook() {
        super(Utils.getLocalizedString("TXT_RefAssociationLook"));
    }
    
    public String toString() {
        return "MOF/AssociationProxy::ALL"; // NOI18N
    }
    
    
    public String getName( Look.NodeSubstitute substitute ) {
        RefAssociation ra = (RefAssociation)substitute.getRepresentedObject();
        return ((Association)ra.refMetaObject()).getName();
    }
    
    public String getDisplayName(Look.NodeSubstitute substitute) {
        return this.getName(substitute);
    }
    
    /** Returns child objects for association, the wrappers for
     *  first and second end of association.
     *  The implementation does not use children count limitiation
     *  because the children count is always two, and they are logically
     *  coupled and should be displayed tgether.
     */
    public Object[] getChildObjects( Look.NodeSubstitute substitute ) {
        ArrayList result = new ArrayList();
        RefAssociation refAssoc = (RefAssociation)substitute.getRepresentedObject();
        MDRepository rep = ((MDRObject)refAssoc).repository();
        rep.beginTrans(false);
        try {
            Association assoc = (Association)refAssoc.refMetaObject();
            List contents = assoc.getContents();
            javax.jmi.model.AssociationEnd assocEnd = null;
            for (Iterator it = contents.iterator(); it.hasNext(); ) {
                Object content = it.next();
                if (content instanceof javax.jmi.model.AssociationEnd) {
                    assocEnd = (javax.jmi.model.AssociationEnd) content;
                    result.add( new RefAssocWrapper( assocEnd, assoc, refAssoc, it.hasNext() ) );
                }
            }
            Object[] resultObjects = result.toArray();
            return resultObjects;
        } finally {
            rep.endTrans();
        }
    }
    
}
