/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrtoolkit.looks.reflect.properties;


import java.util.*;
import java.util.Iterator;
import java.util.ResourceBundle;
import java.beans.PropertyEditor;
import java.beans.PropertyEditorSupport;

import org.openide.nodes.*;
import org.openide.util.NbBundle;
import org.openide.util.actions.SystemAction;
import org.openide.util.Lookup;
import org.openidex.nodes.looks.*;

import org.openide.explorer.*;
import org.openide.explorer.view.*;

public class LookPropertySupport {

    public static final String NO_VALUE = "No value";

    public static List getPropertySets(ReadWritePropertyIntf rwp) {
        ArrayList result = new ArrayList();

        Sheet.Set sheetSet = new Sheet.Set();
        sheetSet.setName( rwp.getSheetName() );
        sheetSet.setDisplayName( rwp.getSheetName() );
        sheetSet.put( new LookNodeProperty( rwp ) ); 

        result.add( sheetSet );
        return result;
    }
    
    public static PropertySupport getProperties(ReadWritePropertyIntf rwp) {
        return new LookNodeProperty( rwp );
    }
    
    // ************************ I N N E R    C L A S S E S ********************************
    
    private static class LookNodeProperty extends PropertySupport.ReadWrite {

        private ReadWritePropertyIntf rwp = null;

        LookNodeProperty(ReadWritePropertyIntf rwp) {
            super( rwp.getPropertyName(), rwp.getPropertyClass(), rwp.getPropertyName(), rwp.getPropertyDesc() );
            this.rwp = rwp;
        }

        public Object getValue() {
            return rwp.getValue();
        }

        public void setValue( Object value ) {
            rwp.setValue( value );
        }

        public PropertyEditor getPropertyEditor () {
            PropertyEditor result = null;
            result = new ListPropertyEditor( rwp );
            return result;
        }
    }
    
    
    private static class ListPropertyEditor extends PropertyEditorSupport { 

        private ReadWritePropertyIntf rwp = null;

        /** Creates new editor */
        public ListPropertyEditor (ReadWritePropertyIntf rwp) {
            this.rwp = rwp;
        }

        public String getAsText () {
            return rwp.getAsTextEditor();
        }

        public void setAsText(String string) {
            rwp.setAsTextEditor(string);
        }

        public void setValue(Object value) {
            rwp.setValueEditor(value);
        }

        public Object getValue() {
            return rwp.getValueEditor();
        }

        public String getJavaInitializationString () {
            return ""; // NOI18N
        }

        public String[] getTags () {
            return rwp.getTagsEditor();
        }

        public boolean supportsCustomEditor() {
            return false; //Lookup doesn't work so far - bug in Lookup
            //return rwp.supportsCustomEditor(); - //Lookup doesn't work so far - bug in Lookup
        }
        public java.awt.Component getCustomEditor() {
            initBrowser();
            return null;
        }
        private LookNode createReflectiveRoot() {

            //Doesn't work so far - bug in Lookup
//            Lookup.Template t = new Lookup.Template( org.netbeans.modules.freestyle.templooks.RefCompositeLook.class );
            Lookup.Template t = null;

            Lookup.Result r = Lookup.getDefault().lookup( t );
            Collection lc = r. allInstances();
            Look look = (Look)lc.iterator().next();

            LookNode result = new LookNode( rwp.getNavigableObject(), look );
            return result;
        }
        private void initBrowser() {
            ExplorerManager manager = new ExplorerManager();
            ExplorerPanel panel = new ExplorerPanel( manager );
            BeanTreeView treeView = new BeanTreeView();

            LookNode rootNode = createReflectiveRoot();
            manager.setRootContext( rootNode );
            panel.add( treeView, java.awt.BorderLayout.CENTER );
            panel.setName( "MDR Browser" );
            panel.open();
        }
    }
}
