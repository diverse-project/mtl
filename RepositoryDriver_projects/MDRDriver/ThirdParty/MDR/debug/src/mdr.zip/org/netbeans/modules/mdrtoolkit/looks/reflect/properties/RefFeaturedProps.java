/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrtoolkit.looks.reflect.properties;

import java.util.*;
import java.awt.*;
import javax.jmi.reflect.*;
import javax.jmi.model.*;

import org.openide.util.actions.SystemAction;
import org.openide.util.SharedClassObject;

import org.openidex.nodes.looks.*;

import java.beans.PropertyEditor;
import java.beans.PropertyEditorSupport;
import org.openide.nodes.*;
import org.openidex.nodes.looks.*;

/**
 *
 * @author  ms118741
 * @version 
 */
public class RefFeaturedProps implements ReadWritePropertyIntf {

    public static final String BOOLEAN_TYPE = "Boolean";
    public static final String BYTE_TYPE ="Byte";
    public static final String CHARACTER_TYPE = "Character";
    public static final String DOUBLE_TYPE = "Double";
    public static final String FLOAT_TYPE ="Float";
    public static final String INTEGER_TYPE ="Integer";
    public static final String LONG_TYPE ="Long";
    public static final String SHORT_TYPE = "Short";
    public static final String STRING_TYPE = "String";

    public static final String ATTRIBUTE_PROPERTY = "Attribute";
    private static final String ATTRIBUTES = "Attributes";
    private static final String NAME_PROPERTY = "name";

    private Object attributeValue = null;
    private String attributeName = null;
    private RefFeatured refFeatured = null;
    private RefBaseObject valueRefObject = null;
    private Attribute attributeMeta = null;
    private Look.NodeSubstitute substitute = null;
    /** Creates new RefBaseObjectProps */
    private RefFeaturedProps(RefFeatured refFeatured, Attribute attributeMeta, Look.NodeSubstitute substitute) {
        this.attributeValue = refFeatured.refGetValue(attributeMeta);
        this.attributeName = ((ModelElement)attributeMeta).getName();
        this.refFeatured = refFeatured;
        this.attributeMeta = attributeMeta;
        this.substitute = substitute;
    }

    public static Node.PropertySet[] getPropertySets(RefFeatured refFeatured, Look.NodeSubstitute substitute) {
        Node.PropertySet[] result = Look.NO_PROPERTY_SETS;
        //ArrayList sheetSets = new ArrayList();
        java.util.List attributes = getAllAttributes( refFeatured );
        RefObject attributeMeta = null;

        Sheet.Set sheetSet = new Sheet.Set();
        sheetSet.setName( ATTRIBUTES );
        sheetSet.setDisplayName( ATTRIBUTES );
        ArrayList props = new ArrayList();
        for (Iterator it = attributes.iterator(); it.hasNext(); ) {
            attributeMeta = (RefObject)it.next();
            try {
                refFeatured.refGetValue((StructuralFeature) attributeMeta);
                props.add( org.netbeans.modules.mdrtoolkit.looks.reflect.properties.LookPropertySupport.getProperties( new RefFeaturedProps(refFeatured, (Attribute)attributeMeta, substitute) ));
            } catch (java.lang.Exception e) {
                //Not a property
            }
        }
        for (Iterator it = props.iterator(); it.hasNext(); ) {
            sheetSet.put( (PropertySupport)it.next() );
        }
        result = new  Node.PropertySet[] {sheetSet};
        return result;
    }

    public static java.util.List getAllAttributes(RefFeatured refFeatured) {
        ArrayList result = new ArrayList();
        RefObject metaObject = refFeatured.refMetaObject();
        if (metaObject instanceof GeneralizableElement) {
            java.util.List superTypes = ((GeneralizableElement)metaObject).allSupertypes();
            RefObject superType = null;
            for (Iterator it = superTypes.iterator(); it.hasNext(); ) {
                superType = (RefObject)it.next();
                result.addAll( getAllFeatures( superType, refFeatured ) );
            }
            result.addAll( getAllFeatures( metaObject, refFeatured ) );
        }
        return result;
    }
    private static java.util.List getAllFeatures(RefObject superType, RefFeatured featured) {
        ArrayList result = new ArrayList();
        RefObject containedObject = null;
        Object value = null;
        Object collectionValue = null;
        Collection contents = null;
        if ( superType instanceof Namespace ) {
            contents = ((Namespace)superType).getContents();
            for (Iterator itContents = contents.iterator(); itContents.hasNext(); ) {
                containedObject = (RefObject)itContents.next();
                if (containedObject instanceof Attribute) {
                    result.add( containedObject );
                }
            }
        }
        return result;
    }

    public String getSheetName() {
        return ATTRIBUTES;
    }
    
    
    public String getPropertyName() {
        return attributeName;
    }
    
    public String getPropertyDesc() {
        return getPropertyName();
    }
    
    public Class getPropertyClass() {
        return String.class;
    }

    public Object getValue() {
        Object result = null;
        result = refFeatured.refGetValue(attributeMeta);
        if (result instanceof RefBaseObject) {
            result = ((RefBaseObject)result).refMofId();
            valueRefObject = (RefBaseObject)result;
        } else {
            if ( result == null ) {
                result = "(null)";
            }
            else {
                result = result.toString();
            }
        }
        if (result == null) {
            result = LookPropertySupport.NO_VALUE;
        }
        attributeValue = result;
        return result;
    }
    
    public void setValue(Object value) {
        try {
            if  ( ((refFeatured != null) && (attributeMeta != null) ) && (value != null) && (!value.equals( attributeValue )) ) {
                refFeatured.refSetValue( attributeMeta, getValueByType( refFeatured, attributeMeta, value ) );
                substitute.firePropertyChange( ATTRIBUTE_PROPERTY, attributeValue, value );
                if (NAME_PROPERTY.equals( attributeMeta.getName() ) ) {
                    substitute.fireNameChange(attributeValue.toString(), value.toString());
                }
                substitute.refreshChildren();
                attributeValue = value;
            }
        } catch (Exception e) {
            System.out.println("Unable to set this attribute type. " + e.getMessage());
        }
    }

    // * * * * * *      EDITOR       * * * * * * * * 
    public String getAsTextEditor() {
        return getValue().toString();
    }
    
    public boolean isPropertyEditor() {
        return false;
    }

    public void setValueEditor(Object value) {
        setValue(value);
    }
    
    public void setAsTextEditor(String string) {
        setValue(string);
    }
    public Object getValueEditor() {
        return getValue();
    }
    public String[] getTagsEditor() {
        return new String[] {};
    }
    public boolean supportsCustomEditor() {
        boolean result = true;
        if ((valueRefObject == null) || (LookPropertySupport.NO_VALUE.equals( getValue() ) ) ) {
            result = false;
        }
        return result;
    }
    public RefBaseObject getNavigableObject() {
        return valueRefObject;
    }

    private Object getValueByType(RefFeatured refFeatured, Attribute attributeMeta, Object newValue) {
        Object result = newValue;
        Classifier type = getType( attributeMeta );
        if (type instanceof PrimitiveType) {
            String primitiveType = type.getName();
            if (BOOLEAN_TYPE.equals( primitiveType )) result = Boolean.valueOf(newValue.toString());
            if (BYTE_TYPE.equals( primitiveType )) result = new Byte( newValue.toString() );
            if (CHARACTER_TYPE.equals( primitiveType )) result = new Character( newValue.toString().toCharArray()[0] );
            if (DOUBLE_TYPE.equals( primitiveType )) result = new Double( newValue.toString() );
            if (FLOAT_TYPE.equals( primitiveType )) result = new Float( newValue.toString() );
            if (INTEGER_TYPE.equals( primitiveType )) result = new Integer( newValue.toString() );
            if (LONG_TYPE.equals( primitiveType )) result = new Long( newValue.toString() );
            if (SHORT_TYPE.equals( primitiveType )) result = new Short( newValue.toString() );
            if (STRING_TYPE.equals( primitiveType )) result = ((newValue == null) ? null : newValue.toString()); 
            if (attributeMeta.getMultiplicity().getUpper() == -1) {
                ArrayList coll = new ArrayList();
                coll.add( result );
                result = coll;
                coll = null;
            }
        } else {
            throw new IllegalArgumentException("Not supported argument type : " + type);
        }
        return result;
    }
    private Classifier getType(TypedElement typedElement) {
        Classifier result = typedElement.getType();
        if (result instanceof AliasType) {
            result = getType( (AliasType)result );
        }
        return result;
    }
}
