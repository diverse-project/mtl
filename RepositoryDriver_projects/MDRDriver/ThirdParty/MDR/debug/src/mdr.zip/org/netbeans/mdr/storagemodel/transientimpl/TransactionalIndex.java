/*
 *                 Sun Public License Notice
 *
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 *
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */


package org.netbeans.mdr.storagemodel.transientimpl;

import java.util.Stack;
import org.netbeans.mdr.persistence.Index;
import org.netbeans.mdr.persistence.StorageException;
import org.netbeans.mdr.util.Logger;

/**
 *
 * @author  tz97951
 */
public abstract class TransactionalIndex implements Index {
    
    // Transaction log
    protected Stack txlog;
    
    /** Creates a new instance of TransactionalIndex */
    public TransactionalIndex() {
        this.txlog = new Stack();
    }
    
    /** Commits the changes
     *  Clears compensating transaction log
     */
    public void commit() {
        this.txlog.clear();
    }
    
    /** Rollbacks the transaction
     *  Executes the compensating transaction log
     */
    public void rollBack() {
        while (!txlog.empty()) {
            try {
                CompensatingTransaction ctx = (CompensatingTransaction) txlog.pop();
                ctx.perform(this);
            } catch (StorageException se) {
                Logger.getDefault().notify(Logger.INFORMATIONAL, se);
            }
        }
    }
    
    protected abstract void addNoTx(Object key, Object value) throws StorageException;
    
    protected abstract Object removeNoTx(Object key, Object value) throws StorageException;
    
}
