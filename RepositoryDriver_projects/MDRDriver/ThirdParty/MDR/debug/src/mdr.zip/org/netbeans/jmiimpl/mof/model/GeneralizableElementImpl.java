/*
 *                 Sun Public License Notice
 *
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 *
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.jmiimpl.mof.model;

import java.util.*;
import javax.jmi.model.*;
import javax.jmi.reflect.*;

import org.netbeans.mdr.util.*;
import org.netbeans.mdr.storagemodel.*;
import org.netbeans.mdr.handlers.*;
import org.netbeans.mdr.persistence.StorageException;

/**
 * Implements MOF operations of GeneralizableElement class of MOF model.
 *
 * @author Martin Matula
 */
public abstract class GeneralizableElementImpl extends NamespaceImpl implements GeneralizableElement {

    protected GeneralizableElementImpl(StorableObject storable) {
        super(storable);
    }

    private Collection/*<StorableFeatured>*/ extendedNamespace() {
        try {
            StorableFeatured storable = (StorableFeatured) _getDelegate();
            StorableAssociation assoc = resolveContains(storable);
            Collection result = new ArrayList((Collection) assoc.queryObjects(assoc.getEnd1Name(), storable.getMofId()));

            if (this instanceof GeneralizableElement) {
                Collection supertypes = ((GeneralizableElement) this).allSupertypes();

                for (Iterator it = supertypes.iterator(); it.hasNext();) {
                    storable = (StorableFeatured) ((BaseObjectHandler) it.next())._getDelegate();
                    result.addAll((Collection) assoc.queryObjects(assoc.getEnd1Name(), storable.getMofId()));
                }
            }

            if (this instanceof MofPackage) {
                ArrayList imports = new ArrayList();
                Object temp;

                for (Iterator it = result.iterator(); it.hasNext();) {
                    temp = it.next();
                    if (temp instanceof Import) {
                        imports.add(((BaseObjectHandler) ((Import) temp).getImportedNamespace())._getDelegate());
                    }
                }

                result.addAll(imports);
            }

            return result;
        } catch (StorageException e) {
            throw (DebugException) Logger.getDefault().annotate(new DebugException(), e);
        }
    }

    private void allSupertypes2(List result, Set visited) {
        List tempElements = getSupertypes();
        GeneralizableElementImpl element;

        for (Iterator it = tempElements.iterator(); it.hasNext();) {
            element = (GeneralizableElementImpl) it.next();
            if (visited.add(element)) {
                element.allSupertypes2(result, visited);
                result.add(element);
            }
        }
    }

    // --- operations

    public List allSupertypes() {
        List result = new ArrayList();
        allSupertypes2(result, new HashSet());
        return result;
    }

    public ModelElement lookupElementExtended(String name) throws NameNotFoundException {
        Collection contents = extendedNamespace();
//        StorableBaseObject storable = _getDelegate();
//        Collection items = storable.getMdrStorage().objectsFromAdditionalIndex(storable.getOutermostPackageId(), "ModelElement.name", name);
//
//        if (items != null) {
//            Object result;
//            for (Iterator it = items.iterator(); it.hasNext();) {
//                result = it.next();
//                if (contents.contains(result)) {
//                    return (ModelElement) BaseObjectHandler.getHandler((StorableBaseObject) result);
//                }
//            }
//        } else {
            for (Iterator it = contents.iterator(); it.hasNext();) {
                ModelElement el = (ModelElement) BaseObjectHandler.getHandler((StorableBaseObject) it.next());
                if (el.getName().equals(name)) {
                    return el;
                }
            }
//        }

        throw new NameNotFoundException(name);
    }

    public List findElementsByTypeExtended(javax.jmi.model.MofClass ofType, boolean includeSubtypes) {
        ArrayList result = new ArrayList();
        RefObject element;
        Collection contents = extendedNamespace();

        for (Iterator it = contents.iterator(); it.hasNext();) {
            element = (RefObject) BaseObjectHandler.getHandler((StorableObject) it.next());
            if (element.refIsInstanceOf(ofType, includeSubtypes)) {
                result.add(element);
            }
        }

        return result;
    }

    // --- derived attributes

}
