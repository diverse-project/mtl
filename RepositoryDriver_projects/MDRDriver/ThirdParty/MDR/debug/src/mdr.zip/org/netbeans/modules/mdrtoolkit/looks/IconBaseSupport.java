/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrtoolkit.looks;

import java.awt.Image;

import org.openide.nodes.AbstractNode;
import org.openide.nodes.Children;

/** Support class for sharing the Icon cache with the ret of the IDE and
 * for easier transformation of location strings to images.<BR> 
 * This class is a hack. Which allowes us to share the icon
 * cache in the IDE (org.openide.nodes.IconManager) without changing the
 * API. However it might be better to publish such a class in the APIs.
 * If nothing else it would be quicker because of the synchronization.
 * This class is a utility singleton class.
 *
 * @author  Jaroslav Tulach, Petr Hrebejk
 */
public class IconBaseSupport extends Object {

    private static final HackNode hackNode = new HackNode();
    
    /** This class is a singleton */
    private IconBaseSupport() {
    }

    /** Finds appropriate icon from the IconBase 
     */
    public static synchronized Image getIcon( String base, int type ) {
        hackNode.setIconBase( base );
        return hackNode.getIcon( type );
    }
    
    /** Finds appropriate openedIcon from the IconBase 
     */
    public static synchronized Image getOpenedIcon( String base, int type ) {
        hackNode.setIconBase( base );
        return hackNode.getOpenedIcon( type );
    }
    
    /** Terrible hack, for caching our icons.
     */
    private static class HackNode extends AbstractNode {
        HackNode() {
            super( Children.LEAF );
        }
        
    }
    
    
}
