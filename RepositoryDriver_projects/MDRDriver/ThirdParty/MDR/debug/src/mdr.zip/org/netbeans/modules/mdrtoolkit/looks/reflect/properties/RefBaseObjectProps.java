/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrtoolkit.looks.reflect.properties;

import org.netbeans.modules.mdrtoolkit.looks.reflect.*;
import org.netbeans.modules.mdrtoolkit.looks.RepositoryCache;

import java.util.*;
import java.awt.*;
import javax.jmi.reflect.*;
import javax.jmi.model.*;

import org.openide.util.actions.SystemAction;
import org.openide.util.SharedClassObject;

import org.openidex.nodes.looks.*;

import java.beans.PropertyEditor;
import java.beans.PropertyEditorSupport;
import org.openide.nodes.*;
/**
 *
 * @author  ms118741
 * @version 
 */
public class RefBaseObjectProps implements ReadWritePropertyIntf {

    private static final String META_PROPERTIES = "Meta properties";
    private static final int META_OBJECT = 0;
    private static final int IMMEDIATE_PACKAGE = 1;
    private static final int OUTERMOST_PACKAGE = 2;
    private static final int MOFID = 3;

    private static final String PROP_META_OBJECT = "Meta object";
    private static final String PROP_IMMEDIATE_PACKAGE = "Immediate package";
    private static final String PROP_OUTERMOST_PACKAGE = "Outermost package";
    private static final String PROP_MOFID = "MofID";
    private static final String OMP_SEPARATOR = ":";

    private RefBaseObject refBaseObject = null;
    private int propCode = META_OBJECT;
    /** Creates new RefBaseObjectProps */
    private RefBaseObjectProps(RefBaseObject refBaseObject, int propCode) {
        this.refBaseObject = refBaseObject;
        this.propCode = propCode;
    }

    public static Node.PropertySet[] getPropertySets(RefBaseObject refBaseObject) {
        Node.PropertySet[] result = Look.NO_PROPERTY_SETS;
        ArrayList sheetSets = new ArrayList();
        sheetSets.addAll( LookPropertySupport.getPropertySets( new RefBaseObjectProps(refBaseObject, META_OBJECT ) ) );
        sheetSets.addAll( LookPropertySupport.getPropertySets( new RefBaseObjectProps(refBaseObject, IMMEDIATE_PACKAGE ) ) );
        sheetSets.addAll( LookPropertySupport.getPropertySets( new RefBaseObjectProps(refBaseObject, OUTERMOST_PACKAGE ) ) );
        sheetSets.addAll( LookPropertySupport.getPropertySets( new RefBaseObjectProps(refBaseObject, MOFID ) ) );
        
        result = new  Node.PropertySet[ sheetSets.size() ];
        System.arraycopy( sheetSets.toArray(), 0, result, 0, sheetSets.size() );
        return result;
    }
    
    public String getSheetName() {
        return META_PROPERTIES;
    }
    
    
    public String getPropertyName() {
        String result = null;
        switch (propCode) {
            case META_OBJECT :  {
                result = PROP_META_OBJECT;
                break;
            }
            case IMMEDIATE_PACKAGE :  {
                result = PROP_IMMEDIATE_PACKAGE;
                break;
            }
            case OUTERMOST_PACKAGE :  {
                result = PROP_OUTERMOST_PACKAGE;
                break;
            }
            case MOFID :  {
                result = PROP_MOFID;
                break;
            }
        }
        return result;
    }
    
    public String getPropertyDesc() {
        return getPropertyName();
    }
    
    public Class getPropertyClass() {
        return String.class;
    }

    public Object getValue() {
        Object result = null;
        switch (propCode) {
            case META_OBJECT :  {
                RefObject metaObject = refBaseObject.refMetaObject();
                if (metaObject instanceof ModelElement) {
                    RefPackage omp = metaObject.refOutermostPackage();
                    result = MofUtils.resolveFullyQualifiedName( ((ModelElement)metaObject).getQualifiedName() );

                    Collection packages = RepositoryCache.getRepositoryCache().getObjectNameChache().keySet();
                    for (Iterator it = packages.iterator(); it.hasNext(); ) {
                        if (omp.equals( it.next() )) {
                            result = (String)RepositoryCache.getRepositoryCache().getObjectNameChache().get( omp ) + 
                                     OMP_SEPARATOR + result;
                        }
                    }
                    
                } else {
                    result = metaObject.refMofId();
                }
                break;
            }
            case IMMEDIATE_PACKAGE :  {
                RefPackage imp = refBaseObject.refImmediatePackage();
                if (imp != null) {
                    result = imp.refMofId();
                }
                break;
            }
            case OUTERMOST_PACKAGE :  {
                RefPackage omp = refBaseObject.refOutermostPackage();
                if (omp != null) {
                    result = omp.refMofId();
                }
                break;
            }
            case MOFID :  {
                result = refBaseObject.refMofId();
                break;
            }
        }
        if (result == null) {
            result = LookPropertySupport.NO_VALUE;
        }
        return result;
    }
    
    public void setValue(Object value) {
    }

    // * * * * * *      EDITOR       * * * * * * * * 
    public String getAsTextEditor() {
        return getValue().toString();
    }
    
    public boolean isPropertyEditor() {
        return false;
    }

    public void setValueEditor(Object value) {
    }
    
    public void setAsTextEditor(String string) {
    }
    public Object getValueEditor() {
        return getValue();
    }
    public String[] getTagsEditor() {
        return null;
    }
    
    public boolean supportsCustomEditor() {
        boolean result = true;
        if ( (propCode == MOFID) || (LookPropertySupport.NO_VALUE.equals( getValue() ) ) ) {
            result = false;
        }
        return result;
    }
    
    public RefBaseObject getNavigableObject() {
        RefBaseObject result = null;
        switch (propCode) {
            case META_OBJECT :  {
                result = refBaseObject.refMetaObject();
                break;
            }
            case IMMEDIATE_PACKAGE :  {
                result = refBaseObject.refImmediatePackage();
                break;
            }
            case OUTERMOST_PACKAGE :  {
                result = refBaseObject.refOutermostPackage();
                break;
            }
            case MOFID :  {
                result = refBaseObject;
                break;
            }
        }
        return result;
    }
    
}
