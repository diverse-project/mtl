/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.mdr;

import org.netbeans.api.mdr.*;

/**
 * A simple {@link org.netbeans.api.mdr.MDRManager} which manages only one
 * single repository of type {@link NBMDRepositoryImpl}.
 *
 * @author  mmatula
 * @version 
 */
public class NBMDRManagerImpl extends MDRManager {
    private static final String REPOSITORY_DEFAULT = "Default";
    private final MDRepository rep = new NBMDRepositoryImpl();
    
    /** Creates new manager. */
    public NBMDRManagerImpl() {
    }
    
    /** Returns the default repository. In this implementation the default
     * repository is the only repository managed by this manager. */
    public MDRepository getDefaultRepository() {
        return getRepository(REPOSITORY_DEFAULT);
    }
    
    /**
     * Returns the default repository, if <code>name</code> is the name
     * of the default repository. In all other cases <code>null</code> is
     * returned.
     *
     * @return the default repository of <code>null</code>
     */
    public MDRepository getRepository(String name) {
        if (REPOSITORY_DEFAULT.equals(name)) {
            return rep;
        } else {
            return null;
        }
    }
    
    public String[] getRepositoryNames() {
        return new String[] {REPOSITORY_DEFAULT};
    }
}
