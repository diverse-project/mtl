/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.lib.jmi.query;

import java.util.Iterator;


/** Default implementation of the iterator, does not allowe the remove operation
 *
 * @author Petr Hrebejk
 */
abstract class QueryIterator implements Iterator {

    abstract public boolean hasNext();
    
    abstract public Object next();
    
    /** Allways throws an UnsupportedOperationException as the Queries are
     * read only.
     */
    public void remove() {
        throw new UnsupportedOperationException( "MDR queries cannot be modified" );
    }
    
    // Innerclasses ------------------------------------------------------------
    
    /** Delegates to underlying iterator
    */
    static class Delegate extends QueryIterator {
        
        /** Contains the underlying iterator. Subclasses can ask it directly.
        */
        protected final Iterator ITERATOR;

        public Delegate(Iterator iterator) {
            super();
            this.ITERATOR = iterator;
        }

        public boolean hasNext() {
            return ITERATOR.hasNext();
        }

        public Object next() {
            return ITERATOR.next();
        }
        
    }
    
}
