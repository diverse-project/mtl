/*
 *                 Sun Public License Notice
 *
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 *
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrexplorer.looks.model;

import java.awt.Image;
import java.util.*;
import javax.jmi.reflect.*;
import javax.jmi.model.*;
import org.openide.nodes.Node;
import org.openide.util.actions.SystemAction;
import org.netbeans.api.mdr.*;
import org.netbeans.api.looks.*;
import org.netbeans.spi.looks.*;
import org.netbeans.modules.mdrexplorer.looks.RepositoryCache;
import org.netbeans.modules.mdrexplorer.looks.reflect.Utils;
import org.netbeans.modules.mdrexplorer.looks.LimitedChildrenLook;
import org.netbeans.modules.mdrexplorer.looks.DataRestWrapper;
import org.netbeans.modules.mdrexplorer.looks.reflect.actions.*;
import org.netbeans.modules.mdrexplorer.looks.RepositoryCache;
import org.netbeans.modules.mdrexplorer.looks.MDREventHandler;
/** Implements MOF models defaut view.
 *
 * @author  Petr Hrebejk, Tomas Zezula
 */
public class RootPackages extends LimitedChildrenLook {
    
    private static final String ICON_BASE_DIR =
    "org/netbeans/modules/mdrexplorer/looks/model/resources/"; // NOI18N
    private static final String PACKAGE_PROXY_ICON = ICON_BASE_DIR + "packageproxy"; // NOI18N
    
    /** Creates new PackageProxy
     */
    public RootPackages() {
        super(Utils.getLocalizedString(RootPackages.class,"TXT_RootPackages"));
    }
    
    public Object attachTo(Look.NodeSubstitute substitute) {
        super.attachTo(substitute);
        RepositoryCache cache = RepositoryCache.getRepositoryCache();
        MDREventHandler handler = cache.getEventHandler(((MDRObject)substitute.getRepresentedObject()).repository());
        if (handler != null)
            handler.addNodeSubstitute(substitute);
        return handler;
    }
    
    public Object[] getChildObjects(Look.NodeSubstitute substitute ) {
        ModelPackage mp = (ModelPackage)substitute.getRepresentedObject();
        MDRepository rep = ((MDRObject)mp).repository();
        rep.beginTrans(false);
        try {
            MofPackageClass pc = mp.getMofPackage();
            ArrayList rps = new ArrayList();
            int count = this.getBrowserChildCount();
            count = (count ==-1 ? Integer.MAX_VALUE : count);
            Collection instances = pc.refAllOfClass();
            Iterator it = instances.iterator();
            for (int i=0; it.hasNext() && i<count;) {
                MofPackage p = (MofPackage)it.next();
                if ( p.getContainer() == null ) {
                    rps.add( p );
                    i++;
                }
            }
            if (it.hasNext()) {
                rps.add( new DataRestWrapper( new Collection[] {instances}, count));
            }
            Object[] children = new Object[ rps.size() ];
            rps.toArray( children );
            return children;
        } finally {
            rep.endTrans();
        }
    }
    
    public String iconBase(Look.NodeSubstitute substitute) {
        return PACKAGE_PROXY_ICON;
    }
    
    public String getName( Look.NodeSubstitute substitute ) {
        RefPackage packageProxy = (RefPackage)substitute.getRepresentedObject();
        String packageName = (String)RepositoryCache.getRepositoryCache().getPackageName(packageProxy);
        if (packageName == null) {
            packageName = ((MofPackage)packageProxy.refMetaObject()).getName();
        }
        return packageName;
    }
    
    public String getDisplayName(Look.NodeSubstitute substitute) {
        return this.getName(substitute);
    }
    
    public javax.swing.Action[] getActions(Look.NodeSubstitute substitute) {
        return new javax.swing.Action[] {
            SystemAction.get(LoadXMIAction.class),
            SystemAction.get(SaveXMIAction.class),
            SystemAction.get(GenerateDTDAction.class),
            SystemAction.get(Map2JavaAction.class),
            SystemAction.get(DeleteObjectAction.class),
        };
    }
    
}
