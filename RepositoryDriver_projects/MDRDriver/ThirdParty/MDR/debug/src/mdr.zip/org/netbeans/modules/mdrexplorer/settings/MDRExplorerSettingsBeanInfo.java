/*
 *                 Sun Public License Notice
 *
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 *
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrexplorer.settings;

import java.beans.*;
import java.util.ResourceBundle;
import org.openide.util.NbBundle;


public class MDRExplorerSettingsBeanInfo extends SimpleBeanInfo {
    
    private static final String ICON_BASE = "org/netbeans/modules/mdrexplorer/resources/";
    private static final String ICON_COLOR_16 = "settings.gif";
    private static final String ICON_COLOR_32 = "settings.gif";
    private static final String ICON_MONO_16 = "settings.gif";
    private static final String ICON_MONO_32 = "settings.gif";
    
    private ResourceBundle bundle;
    
    public MDRExplorerSettingsBeanInfo() {
    }
    
    public BeanDescriptor getBeanDesriptor() {
        BeanDescriptor bd = new BeanDescriptor(MDRExplorerSettings.class);
        bd.setDisplayName (this.getLocalizedString("TXT_MDRExplorerSettings"));
        return bd;
    }
    
    public  PropertyDescriptor[] getPropertyDescriptors() {
        try {
            PropertyDescriptor[] pds =  new PropertyDescriptor[] {
                new PropertyDescriptor(MDRExplorerSettings.CHILD_COUNT,MDRExplorerSettings.class,"getBrowserChildCount","setBrowserChildCount") // NoI18N
            };
            pds[0].setBound(true);
            pds[0].setDisplayName(this.getLocalizedString("TXT_BrowserChildsCountDisplayName"));
            pds[0].setShortDescription(this.getLocalizedString("TXT_BrowserChildsCountDescription"));
            pds[0].setPropertyEditorClass (BrowserChildCountPropertyEditor.class);
            return pds;
        }catch (IntrospectionException introspectionException) {
            return new PropertyDescriptor[0];
        }
    }
    
    public int getDefaultPropertyIndex() {
        return 0;
    }
    
    public java.awt.Image getIcon(int type) {
        switch (type) {
            case ICON_COLOR_32x32:
                return this.loadImage(ICON_BASE + ICON_COLOR_32);
            case ICON_MONO_16x16:
                return this.loadImage(ICON_BASE + ICON_MONO_16);
            case ICON_MONO_32x32:
                return this.loadImage(ICON_BASE + ICON_MONO_32);
            case ICON_COLOR_16x16:
            default:
                return this.loadImage(ICON_BASE + ICON_COLOR_16);
        }
    }
    
    private String getLocalizedString(String message) {
        if (this.bundle == null) {
            this.bundle = NbBundle.getBundle(MDRExplorerSettingsBeanInfo.class);
        }
        return this.bundle.getString(message);
    }
    
}

