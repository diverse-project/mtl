/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.mdr.handlers;

import java.util.*;
import java.lang.ref.*;
import java.lang.reflect.*;

import javax.jmi.model.Namespace;
import javax.jmi.reflect.*;

import org.netbeans.mdr.storagemodel.*;
import org.netbeans.mdr.persistence.MOFID;
import org.netbeans.mdr.persistence.StorageException;
import org.netbeans.mdr.persistence.StorageBadRequestException;
import org.netbeans.mdr.handlers.gen.*;
import org.netbeans.mdr.util.*;

import org.netbeans.api.mdr.*;
import org.netbeans.api.mdr.events.*;

/** Handles RefBaseObjectCalls
 *
 * @author  Martin Matula
 * @version 
 */
public abstract class BaseObjectHandler extends ImplClass implements MDRObject/*, OclAny*/ {
    
    /* --------------------------------------------------------------------- */
    /* -- Static attributes ------------------------------------------------ */
    /* --------------------------------------------------------------------- */
    
    /**
     * Maps storage objects (instances of {@link StorableBaseObject}) to
     * JMI compliant handler objects (instances of {@link RefBaseObject}).
     */
    private static final Map facilityCache = new FacilityCache();
    
    /**
     * Maps mof ids of meta-objects to the appropriate JMI interfaces (String =&gt; Class).
     */
    private static final Hashtable classCache = new Hashtable();

    private static MDRClassLoader defaultLoader = null;
    private static ClassLoaderProvider provider = null;
    
    /* --------------------------------------------------------------------- */
    /* -- Static setters/getters ------------------------------------------- */
    /* --------------------------------------------------------------------- */
    
    public static synchronized void setClassLoaderProvider(ClassLoaderProvider provider) {
        BaseObjectHandler.provider = provider;
    }
    
    public static synchronized MDRClassLoader getDefaultClassLoader() {
        if (defaultLoader == null) {
            defaultLoader = new MDRClassLoader(provider);
        }
//	Logger.getDefault().log(defaultLoader.toString() + " : " + defaultLoader.getClass().getName());
        return defaultLoader;   
    }
    
    /* --------------------------------------------------------------------- */
    /* -- Static helper methods (private) ---------------------------------- */
    /* --------------------------------------------------------------------- */

    /**
     * Returns the handler class for JMI interface <code>ifc</code> and storage object <code>s</code>.
     *
     * @param loader the class loader for the definition of new classes
     * @param ifc JMI interface to be implemented by the class
     * @param s storage object to be wrapped by an instances of the class
     * @return class implementing <code>ifc</code>
     */
    private static Class getHandlerClass(MDRClassLoader loader, Class ifc, StorableBaseObject s) throws IllegalArgumentException {
        /* check if the loader may load the interface */
        check(loader, ifc);
        /* try to load from cache */
        Map cache = getLoaderCache(loader);
        String className = getName(ifc);
        Class result = getFromCache(cache, ifc, className);
        
        if (result == null) {
            try {
                /* generate and define handler class */
                byte[] handlerClassFile = HandlerGenerator.generateHandler(className, ifc, s);
                
                /* [XXX] Allow the use of a system property org.netbeans.mdr.byteCodeDir, write class
                 * files to that directory, if the system property is set.
                 */
//                try {
//                    java.io.FileOutputStream file = new java.io.FileOutputStream("e:/classes/" + className.substring(className.lastIndexOf('.') + 1) + ".class");
//                    file.write(handlerClassFile);
//                    file.close();
//                } catch (Exception e) {
//                    Logger.getDefault().notify(Logger.INFORMATIONAL, e);
//                }
                
                result = loader.defineClass(className, handlerClassFile);
            } finally {
                releaseCache(cache, result, className);
            }
        }
        
        return result;
    }

    /**
     * Returns the JMI interface to be implemented by the handler of <code>s</code>.
     *
     * @param s a storage object
     * @return the JMI interface for <code>s</code>
     */
    private static Class resolveClass(StorableBaseObject s) {
        try {
            StorableObject metaObject = s.getMetaObject();
            return getDefaultClassLoader().resolveInterface(metaObject, !(s instanceof StorableObject));
        } catch (StorageException e) {
            throw (DebugException) Logger.getDefault().annotate(new DebugException(), e);
        }
    }
    
    /* --------------------------------------------------------------------- */
    /* -- Static methods (public) ------------------------------------------ */
    /* --------------------------------------------------------------------- */

    /**
     * Frees the caches of JMI compliant handler objects (for storage objects)
     * and of JMI implementation classes (for meta-objects).
     */
    public static void _freeCache() {
        facilityCache.clear();
        classCache.clear();
    }
    
    /**
     * Returns JMI compliant handler object for <code>s</code>.
     *
     * @param s the storage object to be wrapped or <code>null</code>
     * @return handler implementing JMI interface or <code>null</code>
     */
    public static RefBaseObject getHandler(StorableBaseObject s) throws IllegalArgumentException {
        if (s == null) {
            return null;
        }

        synchronized (s.getMdrStorage().getStorageByMofId(s.getMofId())) {
//        synchronized (facilityCache) {
            RefBaseObject refBO = (RefBaseObject) (facilityCache.get(s.getMofId()));

            if ( refBO != null ) {
                return refBO;
            }
        }

        Class ifc = resolveClass(s);
        return getHandler(s, ifc);
    }
    
    /**
     * Returns JMI compliant handler object for <code>s</code>.
     *
     * @param s the storage object to be wrapped or <code>null</code>
     * @param ifc the JMI interface to be implemented by the handler
     * @return handler implementing JMI interface or <code>null</code>
     */
    public static RefBaseObject getHandler(StorableBaseObject s, Class ifc) throws IllegalArgumentException {
	if (s == null) {
	    return null;
	}

        /* [XXX] For performance reasons the following piece of code should
         * be enabled, when it is expected that cache lookup succeeds quite
         * often. hkrug@rationalizer.com */
//        Object oldRecord;
//        synchronized (facilityCache) {
//            oldRecord = facilityCache.get(s.getMofId());
//        }
//        if ( oldRecord != null ) {
//            return oldRecord;
//        }
        
        /* load the handler class */
        MDRClassLoader loader = getDefaultClassLoader();
	Class cl = getHandlerClass(loader, ifc, s);

	try {
            Class cls = s.getClass();
            if (cls.equals (TransientStorableClass.class)) {
                cls = StorableClass.class;
            }
            else if (cls.equals (TransientStorableObject.class)) {
                cls = StorableObject.class;
            }
            else if (cls.equals (TransientStorableAssociation.class)) {
                cls = StorableAssociation.class;
            }
            /* create handler object, if necessary */
            Constructor cons = cl.getConstructor(new Class[] {cls});

            synchronized (s.getMdrStorage().getStorageByMofId(s.getMofId())) {
//                synchronized (facilityCache) {
                    Object oldRecord = facilityCache.get(s.getMofId());
                    if (oldRecord == null) {
                        oldRecord = cons.newInstance(new Object[] {s});
                        facilityCache.put(s.getMofId(), oldRecord);
                    }
                    return (BaseObjectHandler) oldRecord;
//                }
            }
	} catch (NoSuchMethodException e) {
            throw (DebugException) Logger.getDefault().annotate(new DebugException(), e);
	} catch (IllegalAccessException e) {
            throw (DebugException) Logger.getDefault().annotate(new DebugException(), e);
	} catch (InstantiationException e) {
            throw (DebugException) Logger.getDefault().annotate(new DebugException(), e);
	} catch (InvocationTargetException e) {
            throw (DebugException) Logger.getDefault().annotate(new DebugException(), e);
	}
    }
    
    /**
     * Returns interface <code>ifcName</code>. The interface is not generated on the
     * fly, but must be available for loading by the default class-loader
     * (see {@link #getDefaultClassLoader()}).
     *
     * @param ifcName name of the interface to be loaded
     * @return the interface named <code>ifcName</code>
     */
    public static Class resolveInterface(String ifcName) throws ClassNotFoundException {
        try {
            return Class.forName(ifcName, true, getDefaultClassLoader());
        } catch (RuntimeException e) {
            Logger.getDefault().annotate(e, "ClassLoader: " + getDefaultClassLoader());
            Logger.getDefault().annotate(e, "ClassName: " + ifcName);
            throw e;
        } catch (Error e) {
            Logger.getDefault().annotate(e, "ClassLoader: " + getDefaultClassLoader());
            Logger.getDefault().annotate(e, "ClassName: " + ifcName);
            throw e;
	}
    }
        
    /**
     * Loads the class <code>implName</code> from the default class loader.
     *
     * @param implName class name
     * @return the class
     */
    public static Class resolveImplementation(String implName) throws ClassNotFoundException {
        try {
            return Class.forName(implName, true, getDefaultClassLoader());
        } catch (ClassNotFoundException e) {
            // Logger.getDefault().annotate(e, "Implementation of derived element not found. ClassName: " + implName);
            throw e;
        } catch (Error e) {
            Logger.getDefault().annotate(e, "ClassLoader: " + getDefaultClassLoader());
            Logger.getDefault().annotate(e, "ClassName: " + implName);
            throw e;
	} catch (RuntimeException e) {
            Logger.getDefault().annotate(e, "ClassLoader: " + getDefaultClassLoader());
            Logger.getDefault().annotate(e, "ClassName: " + implName);
            throw e;
        }
    }
    
    /* --------------------------------------------------------------------- */
    /* -- Private attributes ----------------------------------------------- */
    /* --------------------------------------------------------------------- */

//    /** The object in strorage to delegate to
//    */
//    private final StorableBaseObject storableDelegate;
    private final MOFID mofId;
    private final MdrStorage mdrStorage;
    // The storable hard reference is used only by transient objects
    // to prevent garbage collection.
    // For non transient objects it is null during the whole life cycle.
    private StorableBaseObject storable;
    
    /* --------------------------------------------------------------------- */
    /* -- Constructor(s) --------------------------------------------------- */
    /* --------------------------------------------------------------------- */

    /** Creates new RefBaseObjectHandler */
    protected BaseObjectHandler(StorableBaseObject storable) {
        this.mofId = storable.getMofId();
        //this.storableDelegate = storable;
        this.mdrStorage = storable.getMdrStorage();
        try {
            if (storable instanceof StorableObject && ((StorableObject)storable).getClassProxy ().isTransient ()) {
                this.storable = storable;
            }   
            else {
                this.storable = null;
            }
        } catch (org.netbeans.mdr.persistence.StorageException se) {
            this.storable = null;
        }
    }
    
    /* --------------------------------------------------------------------- */
    /* -- Transaction related methods -------------------------------------- */
    /* --------------------------------------------------------------------- */
    
    protected final void _lock() {
        _lock(true);
    }
    
    protected final void _lock(boolean write) {
        mdrStorage.getRepositoryMutex().enter(write);
    }
    
    protected final void _unlock() {
        mdrStorage.getRepositoryMutex().leave();
    }

    protected final void _unlock(boolean fail) {
        mdrStorage.getRepositoryMutex().leave(fail);
    }
    
    /* --------------------------------------------------------------------- */
    /* -- Implements org.netbeans.api.mdr.MDRObject ------------------------ */
    /* --------------------------------------------------------------------- */
    
    public final MDRepository repository() {
        return mdrStorage.getRepository();
    }
    
    /* --------------------------------------------------------------------- */
    /* -- Extends java.lang.Object ----------------------------------------- */
    /* --------------------------------------------------------------------- */

    /** Tests this object with other object for identity.
     *  The object is identical if it is of RefBaseObject type
     *  and its mofid equals to this object mofid.
     *  This equals method and hashCode method are the only two
     *  methods guaranteed to work after the object was deleted.
     *  This allows developer to safely remove the deleted object from a container.
     *  @param Object other object
     *  @return true if objects are identical
     */ 
    public final boolean equals(Object obj) {
        if (obj instanceof BaseObjectHandler) {
            return this == obj;
        } else return (obj instanceof RefBaseObject) && ((BaseObjectHandler) obj).mofId.equals(this.mofId);
    }

    public String toString() {
        String className = getClass().getName();
        className = className.substring( className.lastIndexOf( "." ) + 1 );
        String metaId;
        try {
            metaId = _getDelegate().getMetaObject().getMofId().toString();
        } catch (Exception e) {
            metaId = "(not available)";
        }
        String outP;

        try {
            outP = _getDelegate().getOutermostPackage().getMofId().toString();
        } catch (Exception e) {
            outP = "(not available)";
        }
        
        return className + "  ID: " + refMofId() + "  MID: " + metaId  + "  OPCKG: " + outP;
    }

    /** Returns hash code of this object.
     *  This hashCode method and equals method are the only two
     *  methods guaranteed to work after the object was deleted.
     *  This allows developer to safely remove the deleted object from a container.
     *  @return int the hash code
     */
    public final int hashCode() {
        return this.mofId.hashCode();
    }
    
    /* --------------------------------------------------------------------- */
    /* -- Implements javax.jmi.reflect.RefBaseObject ----------------------- */
    /* --------------------------------------------------------------------- */

    public final RefObject refMetaObject() {
        try {
            return (RefObject) getHandler(_getDelegate().getMetaObject());
        } catch (StorageException e) {
            throw (DebugException) Logger.getDefault().annotate(new DebugException(), e);
        }
    }

    public final RefPackage refImmediatePackage() {
        try {
            return (RefPackage) getHandler(_getDelegate().getImmediatePackage());
        } catch (StorageException e) {
            throw (DebugException) Logger.getDefault().annotate(new DebugException(), e);
        }
    }

    public final RefPackage refOutermostPackage() {
        try {
            StorableBaseObject pkg = _getDelegate().getOutermostPackage();
            if (pkg.getMofId().equals(_getDelegate().getMofId())) {
                return (RefPackage) this;
            } else {
                return (RefPackage) getHandler(pkg);
            }
        } catch (StorageException e) {
            throw (DebugException) Logger.getDefault().annotate(new DebugException(), e);
        }
    }

    public final String refMofId() {
        return mofId.toString();
    }
    
    public final Collection refVerifyConstraints(boolean deepVerify) {
        if (deepVerify) return _recursiveVerify(new ArrayList(), new HashSet());
        else return _verify(new ArrayList());
    }
    
    /* --------------------------------------------------------------------- */
    /* -- --------------------------------------------------- */
    /* --------------------------------------------------------------------- */

    public final StorableBaseObject _getDelegate() {
/*        
        StorableBaseObject storable = (StorableBaseObject) storableDelegate.get();
        if (storable == null) {
            try {
                storable = mdrStorage.getObject(mofId);
                storableDelegate = new SoftReference(storable);
            } catch (StorageException e) {
                throw new DebugException("Storage exception: " + e);
            }
        }
 */
        try {
            if (this.storable != null)
                return this.storable;                   // Transient object
            else
                return mdrStorage.getObject(mofId);     // Persistent object
        } catch (StorageBadRequestException e) {
            throw new InvalidObjectException(null, "Object with MOFID " + mofId + " no longer exists.");
        } catch (StorageException e) {
            throw new DebugException(e.toString());
        }
        //return storableDelegate;
    }
    
    protected final MdrStorage _getMdrStorage() {
        return mdrStorage;
    }
    
    /* --------------------------------------------------------------------- */
    /* -- Methods to be overridden by sub-classes -------------------------- */
    /* --------------------------------------------------------------------- */

    protected abstract Collection _recursiveVerify(Collection violations, Set visited);
    protected abstract Collection _verify(Collection violations);

    /* --------------------------------------------------------------------- */
    /* -- FacilityCache (static inner class) ------------------------------- */
    /* --------------------------------------------------------------------- */

    /** Weak cache for created Handlers
    */
    private static class FacilityCache extends HashMap {
        private final ReferenceQueue queue = new ReferenceQueue();

        private class HandlerReference extends WeakReference {
            private MOFID mofId;
            private RefBaseObject baseObject;

            public HandlerReference(BaseObjectHandler handler) {
                super(handler, queue);

                mofId = handler._getDelegate().getMofId();
                
                if (handler.refOutermostPackage() instanceof javax.jmi.model.ModelPackage) {
                    // the object is from a metamodel => we will keep "hard" reference
                    baseObject = (RefBaseObject) handler;
                } else {
                    // the object is not a metamodel object => we will not keep "hard" reference on it
                    baseObject = null;
                }
            }

            public MOFID getProxyMofId() {
                return mofId;
            }
        }

        private void cleanUp() {
            HandlerReference reference;

            while ((reference = (HandlerReference) queue.poll()) != null) {
//                Logger.getDefault().log("Removing: " + reference.getProxyMofId());
                this.remove(reference.getProxyMofId());
            }
        }

        public Object put(Object key, Object value) {
            cleanUp();
            Object result = super.put(key, new HandlerReference((BaseObjectHandler) value));
            if (result != null) {
                return ((HandlerReference) result).get();
            } else {
                return result;
            }
        }

        public Object get(Object key) {
            cleanUp();
            Object result = super.get(key);
            if (result != null) {
                return ((HandlerReference) result).get();
            } else {
                return result;
            }
        }
    }
}
