/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrexplorer.looks.reflect;
import org.netbeans.modules.mdrexplorer.looks.reflect.*;
import org.netbeans.modules.mdrexplorer.looks.reflect.actions.*;
import javax.jmi.reflect.*;
import org.openide.util.actions.SystemAction;
import org.netbeans.api.looks.*;
import org.netbeans.spi.looks.*;
import org.netbeans.modules.mdrexplorer.looks.LimitedChildrenLook;

/** Implements MOF models defaut view.
 *
 * @author  Martin Matula, Tomas Zezula
 */
public class BaseObjectLook extends LimitedChildrenLook {

    private static final String PACKAGE_PROXY_ICON = 
        "org/netbeans/modules/mdrexplorer/looks/reflect/resources/packageproxy"; // NOI18N
    
    private static final String CLASS_PROXY_ICON = 
        "org/netbeans/modules/mdrexplorer/looks/reflect/resources/classproxy"; // NOI18N

    private static final String ASSOCIATION_PROXY_ICON = 
        "org/netbeans/modules/mdrexplorer/looks/reflect/resources/associationproxy"; // NOI18N
    
    private static final String ASSOCIATION_WRAPPER = 
        "org/netbeans/modules/mdrexplorer/looks/reflect/resources/associationMeta"; // NOI18N

    private static final String ASSOCIATION_END_ICON = 
        "org/netbeans/modules/mdrexplorer/looks/reflect/resources/associationEnd"; // NOI18N

    private static final String ASSOCIATION_OTHER_END_ICON = 
        "org/netbeans/modules/mdrexplorer/looks/reflect/resources/associationOtherEnd"; // NOI18N

    private static final String OBJECT_ICON = 
        "org/netbeans/modules/mdrexplorer/looks/reflect/resources/object"; // NOI18N

    private static final String REF_OBJECT_ICON = 
        "org/netbeans/modules/mdrexplorer/looks/reflect/resources/refobject"; // NOI18N
    
    
    public BaseObjectLook (String name) {
        super (name);
    }

    public javax.swing.Action[] getActions( Look.NodeSubstitute substitute ) {
        SystemAction[] actions = new SystemAction[1];
        actions[0] = SystemAction.get( PropertiesAction.class);
        return actions;
    }
    
    public String iconBase (Look.NodeSubstitute substitute) {
        String result = OBJECT_ICON;
        Object ro = substitute.getRepresentedObject();
        if ( ro instanceof RefObject ) {
            result = REF_OBJECT_ICON;
        } else if ( ro instanceof RefPackage ) {
            result = PACKAGE_PROXY_ICON;
        } else if ( ro instanceof RefClass ) {
            result = CLASS_PROXY_ICON;
        } else if ( ro instanceof RefAssociation ) {
            result = ASSOCIATION_PROXY_ICON;
        } else if (ro instanceof RefAssocWrapper) {
            result = ASSOCIATION_WRAPPER;
        } else if (ro instanceof RefLinkEndWrapper) {
            result = ASSOCIATION_END_ICON;
        } else if (ro instanceof RefLinkOtherEndWrapper) {
            result = ASSOCIATION_OTHER_END_ICON;
        } else if (ro instanceof RefGetValueWrapper) {
            result = OBJECT_ICON;
        }
        return result;
    }
    
}
