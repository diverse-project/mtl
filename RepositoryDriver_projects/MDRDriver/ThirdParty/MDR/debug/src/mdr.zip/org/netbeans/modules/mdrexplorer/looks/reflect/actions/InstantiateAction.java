/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrexplorer.looks.reflect.actions;

import org.netbeans.modules.mdrexplorer.looks.reflect.*;

import org.openide.TopManager;
import org.openide.NotifyDescriptor;
import org.openide.nodes.Node;
import org.openide.util.HelpCtx;
import org.openide.util.NbBundle;
import org.openide.util.RequestProcessor;
import org.openide.util.actions.NodeAction;
import org.openide.filesystems.FileSystem;
import org.openide.filesystems.FileObject;
import org.openide.loaders.*;

import org.netbeans.api.looks.*;

import javax.jmi.reflect.*;
import javax.jmi.model.MofPackage;

import org.w3c.dom.Document;

import java.util.ResourceBundle;
import java.io.File;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;

/** Action sensitive to the node selection that does something useful.
 *
 * @author  Martin Matula
 */
public class InstantiateAction extends NodeAction {

    /** Resource bundle */
    private static final ResourceBundle bundle = NbBundle.getBundle(Utils.class);

    protected void performAction (Node[] nodes) {
        Node node = nodes[0];
        if ( (node instanceof LookNode) && (((LookNode)node).getRepresentedObject() instanceof MofPackage) ) {
            instantiate( (LookNode)node );
        }
    }

    private void instantiate(LookNode lookNode) {
        final LookNode node = lookNode;
        final TopManager tm = TopManager.getDefault();
        String newName = null;

        NotifyDescriptor.InputLine nd = new NotifyDescriptor.InputLine( bundle.getString("CTL_NewPackageName"), bundle.getString("CTL_Instantiate"));
        if (tm.notify(nd).equals(NotifyDescriptor.OK_OPTION)) {
            newName = nd.getInputText();
        }

        final String packageName = newName;

        if (packageName != null) {
            RequestProcessor.postRequest(new Runnable() {
                public void run() {
                    tm.setStatusText(bundle.getString("CTL_InstantiationStarted"));
                    MofPackage pkg = (MofPackage) node.getRepresentedObject();

                    try {
                        org.netbeans.api.mdr.MDRManager.getDefault().getDefaultRepository().createExtent(packageName, pkg);
                    } catch (org.netbeans.api.mdr.CreationFailedException e) {
                        tm.notify(new NotifyDescriptor.Exception(e));
                    }
                    tm.setStatusText(bundle.getString("CTL_InstantiationFinished"));
                }
            });
        }
    }

    protected boolean enable (Node[] nodes) {
        if (nodes == null || nodes.length != 1)
            return false;
        if (!(nodes[0] instanceof LookNode))
            return false;
        return (((LookNode)nodes[0]).getRepresentedObject() instanceof MofPackage);
    }

    public String getName () {
        return bundle.getString("CTL_ACTION_Instantiate");
    }

    protected String iconResource () {
        return null;
    }

    public HelpCtx getHelpCtx () {
        return HelpCtx.DEFAULT_HELP;
    }
}
