/*
 *                 Sun Public License Notice
 *
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 *
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */

package org.netbeans.modules.mdrexplorer.looks;

import org.netbeans.spi.looks.*;
import org.netbeans.api.looks.*;
/**
 *
 * @author  Tomas Zezula
 */
public class ModelNamespaceLook extends AbstractNamespaceLook {
    
    public static final String PREFIX = "Looks/Model/";
    
    /** Creates a new instance of ModelNamespaceLook */
    public ModelNamespaceLook() {
        super (PREFIX);
    }
    
    /** Returns name of the look. This name should identify the look.
     * @return Name of the look.
     */
    public String getName() {
        return this.getLocalizedString ("TXT_ModelNamespaceLook");
    }
    
    
    public Look[] availableLooks (Look.NodeSubstitute substitute) {
        return null;
    }
    
}
