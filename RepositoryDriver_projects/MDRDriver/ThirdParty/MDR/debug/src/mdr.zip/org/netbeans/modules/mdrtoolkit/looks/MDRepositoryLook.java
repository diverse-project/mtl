/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrtoolkit.looks;

import java.awt.Image;

import javax.jmi.reflect.RefPackage;
import javax.jmi.model.MofPackage;

import org.netbeans.api.mdr.*;
import org.openidex.nodes.looks.*;

//import org.netbeans.modules.freestyle.*;

/** All metadata repositories in the system
 *
 * @author Petr Hrebejk
 */
public class MDRepositoryLook extends AcceptorLook.Type {
        
    private static final String MDREPOSITORY_ICON = "/org/netbeans/modules/mdrtoolkit/looks/resources/repository"; // NOI18N";
    
    /** Creates new RootLook */
    public MDRepositoryLook() {
        super( new Delegate(), MDRepository.class );
        System.out.println(MDRepository.class.getClassLoader().toString());
        System.out.println(MofPackage.class.getClassLoader().toString());
    }
    
    private static class Delegate extends DefaultLook {
        
        public Object[] getChildObjects(Look.NodeSubstitute substitute) {
            Object[] result = Look.NO_KEYS;
            MDRepository repository = (MDRepository)substitute.getRepresentedObject();;
            
            String[] packages = repository.getExtentNames();
            java.util.ArrayList temp = new java.util.ArrayList();
            javax.jmi.reflect.RefPackage packageObject = null;
            if ( (packages != null) && (packages.length > 0) ) {
                for (int cnt = 0; cnt < packages.length; cnt++ ) {
                    packageObject = repository.getExtent( packages[cnt] );
                    if (packageObject != null) {
                        temp.add(packageObject);
                        RepositoryCache.getRepositoryCache().getObjectNameChache().put( packageObject, packages[cnt] );
                    }
                }
                if (temp.size() > 0) {
                    result = temp.toArray();
                }
            }
            return result;
        }
        
        /*
        public Object[] getChildObjects( Look.NodeSubstitute substitute ) {
            
            MDRepository rep = (MDRepository)substitute.getRepresentedObject();
            
            String[] packageNames = rep.getPackageNames();
            RefPackage[] pckgs = new RefPackage[ packageNames.length ];
            
            for( int i = 0; i < packageNames.length; i++ ) {
                try {
                    pckgs[i] = rep.getPackage( packageNames[i] );
                }
                catch ( NameNotResolvedException e ) {
                    System.out.println( e );
                }
            }
        
            return pckgs;
        }
        */
        
        public Image getIcon( Look.NodeSubstitute substitute, int type ) {
            return IconBaseSupport.getIcon( MDREPOSITORY_ICON, type );
        }
        
        public String getName( Look.NodeSubstitute substitute ) {
            return "MOF Repository";
        }
        
    }
     
}
