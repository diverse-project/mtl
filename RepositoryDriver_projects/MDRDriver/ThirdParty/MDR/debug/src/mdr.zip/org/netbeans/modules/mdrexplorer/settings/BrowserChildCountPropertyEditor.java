/*
 *                 Sun Public License Notice
 *
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 *
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */

package org.netbeans.modules.mdrexplorer.settings;

import java.beans.*;
import java.util.ResourceBundle;
import org.openide.util.NbBundle;
/**
 *
 * @author  Tomas Zezula
 */
public class BrowserChildCountPropertyEditor extends PropertyEditorSupport {
    
    private ResourceBundle bundle;
    
    /** Creates a new instance of BrowserChildCountPropertyEditor */
    public BrowserChildCountPropertyEditor() {
        super ();
    }
    
    public BrowserChildCountPropertyEditor (Object source) {
        super (source);
    }
    
    
    public String getAsText () {
        Integer a = (Integer) this.getValue();
        if (a.intValue() == -1) {
            return this.getLocalizedString ("TXT_Unlimited");
        }
        else
            return a.toString();
    }
    
    public void setAsText (String value) {
        if (value != null) {
            if (value.equals (this.getLocalizedString("TXT_Unlimited"))) {
                this.setValue (new Integer (-1));
            }
            else {
                try {
                    this.setValue (Integer.valueOf (value));
                }catch (NumberFormatException nfe) {
                }
            }
        }
    }
    
    public void setValue (Object value) {
        if (value instanceof Integer && ((Integer)value).intValue() >= -1) {
            super.setValue (value);
        }
    }
   
    
    public boolean isPaintable () {
        return false;
    }
    
    protected String getLocalizedString (String message) {
        if (this.bundle == null) {
            this.bundle = NbBundle.getBundle (BrowserChildCountPropertyEditor.class);
        }
        return this.bundle.getString (message);
    }
}
