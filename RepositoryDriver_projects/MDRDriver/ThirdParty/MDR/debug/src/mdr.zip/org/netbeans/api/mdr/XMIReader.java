/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.api.mdr;

import javax.jmi.xmi.*;
import java.io.IOException;
import javax.jmi.reflect.RefPackage;
import java.util.Collection;
import org.openide.util.Lookup;

/** XMI reader utility. Provides a way for importing XMI documents into a JMI service.
 * Use {@link #getDefault} method to get the default instance.
 * @author Martin Matula
 * @deprecated This class was replaced by a new API in org.netbeans.api.xmi package and will be removed soon.
 * You should use {@link javax.jmi.xmi.XmiReader} and {@link org.netbeans.api.xmi.XMIReader} instead.
 */
public abstract class XMIReader implements XmiReader {
    /** Reads an XMI document identified by a given URL into a given package instance (extent).
     * @param uri URI of an XMI document to read.
     * @param extents Package instance which the document should be imported to.
     * @throws IOException I/O error during XMI import.
     * @throws MalformedXMIException Malformed XMI document.
     * @return Collection of topmost object read from the XMI.
     */    
    public abstract Collection read(String uri, RefPackage[] extents) throws IOException, MalformedXMIException; 
    
    /** Returns the default instance of XMIReader.
     * @return Default XMI reader.
     */    
    public static XMIReader getDefault() {
        // [PENDING] simple lookup should be used once the lookup is fixed (currently it does not preserve order)
        Lookup.Result result = Lookup.getDefault().lookup(
            new Lookup.Template(XMIReader.class)
        );
        Collection instances = result.allInstances();
        return (instances.size() > 0 ? (XMIReader) result.allInstances().iterator().next() : null);
    }
}
