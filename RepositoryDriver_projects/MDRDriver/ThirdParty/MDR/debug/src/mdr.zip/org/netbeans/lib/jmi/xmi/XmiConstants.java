/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.lib.jmi.xmi;

/**
 *
 * @author  mareks
 * @version 
 */
public interface XmiConstants {

    //General constants
    public static final String NS_SEPARATOR = ":";
    public static final String DOT_SEPARATOR = ".";
    public static final String XMI_PREFIX = "XMI.";

    //Basic elements
    public static final String XMI_ROOT = "XMI";
    public static final String XMI_HEADER = "XMI.header";
    public static final String XMI_CONTENT = "XMI.content";
    public static final String XMI_DIFFERENCE = "XMI.difference";
    public static final String XMI_DELETE = "XMI.delete";
    public static final String XMI_ADD = "XMI.add";
    public static final String XMI_REPLACE = "XMI.replace";
    public static final String XMI_EXTENSION = "XMI.extension";
    public static final String XMI_EXTENSIONS = "XMI.extensions";
    
    //Sub elements for XMI_HEADER
    public static final String XMI_DOCUMENTATION = "XMI.documentation";
    public static final String XMI_MODEL = "XMI.model";
    public static final String XMI_METAMODEL = "XMI.metamodel";
    public static final String XMI_METAMETAMODEL = "XMI.metametamodel";
    public static final String XMI_IMPORT = "XMI.import";
    
    //Attributes
    public static final String XMI_ID = "xmi.id";
    public static final String XMI_UUID = "xmi.uuid";
    public static final String XMI_LABEL = "xmi.label";
    public static final String XMI_IDREF = "xmi.idref";
    public static final String XMI_HREF = "href";
    public static final String XMI_POSITION = "xmi.position";
    public static final String XMI_VersionAtt = "xmi.version";
    public static final String XMI_NameAtt = "xmi.name";
    public static final String XMI_VALUE = "xmi.value";
    public static final String XMI_TYPE = "xmi.type";    
    
    //DataTypes
    public static final String XMI_CORBA_TYPE_CODE = "XMI.CorbaTypeCode";
    public static final String XMI_ANY_TYPE = "XMI.any";
    public static final String XMI_FIELD = "XMI.field";

    // MOF 1.4 primitive types
    public static final String BOOLEAN_TYPE = "Boolean";
    public static final String DOUBLE_TYPE = "Double";
    public static final String FLOAT_TYPE ="Float";
    public static final String INTEGER_TYPE ="Integer";
    public static final String LONG_TYPE ="Long";
    public static final String STRING_TYPE = "String";

    //Corba types
    public static final String XMICorbaTcField = "XMI.CorbaTcField";
    public static final String XMI_TCNAME = "xmi.tcName";
    public static final String XMI_CorbaTcEnumLabel = "XMI.CorbaTcEnumLabel";

    public static final String XMICorbaTcStruct = "XMI.CorbaTcStruct";
    public static final String XMICorbaTcEnum = "XMI.CorbaTcEnum";
    public static final String XMICorbaTcUnion = "XMI.CorbaTcUnion";
    public static final String XMICorbaTcObjRef = "XMI.CorbaTcObjRef";
    public static final String XMICorbaTcArray = "XMI.CorbaTcArray";
    public static final String XMICorbaTcAlias = "XMI.CorbaTcAlias";
    public static final String XMICorbaTcSequence = "XMI.CorbaTcSequence";
    public static final String XMICorbaTcAny = "XMI.CorbaTcAny";
    
    public static final String XMICorbaTcExcept = "XMI.CorbaTcExcept";
    public static final String XMICorbaTcTypeCode = "XMI.CorbaTcTypeCode";
    public static final String XMICorbaTcPrincipal = "XMI.CorbaTcPrincipal";
    public static final String XMICorbaTcNull = "XMI.CorbaTcNull";
    public static final String XMICorbaTcVoid = "XMI.CorbaTcVoid";
    
    public static final String XMICorbaTcShort = "XMI.CorbaTcShort";
    public static final String XMICorbaTcLong = "XMI.CorbaTcLong";
    public static final String XMICorbaTcUShort = "XMI.CorbaTcUShort";
    public static final String XMICorbaTcULong = "XMI.CorbaTcULong";
    public static final String XMICorbaTcFloat = "XMI.CorbaTcFloat";
    public static final String XMICorbaTcDouble = "XMI.CorbaTcDouble";
    public static final String XMICorbaTcBoolean = "XMI.CorbaTcBoolean";
    public static final String XMICorbaTcChar = "XMI.CorbaTcChar";
    public static final String XMICorbaTcWChar = "XMI.CorbaTcWChar";
    public static final String XMICorbaTcOctet = "XMI.CorbaTcOctet";
    public static final String XMICorbaTcString = "XMI.CorbaTcString";
    public static final String XMICorbaTcWString = "XMI.CorbaTcWString";
    public static final String XMICorbaTcLongLong = "XMI.CorbaTcLongLong";
    public static final String XMICorbaTcULongLong = "XMI.CorbaTcULongLong";
    public static final String XMICorbaTcLongDouble = "XMI.CorbaTcLongDouble";

    //Packages
    public static final String PRIMITIVE_TYPES_PACKAGE = "PrimitiveTypes";
    
    // Tag ids
    public static final String TAGID_XMI_NAMESPACE = "org.omg.xmi.namespace";
    public static final String TAGID_XMI_ENUMERATION_UNPREFIX = "org.omg.xmi.enumerationUnprefix";
    
    // XMI 2.0 tags
    public static final String TAG_SERIALIZE = "org.omg.xmi.serialize";
    public static final String TAG_ELEMENT = "org.omg.xmi.element";
    public static final String TAG_REMOTE_ONLY = "org.omg.xmi.remoteOnly";
    public static final String TAG_XMI_NAME = "org.omg.xmi.xmiName";
    public static final String TAG_HREF = "org.omg.xmi.href";
    public static final String TAG_NS_PREFIX = "org.omg.xmi.nsPrefix";
    public static final String TAG_NS_URI = "org.omg.xmi.nsURI";
    
    // XMI 2.0 Schema
    public static String TAG_ENFORCE_MAX_MULTIPLICITY = "org.omg.xmi.enforceMaximumMultiplicity";
    public static String TAG_ENFORCE_MIN_MULTIPLICITY = "org.omg.xmi.enforceMinimumMultiplicity";
    public static String TAG_USE_SCHEMA_EXTENSIONS = "org.omg.xmi.useSchemaExtensions";
    public static String TAG_CONTENT_TYPE = "org.omg.xmi.contentType";
    public static String TAG_PROCESS_CONTENTS = "org.omg.xmi.processContents";
    public static String TAG_INCLUDE_NILS = "org.omg.xmi.includeNils";
    public static String TAG_SCHEMA_TYPE = "org.omg.xmi.schemaType";
    public static String TAG_ID_NAME = "org.omg.xmi.idName";
    public static String TAG_DEFAULT_VALUE = "org.omg.xmi.defaultValue";
    public static String TAG_FIXED_VALUE = "org.omg.xmi.fixedValue";
    public static String TAG_FORM = "org.omg.xmi.form";    
    
    // XMI 2.0 namespace uri
    public static final String XMI_NAMESPACE_URI = "http://www.omg.org/XMI";
    // XML Schema namespace uri
    public static final String XML_SCHEMA_NAMESPACE_URI = "http://www.w3.org/XMLSchema-instance";
    
    public static final String XMI20_ID = "id";    
    public static final String XMI20_IDREF = "idref";
    public static final String XMI20_VERSION = "version";
    public static final String XMI20_NIL = "nil";
}
