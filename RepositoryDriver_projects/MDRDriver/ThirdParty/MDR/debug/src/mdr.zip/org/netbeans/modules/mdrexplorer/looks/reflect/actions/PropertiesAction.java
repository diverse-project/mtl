/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrexplorer.looks.reflect.actions;

import org.netbeans.modules.mdrexplorer.looks.reflect.*;

import org.openide.TopManager;
import org.openide.NotifyDescriptor;
import org.openide.nodes.Node;
import org.openide.util.*;
import org.openide.util.actions.NodeAction;
import org.openide.filesystems.FileSystem;
import org.openide.filesystems.FileObject;
import org.openide.loaders.*;
import org.netbeans.api.mdr.*;
import javax.jmi.reflect.*;

import java.util.ResourceBundle;

import org.netbeans.api.looks.*;


public class PropertiesAction extends NodeAction {
   
    /** Resource bundle */
    private static final ResourceBundle bundle = NbBundle.getBundle(Utils.class);

    protected void performAction (Node[] nodes) {
        TopManager topManager = TopManager.getDefault();
        topManager.getNodeOperation().showProperties( nodes );
    }

    protected boolean enable (Node[] nodes) {
        return true;
    }

    public String getName () {
        return bundle.getString("CTL_ACTION_Properties");
    }

    protected String iconResource () {
        return null;
    }

    public HelpCtx getHelpCtx () {
        return HelpCtx.DEFAULT_HELP;
    }
}
