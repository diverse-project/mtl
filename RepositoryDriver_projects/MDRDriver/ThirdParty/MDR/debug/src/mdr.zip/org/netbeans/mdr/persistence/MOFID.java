/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.mdr.persistence;

import java.io.*;
import java.text.*;
import java.util.*;
import org.netbeans.mdr.persistence.*;

/**
 * MOFID implemented as a UUID for the repository plus a long for the ID.
 */
public final class MOFID extends Object {
    
    public static final int LENGTH = 8;
    public static final int STRING_LENGTH = 16;
    
    private long serialNumber;
    private String string = null;
    private String storageId = null;

    
    public MOFID(Storage storage) {
        this.storageId = storage.getStorageId ();
        this.serialNumber = storage.getSerialNumber ();
    }

    /** This constructor is just for internal use by storage
     *  to create MOFID after deserialization and should be
     *  newer called by user code.
     */ 
    public MOFID(long serialNumber, String storageId) {
        this.serialNumber = serialNumber;
        if (storageId == null)
            throw new IllegalArgumentException ();
        else
            this.storageId = storageId;
    }

    /** get the serial number
    */
    public long getSerialNumber() {
    	return serialNumber;
    }
    
    /** Getter for storage ID.
     * @return ID of the home storage of this MOFID.
     */
    public String getStorageID() {
        return storageId;
    }

    /** compare MOFIDs as values
    */
    public boolean equals(Object o) {
	if (!(o instanceof MOFID))
	    return false;
	if (this.serialNumber != ((MOFID)o).serialNumber)
            return false;
        return this.getStorageID().equals (((MOFID)o).getStorageID());
    }

    /*** Helper Methods ***/
    
    /** MOFIDs with equal values will hash equal
    */
    public int hashCode() {
	return (int)serialNumber;
    }

    private static char makeStringBuffer[];
    /**
     * Construct the external form of a MOFID
     */
    public synchronized static String makeString(String prefix, long id) {
	int size = prefix.length();
	int totalSize = size + 1 + STRING_LENGTH;
	if (makeStringBuffer == null || makeStringBuffer.length < totalSize) {	
	    makeStringBuffer = new char[totalSize];
	}
	prefix.getChars(0, size, makeStringBuffer, 0);
	makeStringBuffer[size] = ':';
	fromLong(id, makeStringBuffer, size + 1);
	return new String(makeStringBuffer, 0, totalSize);
    }

    /**
     * Convert to external form.
     */
    public String toString() {
        if (string == null) {
            string = makeString(storageId, serialNumber);
        }
        return string;
    }

    private static int[] longwords;
    /** Convert long to 16 hex digits, to be placed in a character array.
    * @param value value to convert to hex digits
    * @param buffer array into which to place hex digits
    * @param beginning offset in array
    */
    public synchronized static void fromLong(long value, char buffer[], int offset) {
        int b;
	if (longwords == null)
	    longwords = new int[2];
	longwords[0] = (int)((value >> 32) & 0xFFFFFFFF);
	longwords[1] = (int)(value & 0xFFFFFFFF);
	for (int j = 0; j < 2; j++) {
	    for (int shift = 28; shift >= 0; shift -= 4) {
		b = (int)((longwords[j] >> shift) & 0xF);

		if (b <= 9)
		    b += 0x30;
		else
		    b += 0x37;

		buffer[offset++] = (char)b;
	    }
	}
    }	
    
    public static MOFID fromString(String mofId) {
        int pos = mofId.lastIndexOf(':');
        if (pos >= 0) try {
            return new MOFID(Long.parseLong(mofId.substring(pos + 1), 16), mofId.substring(0, pos));
        } catch (NumberFormatException e) {
        } catch (IndexOutOfBoundsException e) {
        }
        return null;
    }
}
