/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrexplorer.looks.reflect.properties;


import java.util.*;
import java.util.Iterator;
import java.util.ResourceBundle;
import java.beans.PropertyEditor;
import java.beans.PropertyEditorSupport;
import org.openide.nodes.*;
import org.openide.util.actions.SystemAction;
import org.openide.util.Lookup;
import org.netbeans.api.looks.*;
import org.openide.explorer.*;
import org.openide.explorer.view.*;
import org.netbeans.modules.mdrexplorer.looks.reflect.Utils;

public class LookPropertySupport {

    public static PropertySupport getProperty (ReadWritePropertyIntf rwp) {
        return new LookNodeProperty( rwp );
    }
    
    // ************************ I N N E R    C L A S S E S ********************************
    
    private static class LookNodeProperty extends PropertySupport.ReadWrite {

        private ReadWritePropertyIntf rwp = null;

        LookNodeProperty(ReadWritePropertyIntf rwp) {
            super( rwp.getPropertyName(), rwp.getPropertyClass(), rwp.getPropertyName(), rwp.getPropertyDesc() );
            this.rwp = rwp;
        }
        
        public boolean canWrite () {
            return ! rwp.isReadOnly ();
        }

        public Object getValue() {
            return rwp.getValue();
        }

        public void setValue( Object value ) {
            if (!rwp.isReadOnly())
                rwp.setValue( value );
        }

        public PropertyEditor getPropertyEditor () {
            if (rwp.hasPropertyEditor()) {
                return rwp.getPropertyEditor ();
            }
            else {
                // The default one 
                return super.getPropertyEditor ();
            }
        }
    }
 
}
