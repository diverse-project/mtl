/*
 *                 Sun Public License Notice
 *
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 *
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */

package org.netbeans.modules.mdrexplorer.actions;

import org.openide.explorer.ExplorerPanel;
import org.openide.explorer.ExplorerManager;
import org.openide.explorer.view.BeanTreeView;
import org.openide.util.NbBundle;
import org.netbeans.api.looks.Look;
import org.netbeans.api.looks.LookNode;
import org.netbeans.modules.mdrexplorer.looks.MDRManagerWrapper;


public class MDRExplorer extends ExplorerPanel {

  public MDRExplorer () {
    this.initGui ();
  }

  private void initGui () {
    this.add ( new BeanTreeView());
    this.getExplorerManager ().setRootContext (new LookNode (new MDRManagerWrapper(), Look.DEFAULT));
    this.setName (NbBundle.getMessage (MDRExplorer.class,"TXT_MDRBrowser"));
  }


}
