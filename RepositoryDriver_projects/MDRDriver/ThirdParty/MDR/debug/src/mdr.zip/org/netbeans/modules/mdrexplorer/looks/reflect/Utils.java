/*
 *                 Sun Public License Notice
 *
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 *
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrexplorer.looks.reflect;

import org.netbeans.modules.mdrexplorer.looks.reflect.properties.*;

import java.util.*;
import javax.jmi.reflect.*;
import javax.jmi.model.*;

import org.netbeans.api.mdr.MDRObject;
import org.netbeans.api.mdr.MDRepository;
import org.openide.util.actions.SystemAction;
import org.netbeans.api.looks.*;
import org.openide.nodes.*;
import org.openide.util.NbBundle;
import org.netbeans.modules.mdrexplorer.looks.DataRestWrapper;

/**
 *
 * @author  ms118741, Tomas Zezula
 * @version
 */
public class Utils {
    
    private static final String NAME = "name";          // NOI18N
    private static final String NAME_SEPARATOR = ".";   // NOI18N
    
    private static HashMap bundles;
    
    /** Creates new Utils */
    private Utils() {
    }
    
    public static String getRefObjectName(Look.NodeSubstitute substitute) {
        return getRefObjectName( (RefObject)substitute.getRepresentedObject() );
    }
    
    
    public static String getRefObjectName(RefObject refObject) {
        String result = null;
        
        RefObject metaObject = refObject.refClass().refMetaObject();
        try {
            RefObject attribute = ((MofClass)metaObject).lookupElementExtended(NAME);
            if (attribute instanceof Attribute) {
                Object value = ((RefFeatured)refObject).refGetValue( (StructuralFeature) attribute );
                if (value == null) {
                    result = getLocalizedString("TXT_NO_VALUE");
                }
                else {
                    result = value.toString();
                }
            }
        } catch (NameNotFoundException e) {
            if (result == null) {
                result = getLocalizedString("TXT_META") + ((MofClass)refObject.refMetaObject()).getName();
            }
        }
        return result;
    }
    
    public static String getRefObjectMetaName(Look.NodeSubstitute substitute) {
        RefObject object = (RefObject) substitute.getRepresentedObject();
        return resolveFullyQualifiedName(((ModelElement) object.refMetaObject()).getQualifiedName());
    }
    
    public static java.util.List getRefObjectChildObjects(Look.NodeSubstitute substitute, int limit) {
        return getRefObjectChildObjects( (RefObject)substitute.getRepresentedObject(), limit );
    }
    
    public static java.util.List getRefObjectChildObjects(RefObject refObject, int limit) {
        return getAllReferenceWrappers(refObject, limit);
    }
    
    public static java.util.List getAllAttributeWrappers(RefObject refObject, int limit) {
        return getAllFeaturedWrappers(refObject, true, limit);
    }
    
    public static java.util.List getAllReferenceWrappers(RefObject refObject, int limit) {
        return getAllFeaturedWrappers(refObject, false, limit);
    }
    
    /** returns all feature objects for featured object
     *  Starts its own transaction
     */
    public static java.util.List getAllFeaturedWrappers(RefObject refObject, boolean attributes, int limit) {
        boolean[] completionFlag = new boolean[1];
        ArrayList result = new ArrayList();
        RefObject metaObject = refObject.refMetaObject();
        if (metaObject instanceof GeneralizableElement) {
            MDRepository rep = ((MDRObject)refObject).repository();
            rep.beginTrans(false);
            try {
                java.util.List superTypes = ((GeneralizableElement)metaObject).allSupertypes();
                RefObject superType = null;
                int lastSize = 0;
                for (Iterator it = superTypes.iterator(); it.hasNext(); ) {
                    superType = (RefObject)it.next();
                    Collection partialResult = null;
                    if (attributes) {
                        partialResult = getAllAttributes( superType, (RefFeatured)refObject,limit, completionFlag);
                    } else {
                        partialResult = getAllReferences( superType, (RefFeatured)refObject, limit, completionFlag);
                    }
                    result.addAll(partialResult);
                    limit = limit == -1 ? -1 : limit - partialResult.size();
                    if (!completionFlag[0]) {
                        ArrayList restParents = new ArrayList();
                        restParents.add(superType);
                        while (it.hasNext())
                            restParents.add(it.next());
                        restParents.add(metaObject);
                        result.add( new DataRestWrapper(new Collection[] {restParents},result.size()-lastSize,DataRestWrapper.REFERENCES, refObject));
                        return result;
                    }
                    lastSize = result.size();
                }
                if (attributes) {
                    result.addAll( getAllAttributes( metaObject , (RefFeatured)refObject, limit,completionFlag));
                } else {
                    result.addAll( getAllReferences( metaObject , (RefFeatured)refObject, limit,completionFlag));
                }
                if (!completionFlag[0]) {
                    ArrayList rest = new ArrayList();
                    rest.add(metaObject);
                    result.add( new DataRestWrapper(new Collection[]{rest},result.size()-lastSize,DataRestWrapper.REFERENCES, refObject));
                }
            }finally {
                rep.endTrans();
            }
        }
        return result;
    }
    
    public static String resolveFullyQualifiedName(java.util.List fullyQualifiedName) {
        String result = "";
        if (fullyQualifiedName != null) {
            for (Iterator it = fullyQualifiedName.iterator(); it.hasNext(); ) {
                result += it.next();
                if (it.hasNext()) {
                    result += NAME_SEPARATOR;
                }
            }
        }
        return result;
    }
    
    public static Node.PropertySet[] getAssocLinkEndPropertySets(RefBaseObject assocEnd, Look.NodeSubstitute substitute) {
        Node.PropertySet[] featuredProps = new Node.PropertySet[0];
        Node.PropertySet[] refObjectProps = new Node.PropertySet[0];
        Node.PropertySet[] refBaseObjectProps = new Node.PropertySet[0];
        
        if (assocEnd instanceof RefFeatured) {
            featuredProps = RefFeaturedProps.getPropertySets( (RefFeatured)assocEnd, substitute );
        }
        if (assocEnd instanceof RefObject) {
            refObjectProps = RefObjectProps.getPropertySets( (RefObject)assocEnd );
        }
        if (assocEnd instanceof RefBaseObject) {
            refBaseObjectProps = RefBaseObjectProps.getPropertySets( assocEnd );
        }
        
        Node.PropertySet[] result = new Node.PropertySet[featuredProps.length + refObjectProps.length + refBaseObjectProps.length];
        System.arraycopy(featuredProps, 0, result, 0, featuredProps.length);
        System.arraycopy(refObjectProps, 0, result, featuredProps.length, refObjectProps.length);
        System.arraycopy(refBaseObjectProps, 0, result, refObjectProps.length + featuredProps.length, refBaseObjectProps.length);
        return result;
    }
    
    // **************** Public methods for DataRestLook, used to build collection of wrappers on demand
    
    /** Returns the rest of features 
     *  Starts its own transaction
     */
    public static Collection getRestFeatures(Collection metaObjects, RefFeatured featured, int offset, int mode) {
        ArrayList result = new ArrayList();
        boolean[] completionFlag = new boolean[1];
        for (Iterator it = metaObjects.iterator(); it.hasNext();) {
            RefObject metaObject = (RefObject) it.next();
            MDRepository repository = ((MDRObject)metaObject).repository();
            repository.beginTrans(false);
            try {
                result.addAll(getAllFeatures(metaObject,featured,mode == DataRestWrapper.ATTRIBUTES,-1,offset,completionFlag));
            }finally {
                repository.endTrans();
            }
            offset = 0;
        }
        return result;
    }
    
    /** This method creates wrappers for Association Ends
     *  The method does not start its own transaction, so
     *  it should be called within a transaction.
     */
    public static Collection getRefLinkEndWrappers (Collection links, RefAssociation refAssoc, AssociationEnd associationEnd, boolean isFirstEnd, int limit, int offset, boolean[] completionFlag) {
        ArrayList result = new ArrayList();
        ArrayList alreadyCreated = new ArrayList();
        Iterator it = links.iterator();
        // Skeep offset
        for (int i=0; it.hasNext() && i < offset;) {
            RefAssociationLink link = (RefAssociationLink) it.next();
            if (isFirstEnd) {
                if (!alreadyCreated.contains (link.refFirstEnd())) {
                    alreadyCreated.add (link.refFirstEnd());
                    i++;
                }
            }
            else {
                if (!alreadyCreated.contains (link.refSecondEnd())) {
                    alreadyCreated.add (link.refSecondEnd());
                    i++;
                }
            }
        }
        
        for (int i=0; it.hasNext() && (i<limit || limit == -1); ) {
            RefAssociationLink link = (RefAssociationLink)it.next();
            if (isFirstEnd) {
                if (!alreadyCreated.contains( link.refFirstEnd() )) {
                    alreadyCreated.add( link.refFirstEnd() );
                    result.add( new RefLinkEndWrapper( link.refFirstEnd(), refAssoc,associationEnd,true) );
                    i++;
                }
            } else {
                if (!alreadyCreated.contains( link.refSecondEnd() )) {
                    alreadyCreated.add( link.refFirstEnd() );
                    result.add( new RefLinkEndWrapper( link.refSecondEnd(), refAssoc,associationEnd,false) );
                    i++;
                }
            }
        }
        completionFlag[0] = ! it.hasNext();
        alreadyCreated.clear();
        alreadyCreated = null;
        return result;
    }
    
    /** This method creates wrappers for other Association Ends
     *  The method does not start its own transaction, so
     *  it should be called within a transaction.
     */
    public static Collection getRefLinkOtherEndWrappers (Collection otherEnds, RefObject endInstance, RefAssociation refAssoc, boolean isFirstEnd, int count, int offset, boolean[] completionFlag) {
        ArrayList result = new ArrayList();
        Iterator it = otherEnds.iterator();
        // Skeep offset
        for (int i=0; i< offset && it.hasNext(); i++)
            it.next();
        for (int i=0; it.hasNext() && (i<count || count == -1); i++) {
            RefLinkOtherEndWrapper roew = null;
            if (isFirstEnd) {
                roew = new RefLinkOtherEndWrapper(refAssoc,endInstance,(RefObject)it.next(),false);
            }
            else {
                roew = new RefLinkOtherEndWrapper(refAssoc,endInstance,(RefObject)it.next(),true);
            }
            result.add(roew);
        }
        completionFlag[0] = ! it.hasNext();
        return result;
    }
    
    // * * * * * * * *     P R I V A T E    M E T H O D S        * * * * * * * *
    // * * * * * * * *     P R I V A T E    M E T H O D S        * * * * * * * *
    // * * * * * * * *     P R I V A T E    M E T H O D S        * * * * * * * *
    private static Collection getAllReferences(RefObject superType, RefFeatured featured, int limit, boolean[] completionFlag) {
        return getAllFeatures(superType, featured, false, limit, 0, completionFlag);
    }
    private static Collection getAllAttributes(RefObject superType, RefFeatured featured, int limit, boolean[] completionFlag) {
        return getAllFeatures(superType, featured, true, limit, 0, completionFlag);
    }
    
    private static Collection getAllFeatures(RefObject superType, RefFeatured featured, boolean attributes, int limit, int offset, boolean[] completionFlag) {
        Collection result = null;
        Collection contents = null;
        if ( superType instanceof Namespace ) {
            contents = ((Namespace)superType).getContents();
            result = createRefGetValueVrappers(featured, contents, offset, attributes, limit,completionFlag);
        }
        return result;
    }
    
    private static Collection createRefGetValueVrappers(RefFeatured featured, Collection contents, int offset, boolean attributes, int limit, boolean[] completionFlag) {
        Iterator itContents = contents.iterator();
        ArrayList result = new ArrayList();
        //Skeep offset
        for (int i = 0; i <offset && itContents.hasNext();) {
            Object element = itContents.next();
            if ((attributes && element instanceof Attribute) || element instanceof Reference)
                i++;
        }
        
        for (int i = 0; itContents.hasNext() && (limit == -1 || i<limit); ) {
            RefObject containedObject = (RefObject)itContents.next();
            if (attributes) {
                if (containedObject instanceof Attribute) {
                    result.add( new RefGetValueWrapper( featured, containedObject ) );
                    i++;
                }
            } else {
                if (containedObject instanceof Reference) {
                    result.add( new RefGetValueWrapper( featured, containedObject ) );
                    i++;
                }
            }
        }
        if (itContents.hasNext()) {
            completionFlag[0] = false;
        }
        else {
            completionFlag[0] = true;
        }
        return result;
    }
    
    public static String getLocalizedString(String str) {
        return getLocalizedString(Utils.class, str);
    }
    
    public static String getLocalizedString(Class clazz, String str) {
        if (bundles == null) {
            bundles = new HashMap();
        }
        String pkg = clazz.getPackage().getName();
        ResourceBundle bundle = (ResourceBundle) bundles.get(pkg);
        if (bundle == null) {
            bundle = NbBundle.getBundle(clazz);
            bundles.put(pkg, bundle);
        }
        return bundle.getString(str);
    }
    
}
