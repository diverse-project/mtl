/*
 *                 Sun Public License Notice
 *
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 *
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrexplorer.looks.reflect;

import org.netbeans.modules.mdrexplorer.looks.reflect.properties.*;
import org.netbeans.modules.mdrexplorer.looks.reflect.actions.*;
import java.util.*;
import java.awt.*;
import javax.jmi.reflect.*;
import javax.jmi.model.*;
import org.netbeans.api.looks.*;
import org.netbeans.api.mdr.MDRObject;
import org.netbeans.api.mdr.MDRepository;
import org.openide.nodes.*;
import org.openide.util.actions.SystemAction;
import org.netbeans.modules.mdrexplorer.looks.DataRestWrapper;
import org.netbeans.modules.mdrexplorer.looks.reflect.actions.DeleteLinksAction;
/**
 *
 * @author  ms118741, Tomas Zezula
 * @version
 */
public class RefLinkEndWrapperLook extends BaseObjectLook {
    
    /** Creates new RefObjectLook */
    public RefLinkEndWrapperLook() {
        super(Utils.getLocalizedString("TXT_RefLinkEndWrapperLook"));
    }
    
    public String toString() {
        return "MOF/RefLinkEndWrapper::ALL"; // NOI18N
    }
    
    
    
    
    public String getName( Look.NodeSubstitute substitute ) {
        return Utils.getRefObjectName( ((RefLinkEndWrapper)substitute.getRepresentedObject()).getAssocEndInstance() );
    }
    
    public String getDisplayName(Look.NodeSubstitute substitute) {
        return this.getName(substitute);
    }
    
    public Object[] getChildObjects( Look.NodeSubstitute substitute ) {
        RefLinkEndWrapper lew = (RefLinkEndWrapper) substitute.getRepresentedObject();
        RefAssociation refAssoc = lew.getRefAssociation();
        RefObject endInstance = lew.getAssocEndInstance();
        AssociationEnd associationEnd = lew.getMetaAssociationEnd();
        boolean isFirstEnd = lew.isFirstEnd();
        MDRepository repo = ((MDRObject)refAssoc).repository ();
        repo.beginTrans (false);
        try {
            Collection otherEnds = refAssoc.refQuery(associationEnd,endInstance);
            int count = this.getBrowserChildCount();
            boolean[] completionFlag = new boolean[1];
            Collection result = Utils.getRefLinkOtherEndWrappers (otherEnds,endInstance,refAssoc,isFirstEnd,count,0,completionFlag);
            if (!completionFlag[0]) {
                result.add (new DataRestWrapper ( new Collection[] {otherEnds}, count, DataRestWrapper.ASSOC_OTHER_END, lew));
            }
            return result.toArray();
        }finally {
            repo.endTrans ();
        }
    }
    
    public javax.swing.Action[] getActions (Look.NodeSubstitute substitute) {
        javax.swing.Action[] superActions = super.getActions (substitute);
        javax.swing.Action[] actions = new javax.swing.Action [superActions.length + 1];
        actions[0] = SystemAction.get (DeleteLinksAction.class);
        System.arraycopy (superActions,0,actions,1,superActions.length);
        return actions;
    }
    
    public Node.PropertySet[] getPropertySets(Look.NodeSubstitute substitute) {
        return Utils.getAssocLinkEndPropertySets( ((RefLinkEndWrapper)substitute.getRepresentedObject()).getAssocEndInstance(), substitute );
    }
    
}
