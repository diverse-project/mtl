/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrexplorer.looks;

import java.util.*;
import java.lang.ref.Reference;
import java.lang.ref.WeakReference;
import java.lang.ref.ReferenceQueue;
import javax.jmi.reflect.RefPackage;
import org.openide.util.RequestProcessor;
import org.netbeans.api.mdr.MDRepository;
/**
 *
 * @author  ms118741, Tomas Zezula
 * @version 
 */
public class RepositoryCache {
    
    private static final int CLEANER_PERIOD = 5000;
    
    private static RepositoryCache repositoryCache;
    private HashMap objectNameCache;
    private HashMap eventHandlers;
    private ReferenceQueue refQueue;
    private RequestProcessor cleaner;
    
    private class CleanProcess implements Runnable {
        public void run () {
            Iterator handlers = null;
            synchronized (RepositoryCache.this) {
                if (RepositoryCache.this.eventHandlers != null)
                    handlers = ((HashMap)RepositoryCache.this.eventHandlers.clone()).values().iterator();
            }
            if (handlers != null) {
                while (handlers.hasNext()) {
                    Reference ref = (Reference) handlers.next();
                    MDREventHandler handler = (MDREventHandler) ref.get();
                    if (handler != null)
                        handler.flushReferenceQueue();
                }
            }
            
            synchronized (this) {
                if (RepositoryCache.this.refQueue.poll()!=null) {
                    Iterator valueIt = RepositoryCache.this.eventHandlers.values().iterator();
                    while (valueIt.hasNext()) {
                        if (((Reference)valueIt.next()).get() == null) {
                            valueIt.remove();
                            if (RepositoryCache.this.refQueue.poll() == null)
                                break;
                        }
                    }
                }
            }
            
            RepositoryCache.this.cleaner.postRequest (this,CLEANER_PERIOD,Thread.MIN_PRIORITY);
        }
    }
    
    /** Creates new RepositoryCache */
    private RepositoryCache() {
        this.refQueue = new ReferenceQueue ();
        this.cleaner = new RequestProcessor ();
        this.cleaner.post (new CleanProcess(),CLEANER_PERIOD,Thread.MIN_PRIORITY);
    }

    public static RepositoryCache getRepositoryCache() {
        if (repositoryCache == null) {
            repositoryCache = new RepositoryCache();
        }
        return repositoryCache;
    }
    
    public String getPackageName (RefPackage pkg) {
        return (String) this.getObjectNameCache().get (pkg);
    }
    
    public void addPackageName (RefPackage pkg, String name) {
       this.getObjectNameCache().put (pkg, name);
    }
    
    public Collection getPackages () {
        return ((HashMap)this.getObjectNameCache().clone()).values();
    }
    
    public Collection getPackageNames () {
        return ((HashMap)this.getObjectNameCache().clone()).keySet();
    }
    
    public synchronized MDREventHandler addRepository (MDRepository repository) {
        MDREventHandler handler = null;
        Reference ref = (Reference) this.getEventHandlers().get (repository);
        if (ref == null || ref.get() == null) {
            handler = new MDREventHandler (repository);
            this.eventHandlers.put (repository, new WeakReference (handler, this.refQueue));
        }
        else {
            handler = (MDREventHandler) ref.get();
        }
        return handler;
    }
    
    public synchronized void removeRepository (MDRepository repository) {
        this.getEventHandlers().remove (repository);
    }
    
    public synchronized MDREventHandler getEventHandler (MDRepository repository) {
        Reference ref = (Reference) this.getEventHandlers().get (repository);
        if (ref == null)
            return null;
        return (MDREventHandler) ref.get();
    }

    protected HashMap getObjectNameCache() {
        if (this.objectNameCache == null) {
            this.objectNameCache = new HashMap ();
        }
        return objectNameCache;
    }
    
    protected HashMap getEventHandlers () {
        if (this.eventHandlers == null) {
            this.eventHandlers = new HashMap ();
        }
        return this.eventHandlers;
    }
    
    
}
