/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrtoolkit.looks.reflect;

import org.netbeans.modules.mdrtoolkit.looks.reflect.*;
import org.netbeans.modules.mdrtoolkit.looks.reflect.actions.*;
import java.util.Collection;
import javax.jmi.reflect.*;
import javax.jmi.model.Association;
import java.util.*;


import org.openidex.nodes.looks.*;

/** Implements MOF models defaut view.
 *
 * @author  Petr Hrebejk
 */
public class RefAssociationLook extends AcceptorLook.Type {
   
    /** Creates new PackageProxy
     */
    public RefAssociationLook() {
        super( new Delegate(), RefAssociation.class, true );
    }
     
    public String toString() {
        return "MOF/AssociationProxy::ALL"; // NOI18N
    }
    
    private static class Delegate extends BaseObjectLook {
   
        public String getName( Look.NodeSubstitute substitute ) {
            RefAssociation ra = (RefAssociation)substitute.getRepresentedObject();
            return ((Association)ra.refMetaObject()).getName();
        }

        public Object[] getChildObjects( Look.NodeSubstitute substitute ) {
            ArrayList result = new ArrayList();
            RefAssociation refAssoc = (RefAssociation)substitute.getRepresentedObject();

            Association assoc = (Association)refAssoc.refMetaObject();
            List contents = assoc.getContents();
            javax.jmi.model.AssociationEnd assocEnd = null;
            for (Iterator it = contents.iterator(); it.hasNext(); ) {
                Object content = it.next();
                if (content instanceof javax.jmi.model.AssociationEnd) {
                    assocEnd = (javax.jmi.model.AssociationEnd) content;
                    result.add( new RefAssocWrapper( assocEnd, assoc, refAssoc, it.hasNext() ) );
                }
            }
            return result.toArray();
        }
    }
}
