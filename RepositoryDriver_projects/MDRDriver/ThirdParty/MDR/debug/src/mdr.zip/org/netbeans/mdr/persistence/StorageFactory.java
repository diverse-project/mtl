/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.mdr.persistence;

import java.util.Map;
/**
 * For any implementation of Storage, the constructor is something like
 * StorageImplementation(name). Different names represent different repositories.
 * The meaning of "name" is implementation-defined.  For btree it will be the
 * base of the file name.
 * This factory is used only to create instances of Storage. Methods to create and
 * delete physical resources for the Storage, open and close the Storage etc. are
 * defined in Storage interface.
 *
 * @author  pbuzek
 * @version
 */

public interface StorageFactory {

    /** Creates instance of class that implements Storage interface.
     * throws StorageException if the name is not valid name of a Storage
     */
    public Storage createStorage (Map properties) throws StorageException;

    /** Creates a NULL MOFID in the format used by this Storage 
     *  implementation
     */
    public MOFID createNullMOFID () throws StorageException;
}
