/*
 *                 Sun Public License Notice
 *
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 *
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.mdr.handlers.gen;

import java.util.*;
import java.io.*;

import org.netbeans.mdr.storagemodel.*;
import org.netbeans.mdr.util.*;
import javax.jmi.model.*;


class InstanceGenerator extends FeaturedGenerator {
    
    InstanceGenerator(String name, Class ifc, Class handler, StorableObject storable, Class custom) {
        super(name, ifc, handler, storable, custom);
    }

    protected String getConstructorDescriptor() {
        return "(Lorg/netbeans/mdr/storagemodel/StorableObject;)V";
    }
        
    protected MethodInfo[] generateMethods() throws IOException {
        try {
            ArrayList methods = new ArrayList();
            HashSet createdMethods = new HashSet();
	    methods.add(generateConstructor());
            for (Iterator it = new ContainsIterator(obj.getMetaObject()); it.hasNext();) {
                StorableObject element = (StorableObject) it.next();
                String elementName = (String) element.getAttribute(MOFConstants.SH_MODEL_MODEL_ELEMENT_NAME);
                String metaTypeName = (String) element.getMetaObject().getAttribute(MOFConstants.SH_MODEL_MODEL_ELEMENT_NAME);
                String substName = TagSupport.getSubstName(element, elementName, metaTypeName);
                if (metaTypeName.equals(MOFConstants.SH_MODEL_ATTRIBUTE)) {
                    VisibilityKind visibility = (VisibilityKind) element.getAttribute(MOFConstants.SH_MODEL_GENERALIZABLE_ELEMENT_VISIBILITY);
                    ScopeKind scope = (ScopeKind) element.getAttribute(MOFConstants.SH_MODEL_FEATURE_SCOPE);
                    if (visibility.equals(VisibilityKindEnum.PUBLIC_VIS) && scope.equals(ScopeKindEnum.INSTANCE_LEVEL)) {
                        String attrName = firstUpper(substName);
                        String attrTypeName = TagSupport.getDataTypeName(getAttrType(element));
                        MultiplicityType multiplicity = (MultiplicityType) element.getAttribute(MOFConstants.SH_MODEL_STRUCTURAL_FEATURE_MULTIPLICITY);
                        if (multiplicity.getUpper() == 1) {
                            String name;
                            String setterName;
                            if (attrTypeName.equals("java.lang.Boolean")) {
                                if (attrName.substring(0, 2).equals("Is")) name = firstLower(attrName);
                                else name = "is" + attrName;
                                setterName = "set" + name.substring(2);
                            } else {
                                name = "get" + attrName;
                                setterName = "set" + attrName;
                            }
                            String getterType = attrTypeName;
                            if (multiplicity.getLower() == 1)
                                getterType = getPrimitiveName(getterType);
                            String sign = name + getMethodDescriptor(new String[0], getterType);
                            if (!createdMethods.contains(sign)) {
                                methods.addAll(getFeatureMethod(name, new String[0], getterType, M_GET_NAME, M_GET_DESC, M_GET_TYPE, element, (StorableFeatured)obj, "_getAttribute"));
                                createdMethods.add(sign);
                            }
                            boolean changeable = ((Boolean) element.getAttribute(MOFConstants.SH_MODEL_STRUCTURAL_FEATURE_IS_CHANGEABLE)).booleanValue();
                            if (changeable) {
                                sign = setterName + getMethodDescriptor(new String[] {getterType}, "void");
                                if (!createdMethods.contains(sign)) {
                                    methods.addAll(getFeatureMethod(setterName, new String[] {getterType}, "void", M_SET_NAME, M_SET_DESC, M_SET_TYPE, element, (StorableFeatured)obj, "_setAttribute"));
                                    createdMethods.add(sign);
                                }
                            }
                        } else if (multiplicity.getUpper() != 0) {
                            String sign = "get" + attrName + getMethodDescriptor(new String[0], (multiplicity.isOrdered() ? DT_ORDERED : DT_MULTIVALUED));
                            if (!createdMethods.contains(sign)) {
                                methods.addAll(getFeatureMethod("get" + attrName, new String[0], (multiplicity.isOrdered() ? DT_ORDERED : DT_MULTIVALUED), M_GET_NAME, M_GET_DESC, M_GET_TYPE, element, (StorableFeatured)obj, "_getAttribute"));
                                createdMethods.add(sign);
                            }
                        }
                    }
                } else if (metaTypeName.equals(MOFConstants.SH_MODEL_OPERATION)) {
                    VisibilityKind visibility = (VisibilityKind) element.getAttribute(MOFConstants.SH_MODEL_GENERALIZABLE_ELEMENT_VISIBILITY);
                    if (visibility.equals(VisibilityKindEnum.PUBLIC_VIS)) {
                        Collection parameters = new ArrayList();
                        String operType = "void";
                        for (Iterator itt = ((List) element.getReference(MOFConstants.SH_MODEL_NAMESPACE_CONTENTS)).iterator(); itt.hasNext();) {
                            StorableObject el = (StorableObject) itt.next();
                            String mtName = (String) el.getMetaObject().getAttribute(MOFConstants.SH_MODEL_MODEL_ELEMENT_NAME);
                            if (mtName.equals(MOFConstants.SH_MODEL_PARAMETER)) {
                                DirectionKind direction = (DirectionKind) el.getAttribute(MOFConstants.SH_MODEL_PARAMETER_DIRECTION_KIND);
                                if (direction.equals(DirectionKindEnum.RETURN_DIR))
                                    operType = getAttrTypeName(el);
                                else
                                    parameters.add(getAttrTypeName(el) + (direction.equals(DirectionKindEnum.IN_DIR) ? "" : "[]"));
                            }
                        }
                        String[] prms = (String[])parameters.toArray(new String [parameters.size()]);
                        String sign = substName + getMethodDescriptor(prms, operType);
                        if (!createdMethods.contains(sign)) {
                            MethodInfo mInfo = getOperationMethod(substName, prms, operType, elementName);
                            Collection exceptions = (Collection) element.getReference(MOFConstants.SH_MODEL_OPERATION_EXCEPTIONS);
                            short[] declaredExceptions = new short[exceptions.size()];
                            int i = 0;
                            for (Iterator itt = exceptions.iterator(); itt.hasNext(); i++)
                                declaredExceptions[i] = cp.getClass(dotToSlash(TagSupport.getTypeFullName((StorableObject)itt.next())));
                            mInfo.setDeclaredExceptions(declaredExceptions);
                            methods.add(mInfo);
                            createdMethods.add(sign);
                        }
                    }
                } else if (metaTypeName.equals(MOFConstants.SH_MODEL_REFERENCE)) {
                    VisibilityKind visibility = (VisibilityKind) element.getAttribute(MOFConstants.SH_MODEL_GENERALIZABLE_ELEMENT_VISIBILITY);
                    if (visibility.equals(VisibilityKindEnum.PUBLIC_VIS)) {
                        String refName = firstUpper(substName);
                        String refType = TagSupport.getDataTypeName(getAttrType(element));
                        MultiplicityType multiplicity = (MultiplicityType) element.getAttribute(MOFConstants.SH_MODEL_STRUCTURAL_FEATURE_MULTIPLICITY);
                        if (multiplicity.getUpper() == 1) {
                            String sign = "get" + refName + getMethodDescriptor(new String[0], refType);
                            if (!createdMethods.contains(sign)) {
                                methods.addAll(getHandlerMethod("get" + refName, new String[0], refType, M_GET_NAME + "R", M_GET_DESC, M_GET_TYPE, elementName));
                                createdMethods.add(sign);
                            }
                            boolean changeable = ((Boolean) element.getAttribute(MOFConstants.SH_MODEL_STRUCTURAL_FEATURE_IS_CHANGEABLE)).booleanValue();
                            if (changeable) {
                                sign = "set" + refName + getMethodDescriptor(new String[] {refType}, "void");
                                if (!createdMethods.contains(sign)) {
                                    methods.addAll(getHandlerMethod("set" + refName, new String[] {refType}, "void", M_SET_NAME + "R", M_SET_DESC, M_SET_TYPE, elementName));
                                    createdMethods.add(sign);
                                }
                            }
                        } else if (multiplicity.getUpper() != 0) {
                            String sign = "get" + refName + getMethodDescriptor(new String[0], (multiplicity.isOrdered() ? DT_ORDERED : DT_MULTIVALUED));
                            if (!createdMethods.contains(sign)) {
                                methods.addAll(getHandlerMethod("get" + refName, new String[0], (multiplicity.isOrdered() ? DT_ORDERED : DT_MULTIVALUED), M_GET_NAME + "R", M_GET_DESC, M_GET_TYPE, elementName));
                                createdMethods.add(sign);
                            }
                        }
                    }
                }
            }
            
            MethodInfo[] mtds = super.generateMethods();
            for(int i = 0; i < mtds.length; i++)
                methods.add(mtds[i]);
            return (MethodInfo[]) methods.toArray(new MethodInfo[methods.size()]);
        }catch (Exception e) {
            throw (DebugException) Logger.getDefault().annotate(new DebugException(), e);
        }
    }
}
