/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrtoolkit.looks.reflect;

import org.netbeans.modules.mdrtoolkit.looks.reflect.*;
import org.netbeans.modules.mdrtoolkit.looks.reflect.actions.*;
import org.netbeans.modules.mdrtoolkit.looks.IconBaseSupport;

import java.awt.Image;

import javax.jmi.reflect.*;

import org.openide.util.actions.SystemAction;
import org.openide.util.SharedClassObject;

import org.openidex.nodes.looks.*;


/** Implements MOF models defaut view.
 *
 * @author  Martin Matula
 */
public class BaseObjectLook extends DefaultLook {

    private static final String PACKAGE_PROXY_ICON = 
        "/org/netbeans/modules/mdrtoolkit/looks/reflect/resources/packageproxy"; // NOI18N
    
    private static final String CLASS_PROXY_ICON = 
        "/org/netbeans/modules/mdrtoolkit/looks/reflect/resources/classproxy"; // NOI18N

    private static final String ASSOCIATION_PROXY_ICON = 
        "/org/netbeans/modules/mdrtoolkit/looks/reflect/resources/associationproxy"; // NOI18N
    
    private static final String ASSOCIATION_WRAPPER = 
        "/org/netbeans/modules/mdrtoolkit/looks/reflect/resources/associationMeta"; // NOI18N

    private static final String ASSOCIATION_END_ICON = 
        "/org/netbeans/modules/mdrtoolkit/looks/reflect/resources/associationEnd"; // NOI18N

    private static final String ASSOCIATION_OTHER_END_ICON = 
        "/org/netbeans/modules/mdrtoolkit/looks/reflect/resources/associationOtherEnd"; // NOI18N

    private static final String OBJECT_ICON = 
        "/org/netbeans/modules/mdrtoolkit/looks/reflect/resources/object"; // NOI18N

    private static final String REF_OBJECT_ICON = 
        "/org/netbeans/modules/mdrtoolkit/looks/reflect/resources/refobject"; // NOI18N

    private static final String ROOT_NODE_ICON = 
        "/org/netbeans/modules/mdrtoolkit/looks/reflect/resources/root"; // NOI18N

    public SystemAction[] getActions( Look.NodeSubstitute substitute ) {
        SystemAction[] actions = new SystemAction[1];
        actions[0] = (SystemAction)SharedClassObject.findObject( PropertiesAction.class, true );
        return actions;
    }
    
    public Image getIcon( Look.NodeSubstitute substitute, int type ) {
        Image result = IconBaseSupport.getIcon( OBJECT_ICON, type );
        Object ro = substitute.getRepresentedObject();
        if ( ro instanceof RefObject ) {
            result = IconBaseSupport.getIcon( REF_OBJECT_ICON, type );
        } else if ( ro instanceof RefPackage ) {
            result = IconBaseSupport.getIcon( PACKAGE_PROXY_ICON, type );
        } else if ( ro instanceof RefClass ) {
            result = IconBaseSupport.getIcon( CLASS_PROXY_ICON, type );
        } else if ( ro instanceof RefAssociation ) {
            result = IconBaseSupport.getIcon( ASSOCIATION_PROXY_ICON, type );
        } else if ( ro instanceof org.openide.TopManager ) {
            result = IconBaseSupport.getIcon( ROOT_NODE_ICON, type );
        } else if (ro instanceof RefAssocWrapper) {
            result = IconBaseSupport.getIcon( ASSOCIATION_WRAPPER, type );
        } else if (ro instanceof RefLinkEndWrapper) {
            result = IconBaseSupport.getIcon( ASSOCIATION_END_ICON, type );
        } else if (ro instanceof RefLinkOtherEndWrapper) {
            result = IconBaseSupport.getIcon( ASSOCIATION_OTHER_END_ICON, type );
        } else if (ro instanceof RefGetValueWrapper) {
            result = IconBaseSupport.getIcon( OBJECT_ICON, type );
        }
        return result;
    }
    
}
