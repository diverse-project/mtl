/*
 *                 Sun Public License Notice
 *
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 *
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */

package org.netbeans.modules.mdrexplorer.looks.reflect.actions;

import java.util.Iterator;
import java.util.Collection;
import javax.jmi.reflect.*;
import javax.jmi.model.*;
import org.netbeans.api.mdr.MDRepository;
import org.netbeans.api.mdr.MDRObject;
import org.openide.nodes.Node;
import org.openide.util.HelpCtx;
import org.openide.util.actions.NodeAction;
import org.netbeans.api.looks.*;
import org.netbeans.modules.mdrexplorer.looks.reflect.RefLinkEndWrapper;
import org.netbeans.modules.mdrexplorer.looks.reflect.Utils;
/**
 *
 * @author  Tomas Zezula
 */
public class DeleteLinksAction extends NodeAction {
    
    /** Creates a new instance of DeleteLinksAction */
    public DeleteLinksAction() {
    }
    
    /** Test whether the action should be enabled based
     * on the currently activated nodes.
     *
     * @param activatedNodes current activated nodes, may be empty but not <code>null</code>
     * @return <code>true</code> to be enabled, <code>false</code> to be disabled
     */
    protected boolean enable(Node[] nodes) {
        if (nodes == null)
            return false;
        for (int i=0; i< nodes.length; i++) {
            if (!(nodes[i] instanceof LookNode))
                return false;
            if (!(((LookNode)nodes[i]).getRepresentedObject() instanceof RefLinkEndWrapper))
                return false;
        }
        return true;
    }
    
    /** Get a help context for the action.
     * @return the help context for this action
     */
    public HelpCtx getHelpCtx() {
        return HelpCtx.DEFAULT_HELP;
    }
    
    /** Get a human presentable name of the action.
     * This may be
     * presented as an item in a menu.
     * <p>Using the normal menu presenters, an included ampersand
     * before a letter will be treated as the name of a mnemonic.
     * @return the name of the action
     */
    public String getName() {
        return Utils.getLocalizedString ("TXT_DeleteLinks");
    }
    
    /** Perform the action based on the currently activated nodes.
     * Note that if the source of the event triggering this action was itself
     * a node, that node will be the sole argument to this method, rather
     * than the activated nodes.
     *
     * @param activatedNodes current activated nodes, may be empty but not <code>null</code>
     */
    protected void performAction(Node[] nodes ) {
        for (int i=0; i< nodes.length; i++) {
            LookNode node = (LookNode) nodes[i];
            RefLinkEndWrapper ro = (RefLinkEndWrapper) node.getRepresentedObject();
            RefAssociation refAssoc = ro.getRefAssociation();
            MDRepository rep = ((MDRObject) refAssoc).repository();
            rep.beginTrans (true);
            try {
                Collection otherEnds = refAssoc.refQuery (ro.getMetaAssociationEnd(), ro.getAssocEndInstance());
                // Workaround of MDR bug in 0-1 cardinality association
                // the returned collection is not a live collection
                if (otherEnds.size () == 1) {
                    if (ro.isFirstEnd())
                        refAssoc.refRemoveLink (ro.getAssocEndInstance(),(RefObject)otherEnds.iterator().next());
                    else
                        refAssoc.refRemoveLink ((RefObject)otherEnds.iterator().next(),ro.getAssocEndInstance());
                }
                else {
                    for (Iterator it = otherEnds.iterator(); it.hasNext();) {
                        it.next ();
                        it.remove ();
                    }
                }
            }finally {
                rep.endTrans ();
            }
        }
    }
    
}
