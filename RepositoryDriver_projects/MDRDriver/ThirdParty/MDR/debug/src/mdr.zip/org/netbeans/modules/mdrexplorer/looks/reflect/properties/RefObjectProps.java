/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrexplorer.looks.reflect.properties;

import java.util.*;
import javax.jmi.reflect.*;
import org.netbeans.api.looks.*;
import java.beans.PropertyEditor;
import java.beans.PropertyEditorSupport;
import org.openide.nodes.*;
import org.netbeans.modules.mdrexplorer.looks.reflect.Utils;
/**
 *
 * @author  ms118741, Tomas Zezula
 * @version 
 */
public class RefObjectProps implements ReadWritePropertyIntf {

    private static final int IMMEDIATE_COMPOSITE = 0;
    private static final int OUTERMOST_COMPOSITE = 1;

    private boolean noValue;
    private RefObject refObject = null;
    private int propCode = IMMEDIATE_COMPOSITE;
    
    /** Creates new RefBaseObjectProps */
    private RefObjectProps(RefObject refObject, int propCode) {
        this.refObject = refObject;
        this.propCode = propCode;
    }

    public static Node.PropertySet[] getPropertySets(RefObject refObject) {
        try {
            Sheet.Set sheetSet = new Sheet.Set();
            sheetSet.setName(Utils.getLocalizedString(RefObjectProps.class,"TXT_META_PROPERTIES"));
            sheetSet.setDisplayName(Utils.getLocalizedString(RefObjectProps.class,"TXT_META_PROPERTIES"));
            sheetSet.put( LookPropertySupport.getProperty( new RefObjectProps(refObject, IMMEDIATE_COMPOSITE ) ) );
            sheetSet.put( LookPropertySupport.getProperty( new RefObjectProps(refObject, OUTERMOST_COMPOSITE ) ) );
            return new Node.PropertySet[] { sheetSet };
        }catch (Exception exception) {
            //Has to be catched because of bug in the looks implementation
            //the look is asked on the property set even on deleted node
            return new Node.PropertySet[0];
        }
    }
    
    public String getPropertyName() {
        String result = null;
        switch (propCode) {
            case IMMEDIATE_COMPOSITE :  {
                result = Utils.getLocalizedString(RefObjectProps.class,"TXT_PROP_IMMEDIATE_COMPOSITE");
                break;
            }
            case OUTERMOST_COMPOSITE :  {
                result = Utils.getLocalizedString(RefObjectProps.class,"TXT_PROP_OUTERMOST_COMPOSITE");
                break;
            }
        }
        return result;
    }
    
    public String getPropertyDesc() {
        return getPropertyName();
    }
    
    public Class getPropertyClass() {
        return String.class;
    }
    
    public boolean isReadOnly () {
        return true;
    }

    public Object getValue() {
        Object result = null;
        switch (propCode) {
            case IMMEDIATE_COMPOSITE :  {
                RefFeatured imp = refObject.refImmediateComposite();
                if (imp != null) {
                    result = imp.refMofId();
                }
                break;
            }
            case OUTERMOST_COMPOSITE :  {
                RefFeatured omp = refObject.refOutermostComposite();
                if (omp != null) {
                    result = omp.refMofId();
                }
                break;
            }
        }
        if (result == null) {
            result = Utils.getLocalizedString(RefObjectProps.class,"TXT_NO_VALUE");
            this.noValue = true;
        }
        return result;
    }
    
    public void setValue(Object value) {
    }
    
    public boolean hasPropertyEditor() {
        return false;
    }

    public java.beans.PropertyEditor getPropertyEditor () {
        return null;
    }
    
    public RefBaseObject getNavigableObject() {
        RefBaseObject result = null;
        switch (propCode) {
            case IMMEDIATE_COMPOSITE :  {
                result = refObject.refImmediateComposite();
                break;
            }
            case OUTERMOST_COMPOSITE :  {
                result = refObject.refOutermostComposite();
                break;
            }
        }
        return result;
    }
    
}
