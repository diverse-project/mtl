/*
 *                 Sun Public License Notice
 *
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 *
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */

package org.netbeans.modules.mdrexplorer.looks;

import java.lang.ref.Reference;
import java.lang.ref.WeakReference;
import java.lang.ref.ReferenceQueue;
import java.util.HashMap;
import java.util.Iterator;
import javax.jmi.reflect.RefBaseObject;
import javax.jmi.reflect.RefObject;
import javax.jmi.reflect.RefClass;
import org.netbeans.api.mdr.*;
import org.netbeans.api.mdr.events.*;
import org.netbeans.api.looks.Look;

/**
 * Instances of <code>MDREventHandler</code> are event handlers which listen
 * on repository changes on behalf of {@link org.netbeans.api.looks.LookNodeSubstitutes
 * node substitutes}. They manage a map from repository objects to node substitutes
 * to be able to access the node substitute for a given repository object. Looks
 * have to register their node subsitutes by calling {@link #addNodeSubstitute(Look.NodeSubstitute)}
 * or {@link #addNodeSubstitute(Object, Look.NodeSubstitute)} from within
 * {@link org.netbeans.api.looks.Look#attachTo(ook.NodeSubstitute)}.
 *
 * @deprecated register NodeSubstitutes directly on repository objects instead, see
 *     <a href="http://mdr.netbeans.org/issues/show_bug.cgi?id=25186">issue 25186</a>
 * @author  Tomas Zezula
 */
public class MDREventHandler implements MDRPreChangeListener {
    
    /* --------------------------------------------------------------------- */
    /* -- Attributes ------------------------------------------------------- */
    /* --------------------------------------------------------------------- */

    /**
     * Maps repository content to node substitutes.
     */
    private HashMap registeredNodeSubstitutes;
    
    /**
     * Map storing the parents of objects to be deleted. After an object has
     * been deleted, its parent node is not accessible any more. Nevertheless it
     * must be refreshed to reflect the deletion of the node representing the object.
     * Hence the parents of the objects to be deleted are stored in the map.
     */
    private HashMap pendingEvents;
    private ReferenceQueue queue;
    private MDRepository repository;
    
    /* --------------------------------------------------------------------- */
    /* -- Constructor ------------------------------------------------------ */
    /* --------------------------------------------------------------------- */
    
    public MDREventHandler  (MDRepository repository) {
        this.queue = new ReferenceQueue();
        this.registeredNodeSubstitutes = new HashMap();
        this.pendingEvents = new HashMap();
        this.repository = repository;
        this.repository.addListener(this, MDRChangeEvent.EVENTMASK_ALL);
    }
    
    /* --------------------------------------------------------------------- */
    /* -- Keys for Event Sources ------------------------------------------- */
    /* --------------------------------------------------------------------- */
    
        /** If the object has a MOF-ID, we use it as the key. Otherwise, we
         *  use the object itself
         */
    private Object getKey(Object object) {
        return object instanceof RefBaseObject
            ? ((RefBaseObject) object).refMofId()
            : object;
    }
    
    /* --------------------------------------------------------------------- */
    /* -- Management of NodeSubstitutes ------------------------------------ */
    /* --------------------------------------------------------------------- */
    
    public synchronized void addNodeSubstitute(Look.NodeSubstitute substitute) {
        if (substitute == null)
            return;
        this.addNodeSubstitute(substitute.getRepresentedObject(),substitute);
    }
    
    public synchronized void addNodeSubstitute(Object key, Look.NodeSubstitute substitute) {
        if (substitute == null || substitute.getRepresentedObject() == null)
            return;
        this.registeredNodeSubstitutes.put(getKey(key), new WeakReference(substitute,this.queue));
    }
    
    private synchronized Look.NodeSubstitute getNodeSubstituteForObject(Object object) {
        if (object ==null)
            return null;
        Reference ref = (Reference) this.registeredNodeSubstitutes.get(getKey(object));
        if (ref == null) {
            return null; // Not registered object
        }
        Look.NodeSubstitute substitute = (Look.NodeSubstitute) ref.get();
        return substitute;
    }
    
    /* --------------------------------------------------------------------- */
    /* -- Implements org.netbeans.api.mdr.MDRPreChangeListener ------------- */
    /* --------------------------------------------------------------------- */
    
    private void addPendingEvent(MDRChangeEvent e, Object info) {
        pendingEvents.put(getKey(e.getSource()), info);
    }
    
    private Object removePendingEvent(MDRChangeEvent e) {
        return pendingEvents.remove(getKey(e.getSource()));
    }
    
    private Object getPendingEventInfo(MDRChangeEvent e) {
        return pendingEvents.get(getKey(e.getSource()));
    }
    
    /**
     * Handles deletion events only. Stores the parents of objects to be deleted.
     * This is necessary to refresh parent nodes when the object to be deleted
     * has been deleted.
     */
    public void plannedChange(MDRChangeEvent e) {
        if ((e.getType() & ExtentEvent.EVENT_EXTENT_DELETE) == ExtentEvent.EVENT_EXTENT_DELETE) {
            //Destroy
            RefBaseObject source = (RefBaseObject) e.getSource();
            Object parent = source.refImmediatePackage();
            if (parent == null)
                parent = this.repository;
            addPendingEvent(e, parent);
        }
        else if ((e.getType() & InstanceEvent.EVENT_INSTANCE_DELETE) == InstanceEvent.EVENT_INSTANCE_DELETE) {
            //Destroy
            RefObject source = (RefObject) e.getSource();
            Object clazz = source.refClass();
            Object container = null;
            if (source instanceof javax.jmi.model.ModelElement) {
                // We are in MOF instance
                container = ((javax.jmi.model.ModelElement)source).getContainer();
                if (container == null)
                    container = source.refImmediatePackage();
            }
            addPendingEvent(e, new Object[] {clazz, container});
        }
    }
    
    /**
     * Removes the information stored for the pending event <code>e</code>.
     * @see #plannedChange(MDRChangeEvent)
     */
    public void changeCancelled(MDRChangeEvent e) {
        if ((e.getType() & 2) == 2) {
            removePendingEvent(e);
        }
    }

    /**
     * Refreshes the nodes affected by <code>e</code>.
     */
    public void change(MDRChangeEvent e) {
        if ((e.getType() & ExtentEvent.EVENT_EXTENT_CREATE) == ExtentEvent.EVENT_EXTENT_CREATE) {
            // Created
            Look.NodeSubstitute substitute = this.getNodeSubstituteForObject(e.getSource());
            if (substitute != null) {
                substitute.refreshChildren();
            }
        }
        else if ((e.getType() & ExtentEvent.EVENT_EXTENT_DELETE) == ExtentEvent.EVENT_EXTENT_DELETE) {
            // Removed
            Look.NodeSubstitute substitute = this.getNodeSubstituteForObject(getPendingEventInfo(e));
            if (substitute != null) {
                substitute.refreshChildren();
            }
        }
        if ((e.getType() & InstanceEvent.EVENT_INSTANCE_CREATE) == InstanceEvent.EVENT_INSTANCE_CREATE) {
            // Created
            Look.NodeSubstitute substitute = this.getNodeSubstituteForObject(e.getSource());
            if (substitute != null) {
                substitute.refreshChildren();
            }
            RefObject instance = ((InstanceEvent)e).getInstance();
            if (instance instanceof javax.jmi.model.ModelElement) {
                // We are in MOF instance
                Object container = ((javax.jmi.model.ModelElement)instance).getContainer();
                if (container == null)
                    container = instance.refImmediatePackage();
                substitute = this.getNodeSubstituteForObject (container);
                if (substitute != null) {
                    substitute.refreshChildren();
                }
            }
        }
        else if ((e.getType() & InstanceEvent.EVENT_INSTANCE_DELETE) == InstanceEvent.EVENT_INSTANCE_DELETE) {
            // Removed
            Object[] context = (Object[]) getPendingEventInfo(e);
            Look.NodeSubstitute substitute = this.getNodeSubstituteForObject(context[0]);
            if (substitute != null) {
                substitute.refreshChildren();
            }
            substitute = this.getNodeSubstituteForObject (context[1]);
            if (substitute != null) {
                substitute.refreshChildren();
            }
        }
        else if (e instanceof AssociationEvent) {
            Look.NodeSubstitute substitute = this.getNodeSubstituteForObject(e.getSource());
            if (substitute != null) {
                substitute.refreshChildren();
            }
        }
    }
    
    /* --------------------------------------------------------------------- */
    /* -- Clean-up dangling map entries ------------------------------------ */
    /* --------------------------------------------------------------------- */
    
    /**
     * Removes entries with garbage collected values from the map associating
     * repository objects with node substitutes.
     */
    synchronized void flushReferenceQueue() {
        if (this.queue.poll()!=null) {
            Iterator values = this.registeredNodeSubstitutes.values().iterator();
            while (values.hasNext()) {
                if (((Reference)values.next()).get() == null) {
                    values.remove();
                    if (this.queue.poll() == null)
                        return;
                }
            }
        }
    }
    
    
    
}
