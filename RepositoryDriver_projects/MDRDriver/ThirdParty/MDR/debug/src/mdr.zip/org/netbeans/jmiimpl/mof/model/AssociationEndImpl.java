/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.jmiimpl.mof.model;

import java.util.*;
import javax.jmi.model.*;
import javax.jmi.reflect.*;

import org.netbeans.mdr.handlers.InstanceHandler;
import org.netbeans.mdr.storagemodel.StorableObject;
import org.netbeans.mdr.util.*;


/**
 * Implements MOF operations
 *
 * @author mmatula
 */
public abstract class AssociationEndImpl extends ModelElementImpl implements AssociationEnd {
    protected AssociationEndImpl(StorableObject storable) {
        super(storable);
    }

    public AssociationEnd otherEnd() {
        Collection elements = this.getContainer().getContents();
        Object element;

        for (Iterator it = elements.iterator(); it.hasNext();) {
            element = it.next();
            if (element instanceof AssociationEnd && !element.equals(this)) {
                return (AssociationEnd) element;
            }
        }

        return null;
    }

    // --- derived attributes

}
