/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.mdrshell;

import java.util.Collection;
import java.util.Iterator;
import java.io.PrintStream;

/** Helper singleton for StringBuffer
 *
 * @author  Petr Hrebejk        
 * @version 
 */

class Support {

    /** Support is a singleton.
    */
    private Support() {
    }
    
    /** Aligns the StringBuffer to length given by position
    */
    public static void ensurePosition( StringBuffer sb, int position ) {

        if ( sb.length() < position ) {
            
            while ( sb.length() < position ) {
                sb.append( " " );
            }
        }
        else if ( sb.length() > position ) {
            sb.setLength( position );
        }
    }
    
    
    /** Default print function for results of commands. 
    */
    public static void defaultPrint( PrintStream ps, Object object ) {
        defaultPrint( ps, 0, object );
    }
    
    /** Default print function for results of commands at given position on
    * line.
    */
    public static void defaultPrint( PrintStream ps, int offset, Object object ) {
        
        if ( object == null ) {
            ps.println("null");
            return;
        }

        if ( object instanceof java.util.Iterator ) {
            printIndent( ps, offset );
            ps.print( "ITERATOR : {" );
            for( Iterator it = (Iterator)object; it.hasNext(); ) {
                defaultPrint( ps, offset + 2, it.next() );
            }
            ps.println();
            printIndent( ps, offset );
            ps.println( "} // end of ITERATOR" );
        }
        else if ( object.getClass().isArray() ) {
            printIndent( ps, offset );
            ps.print( "ARRAY : [" );
            for ( int i = 0; i < java.lang.reflect.Array.getLength( object ); i++ ) {
                //printIndent( ps, offset );
                defaultPrint( ps, offset + 2, java.lang.reflect.Array.get( object, i ) );
                //ps.println( java.lang.reflect.Array.get( object, i ).toString() );
            }
            ps.println();
            printIndent( ps, offset );
            ps.println( "] // end of ARRAY" );    
        }
        else if ( object instanceof Throwable ) {
            ((Throwable)object).printStackTrace();
        }
        else if ( object instanceof Collection  ) {
            printIndent( ps, offset );
            ps.print( "COLLECTION : {" );
            for( Iterator it = ((Collection)object).iterator(); it.hasNext(); ) {
                defaultPrint( ps, offset + 2, it.next() );
            }
            ps.println();
            printIndent( ps, offset );
            ps.println( "} // end of COLLECTION" );
        }
        else {
            printIndent( ps, offset );
            ps.println( object.toString() );
        }
        
    }

    
    private static void printIndent( PrintStream ps, int indent ) {
        for( ; indent > 0; indent -- ) {
            ps.print( " " );
        }
    }
    
}
