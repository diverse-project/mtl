/*
 *                 Sun Public License Notice
 *
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 *
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrexplorer.looks.reflect.actions;

import org.netbeans.modules.mdrexplorer.looks.reflect.*;

import org.openide.TopManager;
import org.openide.nodes.Node;
import org.openide.util.*;
import org.openide.util.actions.NodeAction;
import org.openide.filesystems.FileSystem;
import org.openide.filesystems.FileObject;
import org.openide.loaders.*;

import org.netbeans.api.looks.*;

import javax.jmi.reflect.*;
import org.netbeans.api.mdr.*;
import org.netbeans.modules.jmitoolkit.FSSFImpl;

import java.util.ResourceBundle;

/** Action sensitive to the node selection that does something useful.
 *
 * @author  Martin Matula
 */
public class Map2JavaAction extends NodeAction {
    
    /** Resource bundle */
    private static final ResourceBundle bundle = NbBundle.getBundle(Utils.class);
    
    protected void performAction(Node[] nodes) {
        generateInterfaces(nodes);
    }
    
    private void generateInterfaces(final Node[] nodes) {
        final TopManager tm = TopManager.getDefault();
        final FileSystem targetFS;
        
        try {
            // selects one folder from data systems
            DataFolder df = (DataFolder)tm.getNodeOperation().select(
            bundle.getString("CTL_GenerateInterfaces"),
            bundle.getString("CTL_SaveIn"),
            tm.getPlaces().nodes().repository(new FolderFilter())
            ).getCookie(DataFolder.class);
            targetFS = df.getPrimaryFile().getFileSystem();
        } catch (org.openide.util.UserCancelException ex) {
            return;
        } catch (java.lang.Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e + ": " + e.getMessage());
        }
        
        // map the interfaces in a background thread
        RequestProcessor.postRequest(new Runnable() {
            public void run() {
                tm.setStatusText(bundle.getString("CTL_GenerationStarted"));
                JMIMapper mapper = JMIMapper.getDefault();
                for (int i=0; i< nodes.length; i++) {
                    MDRObject object = (MDRObject) ((LookNode)nodes[i]).getRepresentedObject();
                    MDRepository rep = object.repository();
                    rep.beginTrans(false);
                    try {
                        mapper.generate(new FSSFImpl(targetFS), object);
                    } catch (java.io.IOException e) {
                        TopManager.getDefault().notifyException(e);
                    } finally {
                        rep.endTrans();
                    }
                }
                tm.setStatusText(bundle.getString("CTL_GenerationFinished"));
            }
        });
    }
    
    protected boolean enable(Node[] nodes) {
        if (nodes == null)
            return false;
        for (int i=0; i< nodes.length; i++) {
            if (!(nodes[i] instanceof LookNode))
                return false;
            Object ro = ((LookNode)nodes[i]).getRepresentedObject();
            if (!(ro instanceof RefObject || ro instanceof RefPackage))
                return false;
            if (!(((RefBaseObject)ro).refOutermostPackage() instanceof javax.jmi.model.ModelPackage))
                return false;
        }
        return true;
    }
    
    public String getName() {
        return bundle.getString("CTL_ACTION_Map2Java");
    }
    
    protected String iconResource() {
        return null;
    }
    
    public HelpCtx getHelpCtx() {
        return HelpCtx.DEFAULT_HELP;
        // If you will provide context help then use:
        // return new HelpCtx (GenerateInterfacesActionAction.class);
    }
    
    /** Perform extra initialization of this action's singleton.
     * PLEASE do not use constructors for this purpose!
     * protected void initialize () {
     * super.initialize ();
     * putProperty ("someProp", value);
     * }
     */
    
    /** Filter for Generate Interfaces into operation, accepts folders. */
    private static final class FolderFilter implements DataFilter {
        public boolean acceptDataObject(DataObject obj) {
            return "".equals(obj.getName());
        }
    }
}
