/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrtoolkit.looks.reflect.actions;

import org.netbeans.modules.mdrtoolkit.looks.reflect.*;

import org.openide.TopManager;
import org.openide.nodes.Node;
import org.openide.util.*;
import org.openide.util.actions.NodeAction;
import org.openide.filesystems.FileSystem;
import org.openide.filesystems.FileObject;
import org.openide.loaders.*;

import org.openidex.nodes.looks.*;

import javax.jmi.reflect.*;
import org.netbeans.api.mdr.*;
import org.netbeans.modules.jmitoolkit.FSSFImpl;

import java.util.ResourceBundle;

/** Action sensitive to the node selection that does something useful.
 *
 * @author  Martin Matula
 */
public class Map2JavaAction extends NodeAction {

    /** Resource bundle */
    private static final ResourceBundle bundle = NbBundle.getBundle(Utils.class);

    protected void performAction (Node[] nodes) {
        final Node node = nodes[0];
        if ( (node instanceof LookNode) && 
              ((((LookNode)node).getRepresentedObject() instanceof RefPackage) ||
                (((LookNode)node).getRepresentedObject() instanceof RefObject) ) ) {
            generateInterfaces( (LookNode)node );
        } else {
            System.out.println("Unable to generate interfaces.");
        }
    }

    private void generateInterfaces(LookNode lookNode) {
        final LookNode node = lookNode;
        final TopManager tm = TopManager.getDefault();
        final FileSystem targetFS;

        try {
            // selects one folder from data systems
            DataFolder df = (DataFolder)tm.getNodeOperation().select(
                                bundle.getString ("CTL_GenerateInterfaces"),
                                bundle.getString ("CTL_SaveIn"),
                                tm.getPlaces().nodes().repository(new FolderFilter())
                            ).getCookie(DataFolder.class);
            targetFS = df.getPrimaryFile().getFileSystem();
        } catch (org.openide.util.UserCancelException ex) {
            return;
        } catch (java.lang.Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e + ": " + e.getMessage());
        }
        
        // map the interfaces in a background thread
        RequestProcessor.postRequest(new Runnable() {
            public void run() {
                MDRObject object = (MDRObject) node.getRepresentedObject();
                MDRepository rep = object.repository();
                tm.setStatusText(bundle.getString("CTL_GenerationStarted"));
                JMIMapper mapper = JMIMapper.getDefault();
                try {
                    rep.beginTrans(false);
                    mapper.generate(new FSSFImpl(targetFS), object);
                } catch (java.io.IOException e) {
                    TopManager.getDefault().notifyException(e);
                } finally {
                    rep.endTrans();
                    tm.setStatusText(bundle.getString("CTL_GenerationFinished"));
                }
            }
        });
    }

    protected boolean enable (Node[] nodes) {
        if (nodes.length == 1 && nodes[0] instanceof LookNode ) {
            
           Object ro = ((LookNode)nodes[0]).getRepresentedObject();
          
           if ( ro instanceof RefBaseObject ) {
                
                if (ro instanceof RefAssociation) {
                    return false;
                } else {
                    return ((RefBaseObject)ro).refOutermostPackage() instanceof javax.jmi.model.ModelPackage;
                }
            }
            
        }
        
        return false;
    }

    public String getName () {
        return bundle.getString("CTL_ACTION_Map2Java");
    }

    protected String iconResource () {
        return null;
    }

    public HelpCtx getHelpCtx () {
        return HelpCtx.DEFAULT_HELP;
        // If you will provide context help then use:
        // return new HelpCtx (GenerateInterfacesActionAction.class);
    }

    /** Perform extra initialization of this action's singleton.
     * PLEASE do not use constructors for this purpose!
    protected void initialize () {
	super.initialize ();
	putProperty ("someProp", value);
    }
    */

    /** Filter for Generate Interfaces into operation, accepts folders. */
    private static final class FolderFilter implements DataFilter {
        public boolean acceptDataObject (DataObject obj) {
            return "".equals(obj.getName());
        }
    }
}
