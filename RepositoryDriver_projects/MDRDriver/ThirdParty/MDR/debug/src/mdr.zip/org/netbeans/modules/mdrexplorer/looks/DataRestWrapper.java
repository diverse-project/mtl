/*
 *                 Sun Public License Notice
 *
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 *
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */

package org.netbeans.modules.mdrexplorer.looks;

import java.util.Collection;
/**
 *
 * @author  Tomas Zezula
 */
public class DataRestWrapper {
    
    public static final int DIRECT          = 0;
    public static final int ATTRIBUTES      = 1;
    public static final int REFERENCES      = 2;
    public static final int ASSOC_END       = 3;
    public static final int ASSOC_OTHER_END = 4;
    
    private Collection[] collection;
    private int offset;
    private int mode;
    private Object data;
    
    /** Creates a new instance of DataRestWrapper */
    public DataRestWrapper (Collection[] collection, int offset) {
        this (collection, offset, DIRECT,null);
    }
    
    public DataRestWrapper (Collection[] collection, int offset, int mode) {
        this (collection, offset, mode, null);
    }
    
    public DataRestWrapper (Collection[] collection, int offset, int mode, Object data) {
        this.mode = mode;
        this.collection = collection;
        this.offset = offset;
        this.data = data;
    }
    
    public Collection[] getCollections () {
        return this.collection;
    }
    
    public int getOffset () {
        return this.offset;
    }
    
    public int getMode () {
        return this.mode;
    }
    
    public Object getData () {
        return this.data;
    }
    
}
