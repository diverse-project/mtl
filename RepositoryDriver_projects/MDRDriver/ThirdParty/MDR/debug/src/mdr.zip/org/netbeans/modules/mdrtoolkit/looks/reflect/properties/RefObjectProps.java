/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrtoolkit.looks.reflect.properties;

import java.util.*;
import java.awt.*;
import javax.jmi.reflect.*;

import org.openide.util.actions.SystemAction;
import org.openide.util.SharedClassObject;

import org.openidex.nodes.looks.*;

import java.beans.PropertyEditor;
import java.beans.PropertyEditorSupport;
import org.openide.nodes.*;
/**
 *
 * @author  ms118741
 * @version 
 */
public class RefObjectProps implements ReadWritePropertyIntf {

    private static final String META_PROPERTIES = "Meta properties";
    private static final int IMMEDIATE_COMPOSITE = 0;
    private static final int OUTERMOST_COMPOSITE = 1;

    private static final String PROP_IMMEDIATE_COMPOSITE = "Immediate composite";
    private static final String PROP_OUTERMOST_COMPOSITE = "Outermost composite";

    private RefObject refObject = null;
    private int propCode = IMMEDIATE_COMPOSITE;
    /** Creates new RefBaseObjectProps */
    private RefObjectProps(RefObject refObject, int propCode) {
        this.refObject = refObject;
        this.propCode = propCode;
    }

    public static Node.PropertySet[] getPropertySets(RefObject refObject) {
        Node.PropertySet[] result = Look.NO_PROPERTY_SETS;
        ArrayList sheetSets = new ArrayList();
        sheetSets.addAll( LookPropertySupport.getPropertySets( new RefObjectProps(refObject, IMMEDIATE_COMPOSITE ) ) );
        sheetSets.addAll( LookPropertySupport.getPropertySets( new RefObjectProps(refObject, OUTERMOST_COMPOSITE ) ) );

        result = new  Node.PropertySet[ sheetSets.size() ];
        System.arraycopy( sheetSets.toArray(), 0, result, 0, sheetSets.size() );
        return result;
    }
    
    public String getSheetName() {
        return META_PROPERTIES;
    }
    
    
    public String getPropertyName() {
        String result = null;
        switch (propCode) {
            case IMMEDIATE_COMPOSITE :  {
                result = PROP_IMMEDIATE_COMPOSITE;
                break;
            }
            case OUTERMOST_COMPOSITE :  {
                result = PROP_OUTERMOST_COMPOSITE;
                break;
            }
        }
        return result;
    }
    
    public String getPropertyDesc() {
        return getPropertyName();
    }
    
    public Class getPropertyClass() {
        return String.class;
    }

    public Object getValue() {
        Object result = null;
        switch (propCode) {
            case IMMEDIATE_COMPOSITE :  {
                RefFeatured imp = refObject.refImmediateComposite();
                if (imp != null) {
                    result = imp.refMofId();
                }
                break;
            }
            case OUTERMOST_COMPOSITE :  {
                RefFeatured omp = refObject.refOutermostComposite();
                if (omp != null) {
                    result = omp.refMofId();
                }
                break;
            }
        }
        if (result == null) {
            result = LookPropertySupport.NO_VALUE;
        }
        return result;
    }
    
    public void setValue(Object value) {
    }

    // * * * * * *      EDITOR       * * * * * * * * 
    public String getAsTextEditor() {
        return getValue().toString();
    }
    
    public boolean isPropertyEditor() {
        return false;
    }

    public void setValueEditor(Object value) {
    }
    
    public void setAsTextEditor(String string) {
    }
    public Object getValueEditor() {
        return getValue();
    }
    public String[] getTagsEditor() {
        return null;
    }
    public boolean supportsCustomEditor() {
        boolean result = true;
        if (LookPropertySupport.NO_VALUE.equals( getValue() )) {
            result = false;
        }
        return result;
    }
    public RefBaseObject getNavigableObject() {
        RefBaseObject result = null;
        switch (propCode) {
            case IMMEDIATE_COMPOSITE :  {
                result = refObject.refImmediateComposite();
                break;
            }
            case OUTERMOST_COMPOSITE :  {
                result = refObject.refOutermostComposite();
                break;
            }
        }
        return result;
    }
}
