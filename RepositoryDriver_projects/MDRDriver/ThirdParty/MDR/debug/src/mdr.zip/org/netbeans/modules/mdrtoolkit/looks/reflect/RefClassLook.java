/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrtoolkit.looks.reflect;

import java.util.Collection;
import javax.jmi.reflect.*;
import javax.jmi.model.MofClass;

import org.openidex.nodes.looks.*;

import java.awt.*;

/** Implements MOF models defaut view.
 *
 * @author  Petr Hrebejk
 */
public class RefClassLook extends AcceptorLook.Type {
       
    /** Creates new ClassProxyLook
     */
    public RefClassLook() {
        super( new Delegate(), RefClass.class, true );
    }
    
    public String toString() {
        return "MOF/ClassProxy::ALL"; // NOI18N
    }

    private static class Delegate extends BaseObjectLook {
   
        public String getName( Look.NodeSubstitute substitute ) {
            RefClass rc = (RefClass)substitute.getRepresentedObject();
            return ((MofClass)rc.refMetaObject()).getName();
        }

        public Object[] getChildObjects( Look.NodeSubstitute substitute ) {
            RefClass rc = (RefClass)substitute.getRepresentedObject();

            Collection objs = rc.refAllOfClass();
        
            Object[] children = new Object[ objs.size() ];
            objs.toArray( children );

            return children;
        }
        
    }
}
