/*
 *                 Sun Public License Notice
 *
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 *
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */

package org.netbeans.modules.mdrexplorer.looks;

import java.util.ResourceBundle;
import org.openide.util.NbBundle;
import org.netbeans.api.looks.*;
import org.netbeans.spi.looks.*;
/**
 *
 * @author  Tomas Zezula
 */
public abstract class AbstractNamespaceLook extends NamespaceLook {
    
    private ResourceBundle bundle;
    
    /** Creates a new instance of ReflectiveNamespaceLook */
    public AbstractNamespaceLook (String prefix) {
        super (prefix);
    }
    
    /** The human presentable name of the look.
     * @return human presentable name
     */
    public String getDisplayName() {
        return this.getName ();
    }
    
    final protected String getLocalizedString (String message) {
        if (this.bundle == null)
            this.initBundle ();
        return this.bundle.getString (message);
    }
    
    private void initBundle () {
        this.bundle = NbBundle.getBundle (ReflectiveNamespaceLook.class);
    }
    
}
