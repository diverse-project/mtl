/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.mdr.persistence.btreeimpl.btreestorage;

import java.io.*;
import java.util.*;

/** This is an extent which is part of a record which has been deleted,
* and is available for reuse
*/
class DeletedBtreeExtent extends BtreeExtent {

    /** Create a new DeletedBtreeExtent
    * @param file the BtreeDataFile this extent will belong to
    * @param chunkNum where this extent begins
    * @param numChunks the size of the extent
    */
    DeletedBtreeExtent(BtreeDataFile file, int chunkNum, short numChunks) {
        super(file, chunkNum, numChunks);
    }

    /** Convert an active extent to a deleted one when a record is
    * deleted
    * @param extent the extent being deleted
    */
    DeletedBtreeExtent(ActiveBtreeExtent extent) {
        super(extent);
        headerIsDirty = true;
        owner.deleteExtent(this);
    }
        
    /** read type-specific header data.  A no-op, since DeletedBtreeExtents
    * have none.
    * @param buffer the buffer to read from
    * @param offset the offset to being reading at
    */
    void readHeaderFromPage(byte buffer[], IntHolder offset) {
        // we have no type-specific data
    }

    /** Get the magic number for this type of extent
    * @return the magic number
    */
    short getMagic() {
        return DELETED_MAGIC;
    }

    /** write the type-specific part of the header.  A no-op, since 
    * DeletedBtreeExtents have none.
    * @param page the page to write to
    * @param offset the offset to begin an
    */
    void writeHeaderToPage(CachedPage page, int offset) {
        // we have no type-specific data
    }

    /** return type of extent
    * @return IS_DELETED
    */
    byte getType() {
        return IS_DELETED;
    }

    /** return name of type of extent
    * @return DELETED_NAME
    */
    String getTypeName() {
        return DELETED_NAME;
    }
}
