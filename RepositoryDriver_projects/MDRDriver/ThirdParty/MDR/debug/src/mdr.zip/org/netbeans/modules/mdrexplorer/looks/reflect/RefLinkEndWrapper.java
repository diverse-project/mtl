/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrexplorer.looks.reflect;


import java.util.*;
import java.awt.*;
import javax.jmi.reflect.*;
import javax.jmi.model.*;

/**
 *
 * @author  ms118741, Tomas Zezula
 * @version 
 */
public class RefLinkEndWrapper {

    private RefObject assocEndInstance = null;
    private RefAssociation refAssoc = null;
    private AssociationEnd metaAssocEnd = null;
    private boolean firstEndFlag;
   

    /** Creates new RefLinkWrapper */
    public RefLinkEndWrapper(RefObject assocEndInstance, RefAssociation refAssoc, AssociationEnd metaAssocEnd, boolean firstEndFlag) {
        this.assocEndInstance = assocEndInstance;
        this.metaAssocEnd = metaAssocEnd;
        this.refAssoc = refAssoc;
        this.firstEndFlag = firstEndFlag;
    }

    public RefObject getAssocEndInstance() {
        return assocEndInstance;
    }

    public AssociationEnd getMetaAssociationEnd() {
        return metaAssocEnd;
    }

    public RefAssociation getRefAssociation() {
        return refAssoc;
    }
    
    public boolean isFirstEnd () {
        return this.firstEndFlag;
    }
}
