/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrtoolkit.looks.reflect;

import java.util.*;
import java.awt.*;
import javax.jmi.reflect.*;
import javax.jmi.model.*;

/**
 *
 * @author  ms118741
 * @version 
 * This class is a wrapper object for the association
 */
public class RefAssocWrapper {

    private RefAssociation refAssoc = null;
    private Association metaAssoc = null;
    private AssociationEnd metaAssocEnd = null;
    private boolean fisrtEnd = false;
    /** Creates new RefAssocWrapper */
    public RefAssocWrapper(AssociationEnd metaAssocEnd, Association metaAssoc, RefAssociation refAssoc, boolean fisrtEnd) {
        this.metaAssocEnd = metaAssocEnd;
        this.metaAssoc = metaAssoc;
        this.refAssoc = refAssoc;
        this.fisrtEnd = fisrtEnd;
    }

    /** getter for the meta object of association */
    public Association getMetaAssociation() {
        return metaAssoc;
    }

    /** getter for the meta object of associationEnd */
    public AssociationEnd getMetaAssociationEnd() {
        return metaAssocEnd;
    }

    /** getter for the association */
    public RefAssociation getRefAssociation() {
        return refAssoc;
    }

    /** getter for the associationEnd */
    public boolean isFirstEnd() {
        return fisrtEnd;
    }
}
