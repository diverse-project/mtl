/*
 *                 Sun Public License Notice
 *
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 *
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */

package org.netbeans.modules.mdrexplorer.settings;

import org.openide.options.SystemOption;
import org.openide.util.NbBundle;


public class MDRExplorerSettings extends SystemOption {

    static final long serialVersionUID = -8659951379494351775L;
    
    static final String CHILD_COUNT = "browserChildCount";    //NOI18N
    private static final int DEFAULT_BROWSER_CHILD_COUNT = 1000;

    private static int browserChildCount;

    public MDRExplorerSettings () {
        browserChildCount = DEFAULT_BROWSER_CHILD_COUNT;
    }
    
    public String displayName () {
        return NbBundle.getBundle(MDRExplorerSettings.class).getString ("TXT_MDRExplorerSettings");  // NOI18N
    }
        
    public int getBrowserChildCount () {
        return browserChildCount;
    }
    
    public void setBrowserChildCount (int count) {
         long oldValue = browserChildCount;
         browserChildCount = count;
	 this.firePropertyChange (CHILD_COUNT, new Long (oldValue), new Long (count));
    }
    

}
