/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.mdr.handlers;

import java.util.*;

import org.netbeans.mdr.storagemodel.TypedCollection;

/**
 *
 * @author  mmatula
 * @version 
 */
public class CollectionUnwrapper extends AbstractList {
    private final Object[] innerList;
    
    public CollectionUnwrapper(Collection elements, Collection typedList) {
        super();
        
        int i = 0;
        TypedCollection list;
        if (typedList instanceof TypedCollection) {
            list = (TypedCollection) typedList;
        } else {
            list = null;
        }
        innerList = new Object[elements.size()];
        for (Iterator it = elements.iterator(); it.hasNext();) {
            Object element = it.next();
            if (list != null) {
                list.checkType(element);
            }
            innerList[i++] = IndexSetWrapper.unwrap(element);
        }
    }
    
    public CollectionUnwrapper(Collection elements) {
        this(elements, null);
    }
    
    public int size() {
        return innerList.length;
    }
    
    public Object get(int param) {
        return innerList[param];
    }
}
