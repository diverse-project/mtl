/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.mdr.persistence.memoryimpl;

import java.util.HashMap;
import java.util.Map;
import org.netbeans.mdr.persistence.*;

/**
 *
 * @author  pbuzek
 * @version 
 */
public class StorageFactoryImpl extends Object implements StorageFactory {
    public static final String STORAGE_NAME = "org.netbeans.mdr.persistence.memoryimpl.name";
    static final String NULL_STORAGE_ID = ".";
    private static final MOFID NULL_MOFID = new MOFID(0, NULL_STORAGE_ID);

    private StorageImpl nullStorage; 
    private final HashMap storages = new HashMap();

    /** Creates new StorageFactoryImpl */
    public StorageFactoryImpl() {
    }

    /** Creates instance of class that implements Storage interface.
     * throws StorageException if the name is not valid name of a Storage
     */
    public synchronized Storage createStorage(Map properties) throws StorageException {
        String name = (String) properties.get(NULL_STORAGE_ID);  // Not mandatory
        if (name == null || name.equals(NULL_STORAGE_ID)) {
            if (nullStorage == null) {
                nullStorage = new StorageImpl(NULL_STORAGE_ID, false);
            }
            return nullStorage;
        } else {
            Storage result = (Storage) storages.get(name);
            if (result == null) {
                result = new StorageImpl(NULL_STORAGE_ID, true);
                storages.put(name, result);
            }
            return result;
        }
    }
    
    public org.netbeans.mdr.persistence.MOFID createNullMOFID() throws StorageException {
        return NULL_MOFID;
    }
}
