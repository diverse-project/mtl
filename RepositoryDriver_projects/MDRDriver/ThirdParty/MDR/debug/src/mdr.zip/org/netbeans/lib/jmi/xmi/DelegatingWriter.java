/*
 *                 Sun Public License Notice
 *
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 *
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.lib.jmi.xmi;

import java.util.Collection;
import java.io.OutputStream;
import java.io.IOException;
import javax.jmi.reflect.RefPackage;
import org.netbeans.api.xmi.XMIWriter;
import org.netbeans.api.xmi.XMIOutputConfig;

public class DelegatingWriter extends XMIWriter {

    public static final String XMI_VERSION_20 = "2.0";
    
    private XMIOutputConfig config;
    
    public DelegatingWriter () {
        config = new OutputConfig ();
    }
    
    public DelegatingWriter (XMIOutputConfig config) {
        this.config = config;
    }
    
    public XMIOutputConfig getConfiguration() {
        return config;
    }
    
    public void write(OutputStream stream, String uri, Collection objects, String xmiVersion) throws IOException {
        getWriter (xmiVersion).write (stream, uri, objects, xmiVersion);
    }

    public void write(OutputStream stream, String uri, RefPackage extent, String xmiVersion) throws IOException {
        getWriter (xmiVersion).write (stream, uri, extent, xmiVersion);
    }

    private WriterBase getWriter (String xmiVersion) {
        if ((xmiVersion != null) && (xmiVersion.equals (XMI_VERSION_20)))
            return new XMI20Writer (config);
        else
            return new WriterBase (config);
    }
    
}
