/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */

package org.netbeans.mdr.util;

/**
 *
 * @author  Tomas Zezula
 */
public class MountFailedException extends java.lang.Exception {
    
    private Exception rootCase;
    
    /**
     * Creates a new instance of <code>MountFailedException</code> without detail message.
     */
    public MountFailedException () {
    }
    
    
    /**
     * Constructs an instance of <code>MountFailedException</code> with the specified detail message.
     * @param msg the detail message.
     */
    public MountFailedException(String msg) {
        this (msg, null);
    }
    
    /**
     * Constructs an instance of <code>MountFailedException</code> with the specified detail message and root case exception.
     * @param msg the detail message.
     * @param rootCase the root case exception
     */
    public MountFailedException (String message, Exception rootCase) {
        super (message);
        this.rootCase = rootCase;
    }
    
    /**
     *  Returns the root case exception.
     *  @return Exception the root case exception
     */
    public Exception getRootCase () {
        return this.rootCase;
    }
}
