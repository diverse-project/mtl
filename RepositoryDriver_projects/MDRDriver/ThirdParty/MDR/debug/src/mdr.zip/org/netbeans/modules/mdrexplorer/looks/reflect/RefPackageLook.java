/*
 *                 Sun Public License Notice
 *
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 *
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrexplorer.looks.reflect;

import org.netbeans.modules.mdrexplorer.looks.RepositoryCache;
import org.netbeans.modules.mdrexplorer.looks.MDREventHandler;
import org.netbeans.modules.mdrexplorer.looks.reflect.actions.*;
import java.util.*;
import javax.jmi.reflect.*;

import org.openide.util.actions.SystemAction;
import org.openide.util.SharedClassObject;
import org.netbeans.api.mdr.*;
import org.netbeans.api.looks.*;
import org.netbeans.modules.mdrexplorer.looks.DataRestWrapper;
/** Implements MOF models defaut view.
 *
 * @author  Petr Hrebejk, Tomas Zezula
 */
public class RefPackageLook extends BaseObjectLook {
    
    /** Creates new PackageProxy
     */
    public RefPackageLook() {
        super(Utils.getLocalizedString("TXT_RefPackageLook"));
    }
    
    public String toString() {
        return "MOF/PackageProxy::ALL"; // NOI18N
    }
    
    public Object attachTo(Look.NodeSubstitute substitute) {
        super.attachTo(substitute);
        RepositoryCache cache = RepositoryCache.getRepositoryCache();
        MDREventHandler handler = cache.getEventHandler(((org.netbeans.api.mdr.MDRObject)substitute.getRepresentedObject()).repository());
        if (handler != null)
            handler.addNodeSubstitute(substitute);
        return handler;
    }
    
    
    public String getName( Look.NodeSubstitute substitute ) {
        RefPackage packageProxy = (RefPackage)substitute.getRepresentedObject();
        String packageName = (String)RepositoryCache.getRepositoryCache().getPackageName(packageProxy);
        if (packageName == null) {
            packageName = ((javax.jmi.model.MofPackage)packageProxy.refMetaObject()).getName();
        }
        return packageName;
    }
    
    public javax.swing.Action[] getActions( Look.NodeSubstitute substitute ) {
        javax.swing.Action[] superActions = super.getActions(substitute);
        if (superActions == null) {
            superActions = new javax.swing.Action[0];
        }
        javax.swing.Action[] actions = new javax.swing.Action[superActions.length + 5];
        actions[0] = SystemAction.get(LoadXMIAction.class);
        actions[1] = SystemAction.get(SaveXMIAction.class);
        actions[2] = SystemAction.get(GenerateDTDAction.class);
        actions[3] = SystemAction.get(Map2JavaAction.class);
        actions[4] = SystemAction.get(DeleteObjectAction.class);
        System.arraycopy(superActions, 0, actions, 5, superActions.length);
        return actions;
    }
    
    public Object[] getChildObjects( Look.NodeSubstitute substitute ) {
        RefPackage packageProxy = (RefPackage)substitute.getRepresentedObject();
        MDRepository rep = ((MDRObject)packageProxy).repository();
        rep.beginTrans(false);
        try {
            Collection packages = packageProxy.refAllPackages();
            Collection classes = packageProxy.refAllClasses();
            Collection associations = packageProxy.refAllAssociations();
            int count = this.getBrowserChildCount();
            count = (count ==-1 ? Integer.MAX_VALUE : count+1);
            Object[] childObjects = new Object[ Math.min(packages.size() + classes.size() + associations.size(),count) ];
            int j = 0;
            for ( Iterator it = packages.iterator(); it.hasNext() && j<count-1;  j++ ) {
                childObjects[ j ] = it.next();
            }
            for ( Iterator it = classes.iterator(); it.hasNext() && j<count-1;  j++ ) {
                childObjects[ j ] = it.next();
            }
            for ( Iterator it = associations.iterator(); it.hasNext() && j<count-1;  j++ ) {
                childObjects[ j ] = it.next();
            }
            if (j==count-1) {
                childObjects[j]= new DataRestWrapper(new Collection[] {packages,classes,associations},count-1);
            }
            return childObjects;
        }finally {
            rep.endTrans();
        }
    }
}
