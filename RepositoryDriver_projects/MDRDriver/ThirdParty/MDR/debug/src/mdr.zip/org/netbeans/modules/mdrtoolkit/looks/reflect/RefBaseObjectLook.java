/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrtoolkit.looks.reflect;

import org.netbeans.modules.mdrtoolkit.looks.reflect.properties.*;

import org.netbeans.modules.mdrtoolkit.looks.reflect.*;
import org.netbeans.modules.mdrtoolkit.looks.reflect.actions.*;

import java.util.*;
import java.awt.*;
import javax.jmi.reflect.*;
import javax.jmi.model.*;

import org.openide.util.actions.SystemAction;
import org.openide.util.SharedClassObject;

import org.openidex.nodes.looks.*;
import java.beans.PropertyEditor;
import java.beans.PropertyEditorSupport;
import org.openide.nodes.*;
/**
 *
 * @author  ms118741
 * @version 
 */
public class RefBaseObjectLook extends AcceptorLook.Type {

    private static final String META = "META_";
    private static final String NAME = "name";
    /** Creates new RefObjectLook */
    public RefBaseObjectLook() {
        super( new Delegate(), RefBaseObject.class, true );
    }

    public String toString() {
        return "MOF/RefBaseObject::ALL"; // NOI18N
    }

    private static class Delegate extends BaseObjectLook {
    
        public String getName( Look.NodeSubstitute substitute ) {
            String result = null;
            result = META + ((ModelElement)((RefBaseObject)substitute.getRepresentedObject()).refMetaObject()).getName();
            return result;
        }

        public Object[] getChildObjects( Look.NodeSubstitute substitute ) {
            ArrayList result = new ArrayList();
            return result.toArray();
        }

        public Node.PropertySet[] getPropertySets( Look.NodeSubstitute substitute ) {
            return RefBaseObjectProps.getPropertySets( (RefBaseObject)substitute.getRepresentedObject() );
        }
    }
}
