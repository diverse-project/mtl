/*
 *                 Sun Public License Notice
 *
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 *
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.lib.jmi.xmi;

import java.io.*;
import java.util.*;
import java.net.URL;

import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.AttributesImpl;

import org.netbeans.lib.jmi.util.DebugException;
import org.netbeans.api.xmi.*;

import javax.jmi.reflect.*;
import javax.jmi.model.*;

public class XMIWriterImpl extends org.netbeans.api.mdr.XMIWriter {

    private DelegatingWriter writer = new DelegatingWriter ();
    
    public XMIWriterImpl() {
    }
    
    public XMIOutputConfig getConfiguration() {
        return writer.getConfiguration ();
    }    
    
    public void write(OutputStream stream, RefPackage extent, String xmiVersion) throws IOException {
        writer.write (stream, extent, xmiVersion);
    }             
    
    public void write(OutputStream stream, Collection objects, String xmiVersion) throws IOException {
        writer.write (stream, objects, xmiVersion);
    }
    
    public void write(OutputStream stream, RefPackage extent) {
        try {
            writer.write (stream, extent, null);
        } catch (IOException e) {
            // [PENDING]
        }
    }

}
