/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrtoolkit.looks.reflect;


import org.netbeans.modules.mdrtoolkit.looks.reflect.*;
import org.netbeans.modules.mdrtoolkit.looks.reflect.actions.*;
import java.util.*;
import java.awt.*;
import javax.jmi.reflect.*;
import javax.jmi.model.*;

import org.openide.util.actions.SystemAction;
import org.openide.util.SharedClassObject;

import org.openidex.nodes.looks.*;
/**
 *
 * @author  ms118741
 * @version 
 */
public class RefAssocWrapperLook extends AcceptorLook.Type {

    /** Creates new RefObjectLook */
    public RefAssocWrapperLook() {
        super( new Delegate(), RefAssocWrapper.class, true );
    }

    public String toString() {
        return "MOF/RefAssocWrapper::ALL"; // NOI18N
    }

    private static class Delegate extends BaseObjectLook {
    
        public String getName( Look.NodeSubstitute substitute ) {
            return Utils.getRefObjectName( ((RefAssocWrapper)substitute.getRepresentedObject()).getMetaAssociationEnd() );
        }

        public Object[] getChildObjects( Look.NodeSubstitute substitute ) {
            ArrayList result = new ArrayList();
            RefAssociation refAssoc = ((RefAssocWrapper)substitute.getRepresentedObject()).getRefAssociation();
            Collection links = refAssoc.refAllLinks();
            RefAssociationLink link = null;
            ArrayList alreadyCreated = new ArrayList();
            for (Iterator it = links.iterator(); it.hasNext(); ) {
                link = (RefAssociationLink)it.next();
                if (((RefAssocWrapper)substitute.getRepresentedObject()).isFirstEnd()) {
                    if (!alreadyCreated.contains( link.refFirstEnd() )) {
                        alreadyCreated.add( link.refFirstEnd() );
                        result.add( new RefLinkEndWrapper( link.refFirstEnd(), refAssoc, ((RefAssocWrapper)substitute.getRepresentedObject()).getMetaAssociationEnd() ) );
                    }
                } else {
                    if (!alreadyCreated.contains( link.refSecondEnd() )) {
                        alreadyCreated.add( link.refFirstEnd() );
                        result.add( new RefLinkEndWrapper( link.refSecondEnd(), refAssoc, ((RefAssocWrapper)substitute.getRepresentedObject()).getMetaAssociationEnd() ) );
                    }
                }
            }
            alreadyCreated.clear();
            alreadyCreated = null;
            return result.toArray();
        }
    }
}
