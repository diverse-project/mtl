/*
 *                 Sun Public License Notice
 *
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 *
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrexplorer.looks.reflect.actions;

import org.netbeans.modules.mdrexplorer.looks.reflect.*;

import org.openide.TopManager;
import org.openide.NotifyDescriptor;
import org.openide.nodes.Node;
import org.openide.util.*;
import org.openide.util.actions.NodeAction;
import org.openide.filesystems.FileSystem;
import org.openide.filesystems.FileObject;
import org.openide.loaders.*;

import org.netbeans.api.looks.*;

import org.netbeans.api.mdr.*;
//import org.netbeans.mdr.util.DebugException;

import javax.jmi.reflect.*;

import java.util.ResourceBundle;
import java.util.ArrayList;
import java.io.File;
import java.io.FileOutputStream;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;

/** Action sensitive to the node selection that does something useful.
 *
 * @author  Martin Matula
 */
public class SaveXMIAction extends NodeAction {
    
    /** Resource bundle */
    private static final ResourceBundle bundle = NbBundle.getBundle(Utils.class);
    
    protected void performAction(Node[] nodes) {
        saveXMI( nodes );
    }
    
    private void saveXMI( Node[] nodes ) {
        final TopManager tm = TopManager.getDefault();
        File temp = null;
        // selects one folder from data systems
        JFileChooser chooser = new JFileChooser();
        // Note: source for ExampleFileFilter can be found in FileChooserDemo,
        // under the demo/jfc directory in the Java 2 SDK, Standard Edition.
        chooser.setFileFilter(new XMIFileFilter());
        java.awt.Component parent = tm.getWindowManager().getMainWindow();
        int returnVal = org.openide.util.Utilities.showJFileChooser(chooser, parent, "Export");
        if(returnVal == JFileChooser.APPROVE_OPTION) {
            temp = chooser.getSelectedFile();
        }
        final File file = temp;
        RefPackage refPackage = null;
        ArrayList al = null;
        
        if (nodes.length == 1 && ((LookNode)nodes[0]).getRepresentedObject() instanceof RefPackage) {
            refPackage = (RefPackage) ((LookNode)nodes[0]).getRepresentedObject();
        }
        else {
            al = new ArrayList();
            for (int i=0; i< nodes.length; i++) {
                al.add( ((LookNode)nodes[i]).getRepresentedObject() );
            }
        }
        
        final RefPackage refFinalPackage = refPackage;
        final ArrayList fal = al;
        
        if (file != null) {
            // map the interfaces in a background thread
            RequestProcessor.postRequest(new Runnable() {
                public void run() {
                    tm.setStatusText(bundle.getString("CTL_XMIExportStarted"));
                    try {
                        FileOutputStream fos = new FileOutputStream( file );
                        XMIWriter xmiWriter = XMIWriter.getDefault();
                        if ( refFinalPackage == null ) {
                            MDRepository rep = ((MDRObject)fal.get(0)).repository();
                            rep.beginTrans(false);
                            try {
                                xmiWriter.write(fos, fal, null);
                            } finally {
                                rep.endTrans();
                            }
                        }
                        else {
                            MDRepository rep = ((MDRObject) refFinalPackage).repository();
                            rep.beginTrans(false);
                            try {
                                xmiWriter.write(fos, refFinalPackage);
                            }finally {
                                rep.endTrans();
                            }
                        }
                        
                    } catch (java.io.IOException ioex) {
                        org.openide.TopManager.getDefault().getErrorManager().notify ( ioex );
                    }
                    finally {
                        tm.setStatusText(bundle.getString("CTL_XMIExportFinished"));
                    }
                }
            });
        }
    }
    
    protected boolean enable(Node[] nodes) {
        if (nodes == null)
            return false;
        RefPackage omp = null;
        for (int i=0; i< nodes.length; i++) {
            if (!(nodes[i] instanceof LookNode))
                return false;
            Object ro = ((LookNode)nodes[i]).getRepresentedObject();
            if (ro instanceof RefPackage && nodes.length == 1)
                return true;
            if (! (ro instanceof RefObject))
                return false;
            if (omp == null) {
                omp = ((RefObject)ro).refOutermostPackage();
            }
            else {
                if (omp != ((RefObject)ro).refOutermostPackage())
                    return false;
            }
        }
        return true;
    }
    
    public String getName() {
        return bundle.getString("CTL_ACTION_XMIExport");
    }
    
    protected String iconResource() {
        return null;
    }
    
    public HelpCtx getHelpCtx() {
        return HelpCtx.DEFAULT_HELP;
        // If you will provide context help then use:
        // return new HelpCtx (GenerateInterfacesActionAction.class);
    }
    
    private static final class XMIFileFilter extends FileFilter {
        public boolean accept(File f) {
            return f.getName().toUpperCase().endsWith(".XML") || f.getName().toUpperCase().endsWith(".XMI") || f.isDirectory();
        }
        
        public String getDescription() {
            return bundle.getString("CTL_XMIFiles");
        }
    }
}