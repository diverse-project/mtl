/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.mdr.handlers;

import java.util.Collection;
import java.util.Iterator;
import org.netbeans.mdr.util.TransactionMutex;

/**
 *
 * @author  mm109185
 */
public class AttrImmutCollWrapper implements Collection {
    protected final Collection inner;
    protected final TransactionMutex mutex;
    
    /** Creates new CollectionWrapper */
    public AttrImmutCollWrapper(TransactionMutex mutex, Collection inner) {
        this.inner = inner;
        this.mutex = mutex;
    }
    
    protected final void lock(boolean write) {
        mutex.enter(write);
    }
    
    protected final void unlock() {
        mutex.leave();
    }
    
    protected final void unlock(boolean fail) {
        mutex.leave(fail);
    }

    public final boolean contains(Object obj) {
        try {
            lock(false);
            return inner.contains(obj);
        } finally {
            unlock();
        }
    }
    
    public Iterator iterator() {
        try {
            lock(false);
            return new AttrImmutIteratorWrapper(inner.iterator());
        } finally {
            unlock();
        }
    }
    
    public final int size() {
        try {
            lock(false);
            return inner.size();
        } finally {
            unlock();
        }
    }
    
    public final boolean isEmpty() {
        try {
            lock(false);
            return inner.isEmpty();
        } finally {
            unlock();
        }
    }
    
    public final boolean containsAll(Collection collection) {
        try {
            lock(false);
            return inner.containsAll(collection);
        } finally {
            unlock();
        }
    }
    
    public final Object[] toArray(Object[] obj) {
        try {
            lock(false);
            return inner.toArray(obj);
        } finally {
            unlock();
        }
    }
    
    public final Object[] toArray() {
        try {
            lock(false);
            return inner.toArray();
        } finally {
            unlock();
        }
    }
    
    public boolean addAll(Collection collection) {
        throw new UnsupportedOperationException();
    }
    
    public boolean remove(Object obj) {
        throw new UnsupportedOperationException();
    }
    
    public boolean add(Object obj) {
        throw new UnsupportedOperationException();
    }
    
    public boolean retainAll(Collection collection) {
        throw new UnsupportedOperationException();
    }
    
    public boolean removeAll(Collection collection) {
        throw new UnsupportedOperationException();
    }
    
    public void clear() {
        throw new UnsupportedOperationException();
    }
    
    protected class AttrImmutIteratorWrapper implements Iterator {
        protected final Iterator innerIterator;
        
        protected AttrImmutIteratorWrapper(Iterator innerIterator) {
            this.innerIterator = innerIterator;
        }
        
        public final boolean hasNext() {
            try {
                lock(false);
                return innerIterator.hasNext();
            } finally {
                unlock();
            }
        }
        
        public Object next() {
            try {
                lock(false);
                return innerIterator.next();
            } finally {
                unlock();
            }
        }
        
        public void remove() {
            throw new UnsupportedOperationException();
        }
    }
}
