/*
 *                 Sun Public License Notice
 *
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 *
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrexplorer.looks.model;

import java.awt.datatransfer.Transferable;
import java.io.IOException;
import java.util.*;
import javax.jmi.reflect.*;
import javax.jmi.model.*;
import org.openide.util.actions.SystemAction;
import org.netbeans.api.looks.*;
import org.netbeans.spi.looks.*;
import org.netbeans.api.mdr.MDRObject;
import org.netbeans.api.mdr.MDRepository;
import org.netbeans.modules.mdrexplorer.looks.reflect.Utils;
import org.netbeans.modules.mdrexplorer.looks.LimitedChildrenLook;
import org.netbeans.modules.mdrexplorer.looks.DataRestWrapper;
import org.netbeans.modules.mdrexplorer.looks.reflect.actions.*;
import org.netbeans.modules.mdrexplorer.looks.RepositoryCache;
import org.netbeans.modules.mdrexplorer.looks.MDREventHandler;
import org.netbeans.modules.mdrexplorer.looks.MDRTransferable;
/** Handles Names and Icons for all MOF Objects
 *
 * @author  Petr Hrebejk, Tomas Zezula
 */
public class ContainedElements extends LimitedChildrenLook {
    
    public ContainedElements() {
        super(Utils.getLocalizedString(ContainedElements.class, "TXT_ContainedElements"));
    }
    
    public Object attachTo(Look.NodeSubstitute substitute) {
        super.attachTo(substitute);
        RepositoryCache cache = RepositoryCache.getRepositoryCache();
        MDREventHandler handler = cache.getEventHandler(((MDRObject)substitute.getRepresentedObject()).repository());
        if (handler != null)
            handler.addNodeSubstitute(substitute);
        return handler;
    }
    
    public Object[] getChildObjects( Look.NodeSubstitute substitute ) {
        Namespace ns = (Namespace)substitute.getRepresentedObject();
        MDRepository rep = ((MDRObject)ns).repository();
        rep.beginTrans(false);
        try {
            // Get all contained elements
            Collection elements = ns.getContents();
            // Make array from the list
            int count = this.getBrowserChildCount();
            count = (count ==-1 ? Integer.MAX_VALUE : count+1);
            Object children[] = new Object[ Math.min(elements.size(),count) ];
            Iterator it = elements.iterator();
            for (int i=0; it.hasNext() && i<count-1; i++) {
                children[i] = it.next();
            }
            if (it.hasNext()) {
                children[children.length-1] = new DataRestWrapper(new Collection[] {elements},count-1);
            }
            return children;
        } finally {
            rep.endTrans();
        }
    }
    
    public Transferable clipboardCopy (Look.NodeSubstitute substitute) throws IOException {
        ModelElement me = (ModelElement) substitute.getRepresentedObject ();
        StringBuffer qualifiedName = new StringBuffer ();
        for (Iterator it = me.getQualifiedName().iterator(); it.hasNext();) {
            if (qualifiedName.length () > 0)
                qualifiedName.append ('.');
            qualifiedName.append ((String)it.next());
        }
        return new MDRTransferable (me, qualifiedName.toString());
    }
}
