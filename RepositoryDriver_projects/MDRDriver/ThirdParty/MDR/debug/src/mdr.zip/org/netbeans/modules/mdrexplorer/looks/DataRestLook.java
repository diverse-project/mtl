/*
 *                 Sun Public License Notice
 *
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 *
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */

package org.netbeans.modules.mdrexplorer.looks;

import java.util.Collection;
import java.util.Iterator;
import java.util.ArrayList;
import org.openide.util.NbBundle;
import javax.jmi.reflect.RefFeatured;
import javax.jmi.reflect.RefObject;
import javax.jmi.reflect.RefAssociation;
import javax.jmi.model.AssociationEnd;
import org.netbeans.api.looks.*;
import org.netbeans.spi.looks.*;
import org.netbeans.api.mdr.MDRObject;
import org.netbeans.api.mdr.MDRepository;
import org.netbeans.modules.mdrexplorer.looks.reflect.RefLinkEndWrapper;
import org.netbeans.modules.mdrexplorer.looks.reflect.RefAssocWrapper;
import org.netbeans.modules.mdrexplorer.looks.reflect.Utils;

/**
 *
 * @author  Tomas Zezula
 */
public class DataRestLook extends DefaultLook {
    
    private static final String ICON = "org/netbeans/modules/mdrexplorer/looks/resources/rest";
    
    /** Creates a new instance of DataRestLook */
    public DataRestLook() {
        super(NbBundle.getMessage(MDRepositoryLook.class,"TXT_DataRestLook"));
    }
    
    public String getName(Look.NodeSubstitute substitute) {
        return NbBundle.getMessage(MDRepositoryLook.class,"TXT_DataRest");
    }
    
    public String getDisplayName(Look.NodeSubstitute substitute) {
        return this.getName(substitute);
    }
    
    public String iconBase(Look.NodeSubstitute substitute) {
        return ICON;
    }
    
    /** Returns the child objects for rest node
     *  the result are either data dirrecly from live collections
     *  or wrappers build on them, depending on mode of substitute
     */
    public Object[] getChildObjects(Look.NodeSubstitute substitute) {
        DataRestWrapper data = ((DataRestWrapper)substitute.getRepresentedObject());
        Collection[] collections = data.getCollections();
        int offset = data.getOffset();
        int size = -offset;
        for (int i=0; i< collections.length; i++) {
            size+=collections[i].size();
        }
        int i=0;
        for (; i< collections.length;i++) {
            if (collections[i].size() <= offset)
                offset = offset - collections[i].size();
            else
                break;
        }
        if (data.getMode() == DataRestWrapper.DIRECT) {
            // Direct mode case
            // Simply copy data from live collecions into resulting array
            Object[] result = new Object[size];
            size=0;
            for (; i< collections.length; i++) {
                System.arraycopy(collections[i].toArray(),offset,result,size,collections[i].size()-offset);
                size+=(collections[i].size()-offset);
                offset = 0;
            }
            return result;
        }
        else if (data.getMode() == DataRestWrapper.ASSOC_END) {
            // First end of association wrappers
            // are build here
            RefAssocWrapper aw = (RefAssocWrapper) data.getData();
            RefAssociation refAssoc = aw.getRefAssociation();
            AssociationEnd associationEnd = aw.getMetaAssociationEnd();
            boolean isFirstEnd = aw.isFirstEnd();
            boolean[] completionFlag = new boolean[1];
            ArrayList resList = new ArrayList();
            MDRepository repo = ((MDRObject)refAssoc).repository();
            repo.beginTrans(false);
            try {
                for (; i<collections.length; i++) {
                    resList.addAll(Utils.getRefLinkEndWrappers(collections[i],refAssoc,associationEnd, isFirstEnd,-1,offset,completionFlag));
                    offset = 0;
                }
                return resList.toArray();
            }finally {
                repo.endTrans();
            }
        }
        else if (data.getMode() == DataRestWrapper.ASSOC_OTHER_END) {
            // Second end of association wrappers
            // are build here
            RefLinkEndWrapper lew = (RefLinkEndWrapper) data.getData();
            RefAssociation refAssoc = lew.getRefAssociation();
            RefObject endInstance = lew.getAssocEndInstance();
            boolean isFirstEnd = lew.isFirstEnd();
            boolean[] completionFlag = new boolean[1];
            ArrayList resList = new ArrayList();
            MDRepository repo = ((MDRObject)refAssoc).repository();
            repo.beginTrans(false);
            try {
                for (;i<collections.length; i++) {
                    resList.addAll(Utils.getRefLinkOtherEndWrappers(collections[i],endInstance,refAssoc,isFirstEnd,-1,offset,completionFlag));
                    offset = 0;
                }
                return resList.toArray();
            } finally {
                repo.endTrans();
            }
        }
        else {
            // Reference wrappers
            // are build here
            ArrayList resList = new ArrayList();
            for (; i< collections.length; i++) {
                resList.addAll(Utils.getRestFeatures(collections[i],(RefFeatured)data.getData(),offset,data.getMode()));
                offset = 0;
            }
            return resList.toArray();
        }
    }
    
}
