/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.api.mdr;

import javax.jmi.xmi.XmiWriter;
import org.openide.util.Lookup;
import java.util.Collection;
import java.io.OutputStream;
import javax.jmi.reflect.RefPackage;

/** XMI writer utility. Provides a way for exporting JMI repository content into XMI format.
 * Use {@link #getDefault} method to obtain the default instance.
 *
 * @author Martin Matula
 * @deprecated This class was replaced by a new API in org.netbeans.api.xmi package and will be removed soon.
 * You should use {@link javax.jmi.xmi.XmiWriter} and {@link org.netbeans.api.xmi.XMIWriter} instead.
 */
public abstract class XMIWriter implements XmiWriter {
    /** Returns the default instance of XMIWriter.
     * @return Default XMI writer instance.
     */    
    public static XMIWriter getDefault() {
        // [PENDING] simple lookup should be used once the lookup is fixed (currently it does not preserve order)
        Lookup.Result result = Lookup.getDefault().lookup(
            new Lookup.Template(XMIWriter.class)
        );
        Collection instances = result.allInstances();
        return (instances.size() > 0 ? (XMIWriter) result.allInstances().iterator().next() : null);
    }

    /** Produces XMI 1.2 document containing elements from the given extent.
     * @param stream Stream used for writing the XMI data.
     * @param extent Package extent to be serialized into XMI.
     */
    public abstract void write(OutputStream stream, RefPackage extent);
}

