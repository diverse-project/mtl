/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrtoolkit.looks.reflect.actions;

import org.netbeans.modules.mdrtoolkit.looks.reflect.*;

import org.openide.TopManager;
import org.openide.NotifyDescriptor;
import org.openide.nodes.Node;
import org.openide.util.*;
import org.openide.util.actions.NodeAction;
import org.openide.filesystems.FileSystem;
import org.openide.filesystems.FileObject;
import org.openide.loaders.*;

import org.openidex.nodes.looks.*;

import org.netbeans.api.mdr.*;
import org.netbeans.mdr.util.DebugException;

import javax.jmi.reflect.*;

import java.util.ResourceBundle;
import java.util.ArrayList;
import java.io.File;
import java.io.FileOutputStream;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;

/** Action sensitive to the node selection that does something useful.
 *
 * @author  Martin Matula
 */
public class SaveXMIAction extends NodeAction {

    /** Resource bundle */
    private static final ResourceBundle bundle = NbBundle.getBundle(Utils.class);

    protected void performAction (Node[] nodes) {
        Node node = nodes[0];
        LookNode lookNode = (LookNode) node; //(LookNode)node.getCookie( LookNode.class );
        
        if ( lookNode != null ) {
            saveXMI( lookNode );
        }
    }

    private void saveXMI( LookNode lookNode ) {
        if (!(lookNode.getRepresentedObject() instanceof RefPackage))
            throw new IllegalArgumentException(
                "Save XMI action can not be applied to this node : " 
                + lookNode.getRepresentedObject()
            );

        final TopManager tm = TopManager.getDefault();
        final File file;

        File temp = null;
        // selects one folder from data systems
        JFileChooser chooser = new JFileChooser();
        // Note: source for ExampleFileFilter can be found in FileChooserDemo,
        // under the demo/jfc directory in the Java 2 SDK, Standard Edition.
        chooser.setFileFilter(new XMIFileFilter());
	java.awt.Component parent = tm.getWindowManager().getMainWindow();
        int returnVal = org.openide.util.Utilities.showJFileChooser(chooser, parent, "Export");
        if(returnVal == JFileChooser.APPROVE_OPTION) {
            temp = chooser.getSelectedFile();
        }
        file = temp;

        RefPackage refPackage = null;
        ArrayList al = null;
        
        if (lookNode.getRepresentedObject() instanceof RefObject ) {
            al = new ArrayList( 1 );
            al.add( lookNode.getRepresentedObject() );
        }
        else if (lookNode.getRepresentedObject() instanceof RefPackage) {
            refPackage = (RefPackage)lookNode.getRepresentedObject();
        }
        
        final RefPackage refFinalPackage = refPackage;
        final ArrayList fal = al;
        refPackage = null;
        
        if (file != null) {
            // map the interfaces in a background thread
            RequestProcessor.postRequest(new Runnable() {
                public void run() {
                    tm.setStatusText (bundle.getString ("CTL_XMIExportStarted"));
                    MDRepository rep = ((MDRObject) refFinalPackage).repository();
                    
                    try {
                        rep.beginTrans(false);
                        FileOutputStream fos = new FileOutputStream( file );
                        XMIWriter xmiWriter = XMIWriter.getDefault();
                        if ( refFinalPackage == null ) {
                            xmiWriter.write(fos, fal, null);
                        }
                        else {
                            xmiWriter.write(fos, refFinalPackage);
                        }
                        
                    } catch (java.io.IOException ioex) {
                        System.out.println( ioex );

                    } finally { 
                        rep.endTrans();
                        tm.setStatusText (bundle.getString ("CTL_XMIExportFinished"));
                    }
                }
            });
        }
    }

    protected boolean enable (Node[] nodes) {
        if (nodes.length == 1) {
            LookNode lookNode = (LookNode) nodes[0];
            if ( lookNode.getRepresentedObject() instanceof RefPackage ) {
                return true;
            }
            return false;
        }        
        return false;
    }

    public String getName () {
        return bundle.getString ("CTL_ACTION_XMIExport");
    }

    protected String iconResource () {
        return null;
    }

    public HelpCtx getHelpCtx () {
        return HelpCtx.DEFAULT_HELP;
        // If you will provide context help then use:
        // return new HelpCtx (GenerateInterfacesActionAction.class);
    }

    private static final class XMIFileFilter extends FileFilter {
        public boolean accept(File f) {
            return f.getName().toUpperCase().endsWith(".XML") || f.getName().toUpperCase().endsWith(".XMI") || f.isDirectory();
        }
        
        public String getDescription() {
            return bundle.getString("CTL_XMIFiles");
        }
    }
}