/*
 *                 Sun Public License Notice
 *
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 *
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */

package org.netbeans.modules.mdrexplorer.actions;

/**
 *
 * @author  Tomas Zezula
 */
import java.lang.ref.WeakReference;
import java.util.ResourceBundle;
import org.openide.TopManager;
import org.openide.windows.Workspace;
import org.openide.util.actions.CallableSystemAction;
import org.openide.util.HelpCtx;
import org.openide.util.NbBundle;

public class BrowserAction extends CallableSystemAction {
    
    private static final String ICON = "org/netbeans/modules/mdrexplorer/looks/resources/repository.gif";
    
    private ResourceBundle bundle;
    private WeakReference explorer;
    
    /** Creates a new instance of BrowserAction */
    public BrowserAction() {
    }
    
    public void performAction () {
        MDRExplorer ep = null;
        if (this.explorer == null || (ep = (MDRExplorer) this.explorer.get ()) == null) {
                ep = new MDRExplorer ();
                this.explorer = new WeakReference (ep);
        }
        Workspace ws = TopManager.getDefault ().getWindowManager ().getCurrentWorkspace ();
        if (!ep.isOpened (ws)) {
            ep.open (ws);
        }
    }
    
    public String getName () {
        if (this.bundle == null) {
            this.bundle = NbBundle.getBundle (BrowserAction.class);
        }
        return bundle.getString ("TXT_BrowserActionName");
    }
    
    
    public String iconResource () {
        return ICON;
    }
    
    public HelpCtx getHelpCtx () {
        return HelpCtx.DEFAULT_HELP;
    }
    
}
