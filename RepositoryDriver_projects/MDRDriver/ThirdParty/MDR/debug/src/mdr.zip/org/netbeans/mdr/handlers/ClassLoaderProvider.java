/*
 * ClassLoaderProvider.java
 *
 * Created on May 18, 2002, 2:15 PM
 */

package org.netbeans.mdr.handlers;

/**
 *
 * @author  mm109185
 */
public interface ClassLoaderProvider {
    /** Implementation of this method should return a classloader that MDR will use
     * for resolving JMI interfaces/classes and classes that implement derived
     * attributes and operations.
     * @return classloader
     */
    public ClassLoader getClassLoader();
    
    /** Implementation of this method can define a given class.
     * The defined class should be then visible from the ClassLoader returned
     * from {@link #getClassLoader} method.
     * @param className name of the class to define.
     * @param classFile array of bytes representing the class.
     * @return Defined class or null (if null is return, MDR will define the
     * class in its own classloader. This class will then not be accessible from outside
     * of MDR
     * @throws ClassFormatError
     */
    public Class defineClass(String className, byte[] classFile);
}
