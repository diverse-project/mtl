/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrtoolkit.looks.reflect;

import org.netbeans.modules.mdrtoolkit.looks.RepositoryCache;
import org.netbeans.modules.mdrtoolkit.looks.reflect.*;
import org.netbeans.modules.mdrtoolkit.looks.reflect.actions.*;
import java.util.*;
import java.awt.*;
import javax.jmi.reflect.*;

import org.openide.util.actions.SystemAction;
import org.openide.util.SharedClassObject;

import org.openidex.nodes.looks.*;

/** Implements MOF models defaut view.
 *
 * @author  Petr Hrebejk
 */
public class RefPackageLook extends AcceptorLook.Type {
   
    /** Creates new PackageProxy
     */
    public RefPackageLook() {
        super( new Delegate(), RefPackage.class, true );
    }
    
    public String toString() {
        return "MOF/PackageProxy::ALL"; // NOI18N
    }

    private static class Delegate extends BaseObjectLook {
    
        public String getName( Look.NodeSubstitute substitute ) {
            RefPackage packageProxy = (RefPackage)substitute.getRepresentedObject();    
            String packageName = (String)RepositoryCache.getRepositoryCache().getObjectNameChache().get( packageProxy );
            if (packageName == null) {
                packageName = ((javax.jmi.model.MofPackage)packageProxy.refMetaObject()).getName();
            }
            return packageName;
        }

        public SystemAction[] getActions( Look.NodeSubstitute substitute ) {
            SystemAction[] superActions = super.getActions(substitute);
            if (superActions == null) {
                superActions = new SystemAction[0];
            }
            SystemAction[] actions = new SystemAction[superActions.length + 4];
            actions[0] = (SystemAction)SharedClassObject.findObject( LoadXMIAction.class, true );
            actions[1] = (SystemAction)SharedClassObject.findObject( SaveXMIAction.class, true );
            actions[2] = (SystemAction)SharedClassObject.findObject( Map2JavaAction.class, true );
            actions[3] = (SystemAction)SharedClassObject.findObject( DeleteObjectAction.class, true );
//            actions[4] = (SystemAction)SharedClassObject.findObject( GenerateJavaAction.class, true );
                       
            System.arraycopy(superActions, 0, actions, 4, superActions.length);

            return actions;
        }
        
        public Object[] getChildObjects( Look.NodeSubstitute substitute ) {
            RefPackage packageProxy = (RefPackage)substitute.getRepresentedObject();
            Collection packages = packageProxy.refAllPackages();
            Collection classes = packageProxy.refAllClasses();
            Collection associations = packageProxy.refAllAssociations();
            Object[] childObjects = new Object[ packages.size() + classes.size() + associations.size() ];

            int j = 0;
            
            for ( Iterator it = packages.iterator(); it.hasNext();  j++ ) {
                childObjects[ j ] = it.next();
            }
            for ( Iterator it = classes.iterator(); it.hasNext();  j++ ) {
                childObjects[ j ] = it.next();
            }
            for ( Iterator it = associations.iterator(); it.hasNext();  j++ ) {
                childObjects[ j ] = it.next();
            }
            
            return childObjects;
        }
        
    }

}
