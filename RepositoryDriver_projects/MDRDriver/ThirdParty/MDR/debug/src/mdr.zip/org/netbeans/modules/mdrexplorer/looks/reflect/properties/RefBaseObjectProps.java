/*
 *                 Sun Public License Notice
 *
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 *
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrexplorer.looks.reflect.properties;

import org.netbeans.modules.mdrexplorer.looks.reflect.*;
import org.netbeans.modules.mdrexplorer.looks.RepositoryCache;

import java.util.*;
import java.awt.*;
import javax.jmi.reflect.*;
import javax.jmi.model.*;

import org.openide.util.actions.SystemAction;
import org.openide.util.SharedClassObject;

import org.netbeans.api.looks.*;

import java.beans.PropertyEditor;
import java.beans.PropertyEditorSupport;
import org.openide.nodes.*;
/**
 *
 * @author  ms118741, Tomas Zezula
 * @version
 */
public class RefBaseObjectProps implements ReadWritePropertyIntf {
    
    private static final int META_OBJECT = 0;
    private static final int IMMEDIATE_PACKAGE = 1;
    private static final int OUTERMOST_PACKAGE = 2;
    private static final int MOFID = 3;
    
    private static final String OMP_SEPARATOR = ":";    // NOI18N
    
    private RefBaseObject refBaseObject = null;
    private int propCode = META_OBJECT;
    private boolean noValue;
    
    /** Creates new RefBaseObjectProps */
    private RefBaseObjectProps(RefBaseObject refBaseObject, int propCode) {
        this.refBaseObject = refBaseObject;
        this.propCode = propCode;
    }
    
    public static Node.PropertySet[] getPropertySets(RefBaseObject refBaseObject) {
        try {
            Sheet.Set sheetSet = new Sheet.Set();
            sheetSet.setName(Utils.getLocalizedString(RefBaseObjectProps.class,"TXT_META_PROPERTIES"));
            sheetSet.setDisplayName(Utils.getLocalizedString(RefBaseObjectProps.class,"TXT_META_PROPERTIES"));
            sheetSet.put( LookPropertySupport.getProperty( new RefBaseObjectProps(refBaseObject, META_OBJECT ) ) );
            sheetSet.put( LookPropertySupport.getProperty( new RefBaseObjectProps(refBaseObject, IMMEDIATE_PACKAGE ) ) );
            sheetSet.put( LookPropertySupport.getProperty( new RefBaseObjectProps(refBaseObject, OUTERMOST_PACKAGE ) ) );
            sheetSet.put( LookPropertySupport.getProperty( new RefBaseObjectProps(refBaseObject, MOFID ) ) );
            return new Node.PropertySet[] { sheetSet };
        }catch (Exception exception) {
            //Has to be catched because of bug in the looks implementation
            //the look is asked on the property set even on deleted node
            return new Node.PropertySet[0];
        }
    }
    
    public String getSheetName() {
        return Utils.getLocalizedString(RefBaseObjectProps.class,"TXT_META_PROPERTIES");
    }
    
    
    public String getPropertyName() {
        String result = null;
        switch (propCode) {
            case META_OBJECT :  {
                result = Utils.getLocalizedString(RefBaseObjectProps.class,"TXT_PROP_META_OBJECT");
                break;
            }
            case IMMEDIATE_PACKAGE :  {
                result = Utils.getLocalizedString(RefBaseObjectProps.class,"TXT_PROP_IMMEDIATE_PACKAGE");
                break;
            }
            case OUTERMOST_PACKAGE :  {
                result = Utils.getLocalizedString(RefBaseObjectProps.class,"TXT_PROP_OUTERMOST_PACKAGE");
                break;
            }
            case MOFID :  {
                result = Utils.getLocalizedString(RefBaseObjectProps.class,"TXT_PROP_MOFID");
                break;
            }
        }
        return result;
    }
    
    public String getPropertyDesc() {
        return getPropertyName();
    }
    
    public Class getPropertyClass() {
        return String.class;
    }
    
    public Object getValue() {
        Object result = null;
        switch (propCode) {
            case META_OBJECT :  {
                RefObject metaObject = refBaseObject.refMetaObject();
                if (metaObject instanceof ModelElement) {
                    RefPackage omp = metaObject.refOutermostPackage();
                    result = Utils.resolveFullyQualifiedName( ((ModelElement)metaObject).getQualifiedName() );
                    
                    Collection packages = RepositoryCache.getRepositoryCache().getPackages();
                    for (Iterator it = packages.iterator(); it.hasNext(); ) {
                        if (omp.equals( it.next() )) {
                            result = (String)RepositoryCache.getRepositoryCache().getPackageName(omp) +
                            OMP_SEPARATOR + result;
                        }
                    }
                    
                } else {
                    result = metaObject.refMofId();
                }
                break;
            }
            case IMMEDIATE_PACKAGE :  {
                RefPackage imp = refBaseObject.refImmediatePackage();
                if (imp != null) {
                    result = imp.refMofId();
                }
                break;
            }
            case OUTERMOST_PACKAGE :  {
                RefPackage omp = refBaseObject.refOutermostPackage();
                if (omp != null) {
                    result = omp.refMofId();
                }
                break;
            }
            case MOFID :  {
                result = refBaseObject.refMofId();
                break;
            }
        }
        if (result == null) {
            result = Utils.getLocalizedString(RefBaseObjectProps.class,"TXT_NO_VALUE");
            this.noValue = true;
        }
        return result;
    }
    
    public boolean isReadOnly() {
        return true;
    }
    
    public void setValue(Object value) {
    }
    
    public boolean hasPropertyEditor() {
        return false;
    }
    
    public java.beans.PropertyEditor getPropertyEditor() {
        return null;
    }
    
    public RefBaseObject getNavigableObject() {
        RefBaseObject result = null;
        switch (propCode) {
            case META_OBJECT :  {
                result = refBaseObject.refMetaObject();
                break;
            }
            case IMMEDIATE_PACKAGE :  {
                result = refBaseObject.refImmediatePackage();
                break;
            }
            case OUTERMOST_PACKAGE :  {
                result = refBaseObject.refOutermostPackage();
                break;
            }
            case MOFID :  {
                result = refBaseObject;
                break;
            }
        }
        return result;
    }
    
}
