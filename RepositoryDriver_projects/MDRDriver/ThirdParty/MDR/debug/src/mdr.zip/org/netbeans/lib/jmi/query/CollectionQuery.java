/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.lib.jmi.query;

import java.util.Collection;
import java.util.Iterator;

/** Takes a collection and transforms it into a query.
 *
 * @author Petr Hrebejk
 */
public class CollectionQuery implements Query {

    private final Collection COLLECTION;
    
    public CollectionQuery( Collection collection ) {
        this.COLLECTION = collection;
    }
    
    public Iterator iterator() {
        return new QueryIterator.Delegate( COLLECTION.iterator() );
    }
    
    public boolean contains( Object object ) {
        return COLLECTION.contains( object );
    }
}
