/*
 *                 Sun Public License Notice
 *
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 *
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrexplorer.looks;

import java.io.File;
import java.util.Collection;
import java.util.ArrayList;
import org.openide.util.NbBundle;
import org.openide.util.Lookup;
import org.netbeans.api.mdr.*;
import org.netbeans.spi.looks.*;
import org.netbeans.api.looks.*;
import org.netbeans.modules.mdrexplorer.looks.DataRestWrapper;

/** All metadata repositories in the system
 *
 * @author Petr Hrebejk, Tomas Zezula
 */
public class MDRManagerLook extends LimitedChildrenLook {
    
    public static final String MDRMANAGER_ICON = "org/netbeans/modules/mdrexplorer/looks/reflect/resources/root";
    
    /** Creates new RootLook */
    public MDRManagerLook() {
        super (NbBundle.getMessage(MDRManagerLook.class,"TXT_MDRManagerLook"));
    }
    
    public String getName (Look.NodeSubstitute substitute) {
        return NbBundle.getMessage(MDRManagerLook.class,"TXT_MDRManager");
    }
    
    public String getDisplayName (Look.NodeSubstitute substitute) {
        return this.getName (substitute);
    }
    
    public String iconBase (Look.NodeSubstitute substitute) {
        return MDRMANAGER_ICON;
    }
    
    public Object[] getChildObjects( Look.NodeSubstitute substitute ) {        
        MDRManager manager = ((MDRManagerWrapper)substitute.getRepresentedObject()).getMDRManager();
        String[] mdrNames = manager.getRepositoryNames();
        int count = this.getBrowserChildCount ();
        count = (count ==-1 ? Integer.MAX_VALUE : count+1);
        Object[] mdrs = new Object[ Math.min(mdrNames.length,count) ];
        int i = 0;
        for (; i < Math.min (mdrNames.length,count-1); i++ ) {
            mdrs[i] = manager.getRepository( mdrNames[i] );
        }
        if (i < mdrNames.length) {
            ArrayList list = new ArrayList ();
            for (;i< mdrNames.length;i++) {
                list.add (manager.getRepository(mdrNames[i]));
            }
            mdrs[count-1] = new DataRestWrapper (new Collection[]{list},0);
        }
        return mdrs;
    }
}
