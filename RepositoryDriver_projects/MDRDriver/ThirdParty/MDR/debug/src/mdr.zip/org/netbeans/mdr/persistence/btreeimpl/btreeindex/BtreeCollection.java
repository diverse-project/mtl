/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.mdr.persistence.btreeimpl.btreeindex;
import org.netbeans.mdr.persistence.*;
import java.io.*;
import java.util.*;

/**
 * This is the read-only Collection interface to the set of values contained 
 * in a SinglevaluedBtree.
 *
 * @author	Dana Bergen
 * @version	1.0
 */
public class BtreeCollection extends AbstractCollection {

    protected Btree btree;

    /**
     * Construct a Collection view of a btree.
     *
     * @param	btree	the btree
     */
    public BtreeCollection(Btree btree) {
        this.btree = btree;
    }

    /**
     * Returns the number of items in this btree
     */
    public int size() {
        try {
	    btree.beginRead();
            return btree.countRecords();
	} catch (StorageException e) {
	} finally {
	    btree.endRead();
	}
	return 0;
    }

    /**
     * Returns an iterator on this BtreeCollection
     */
    public Iterator iterator() {
        return new BtreeIterator(btree);
    }
}
