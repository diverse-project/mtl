/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrtoolkit.looks.reflect;

import java.util.ResourceBundle;
import java.util.Collections;
import java.util.Collection;
import javax.jmi.reflect.*;
import javax.jmi.model.MofClass;

import org.openide.nodes.Node;
import org.openide.nodes.Sheet;
import org.openide.util.actions.SystemAction;
import org.openide.util.NbBundle;
import org.netbeans.api.mdr.*;
import org.openide.util.SharedClassObject;

import org.openidex.nodes.looks.*;

/** Implements MOF models defaut view.
 *
 * @author  Petr Hrebejk
 */
public class Instance extends DefaultLook {
   
    /*
    private static final ResourceBundle bundle = NbBundle.getBundle( Instance.class );
    
    private  static final String ICON_BASE =
        "/org/netbeans/modules/metabrowser/mof/resources/default"; // NOI18N
    
    public Instance() {
        super( Instance.Matter.class );
    }
    
    public String getName(Node node) {
        
        Instance.Matter m = (Instance.Matter)node.getCookie( Matter.class );
        
        String name = ((MofClass)m.getRefObject().refMetaObject()).getName();
        return name;
    }
    
    public String getIconBase(Node node) {
        return ICON_BASE;
    }
    
    public static class Matter extends BaseObject.Matter {
        
        public Matter( RefObject refObject ) {
            super(refObject);
        }
        
        public RefObject getRefObject() {
            return (RefObject) getRefBaseObject();
        }
        
    }
     */
}
