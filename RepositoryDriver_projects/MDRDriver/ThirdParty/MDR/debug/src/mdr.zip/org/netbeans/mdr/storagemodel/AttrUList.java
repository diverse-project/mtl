/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.mdr.storagemodel;

import java.util.*;

import java.io.InputStream;
import java.io.IOException;

import javax.jmi.reflect.*;
import org.netbeans.mdr.persistence.MOFID;
import org.netbeans.mdr.persistence.StorageException;

/**
 *
 * @author  mm109185
 */
public class AttrUList extends AttrList {
    private Set innerSet = new HashSet();
    
    public AttrUList() {
        super();
    }
    
    AttrUList(StorableFeatured mdrObject, StorableClass.AttributeDescriptor desc) throws StorageException {
        this(mdrObject, desc, null);
    }
    
    protected AttrUList(StorableFeatured mdrObject, StorableClass.AttributeDescriptor desc, List values) throws StorageException {
        super(mdrObject, desc, values);
        
        for (Iterator it = inner.iterator(); it.hasNext();) {
            Object value = it.next();
            if (!innerSet.add(value)) {
                throw new DuplicateException(value, getMetaElement());
            }
        }
    }

    protected AttrUList(StorableFeatured mdrObject, List values, int maxSize, Class type, String attrName, boolean isRefObject, MOFID metaMofId, Set innerSet) {
        super(mdrObject, values, maxSize, type, attrName, isRefObject, metaMofId);
        this.innerSet = innerSet;
    }
    
    public void read(InputStream stream, StorableFeatured storable) throws IOException {
        super.read(stream, storable);
        innerSet.addAll(inner);
    }
    
    public boolean remove(Object obj) {
        super.remove(obj);
        return innerSet.remove(obj);
    }
    
    public Object set(int param, Object obj) {
        Object retValue;
        retValue = super.set(param, obj);
        innerSet.remove(retValue);
        if (!innerSet.add(obj)) {
            throw new DuplicateException(obj, getMetaElement());
        }
        return retValue;
    }
    
    public ListIterator listIterator(int param) {
        return new AttrUListIterator(innerList.listIterator(param));
    }
    
    public Iterator iterator() {
        return new AttrUListIterator(innerList.listIterator());
    }
    
    public ListIterator listIterator() {
        return new AttrUListIterator(innerList.listIterator());
    }
    
    public Object remove(int param) {
        Object retValue;
        retValue = super.remove(param);
        innerSet.remove(retValue);
        return retValue;
    }
    
    public void add(int param, Object obj) {
        super.add(param, obj);
        if (!innerSet.add(obj)) {
            throw new DuplicateException(obj, getMetaElement());
        }
    }
    
    public boolean add(Object obj) {
        super.add(obj);
        return innerSet.add(obj);
    }
    
    public List subList(int param, int param1) {
        return new AttrUList(mdrObject, innerList.subList(param, param1), maxSize, type, attrName, isRefObject, metaMofId, innerSet);
    }
    
    public boolean contains(Object obj) {
        return innerSet.contains(obj);
    }
    
    public boolean containsAll(Collection collection) {
        return innerSet.containsAll(collection);
    }
    
    protected class AttrUListIterator extends AttrListIterator {
        protected AttrUListIterator(ListIterator iterator) {
            super(iterator);
        }
        
        public void remove() {
            super.remove();
            innerSet.remove(lastRead);
        }
        
        public void add(Object obj) {            
            if (!innerSet.add(obj)) {
                throw new DuplicateException(obj, getMetaElement());
            }
            super.add(obj);
        }
        
        public void set(Object obj) {
            super.set(obj);
            innerSet.remove(lastRead);
            if (!innerSet.add(obj)) {
                throw new DuplicateException(obj, getMetaElement());
            }
        }
    }
}
