/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.lib.jmi.query;

import java.util.Comparator;

import javax.jmi.model.*;
import javax.jmi.reflect.RefFeatured;

/** Abstract class for creating filter queries.
 *
 * @author Petr Hrebejk
 */
public class JavaIofFilter extends FilterQuery {
    
    /** Name of the feature to filter by */
    protected String featureName;
    
    private java.lang.Class clazz = null;
    
    public JavaIofFilter(Query query, java.lang.Class clazz) {
        super( query );
        this.clazz = clazz;
    }
     
    
    protected boolean accept( Object object ) {
        
        if ( clazz.isInstance( object ) ) {
            return true;
        }
        return false;
    }
    
    
}
