/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.mdr.persistence.btreeimpl.btreestorage;

import java.util.Map;
import org.netbeans.mdr.persistence.*;
import org.netbeans.mdr.util.Logger;

/**
* Create a BtreeStorage
*/
public class BtreeFactory implements StorageFactory {
    public static final String DEFAULT_FILE_NAME = "mdr";
    public static final String STORAGE_FILE_NAME = "org.netbeans.mdr.persistence.btreeimpl.filename";       // NOI18N
    
    // Btree MOFID constnants
    static final public int SAME_PREFIX_CODE = 0;
    static final public int INTERNAL_PREFIX_CODE = 1;
    static final public int FIRST_EXTERNAL_CODE = 2;

    static final private byte SAME_MOFID_GENERATOR = 0;
    static final private byte OTHER_MOFID_GENERATOR = 1;
    static final private byte NO_MOFID_GENERATOR = 2;

    /* MOFIDs lower than this are internal, and use the
       internal prefix */
    static final public int FIRST_EXTERNAL_ID = 128;

    /* prefix used for internal objects */
    static final public String INTERNAL_PREFIX = "00000000-0000-0000-0000-000000000000";
    
        /** MOFID signifying null MOFID */
    public static MOFID nullMOFID = new MOFID(1, INTERNAL_PREFIX);

    /** MOFID for index of secondary indexes */
    public static MOFID indexIndexId = new MOFID(2, INTERNAL_PREFIX);

    /** MOFID for index of classes stored in repository */
    public static MOFID classIndexId = new MOFID(3, INTERNAL_PREFIX);

    /** Creates BtreeStorage
    * @parameter name base name of Btree files
    */
    public Storage createStorage (Map properties) throws StorageException {
        String name = (String) properties.get (STORAGE_FILE_NAME);
        if (name == null) {
            name = DEFAULT_FILE_NAME;
            Logger.getDefault().log(Logger.WARNING, "Property " + STORAGE_FILE_NAME + " not specified. Using default value: " + DEFAULT_FILE_NAME);
        }
        Logger.getDefault().log("Storage file name: " + name);
        return new BtreeStorage(name);
    }

    /** null MOFID */
    public org.netbeans.mdr.persistence.MOFID createNullMOFID () {
    	return nullMOFID;
    }
}

    
