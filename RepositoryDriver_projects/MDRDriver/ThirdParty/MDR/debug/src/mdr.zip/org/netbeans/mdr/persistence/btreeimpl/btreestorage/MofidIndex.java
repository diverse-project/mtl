/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.mdr.persistence.btreeimpl.btreestorage;

import java.io.*;
import java.text.*;
import java.util.*;
import org.netbeans.mdr.persistence.*;
import org.netbeans.mdr.persistence.btreeimpl.btreeindex.*;

/**
* This is an index from names (Strings) to MOFIDs.  Its primary use is to 
* store the MOFIDs for secondary indexes.
*/
public class MofidIndex extends NameIndex implements StorageClient {

    /* MOFID generator */
    BtreeStorage storage;

    /** Create a new MofidIndex  */
    public MofidIndex() {
    }

    /** Create a new MofidIndex  */
    public MofidIndex(BtreeStorage storage) {
        super();
        this.storage = storage;
    }

    /** get a MOFID by its name.  If none exists, throw an exception
    * @param name the name associated with the MOFID
    */
    public synchronized MOFID get(String name)throws StorageException  {
    	return (MOFID)getObj(name);
    }

    /**
    * Add a name-MOFID pair to the MofidIndex.  If one already existed,
    * throw an exception.
    * @param name name of object to add to index
    * @param id MOFID of object to add
    */
    public synchronized void add(String name, MOFID id) throws StorageException {
    	addObj(name, id);
    }

    /**
    * write object to stream.  Used by serialization.
    * @param obj object to write
    * @param strm stream to write it to
    */
    protected void writeObjectToStream(Object obj, DataOutputStream strm) 
    	throws StorageException {
            this.storage.writeMOFIDData (strm, (MOFID) obj);
    }

    /**
    * read object from stream.  Used by deserialization.
    * @param strm stream to read from
    * @return obj object read
    */
    protected Object readObjectFromStream(DataInputStream strm) 
    	throws StorageException {
	return this.storage.readMOFIDData (strm);
    }

    /** called on deserialization */
    public void setStorage(Storage storage) {
    	this.storage = ((BtreeStorage)storage);
    }
}



