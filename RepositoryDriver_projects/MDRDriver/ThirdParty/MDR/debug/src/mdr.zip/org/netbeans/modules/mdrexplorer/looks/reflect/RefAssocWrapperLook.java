/*
 *                 Sun Public License Notice
 *
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 *
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrexplorer.looks.reflect;


import org.netbeans.modules.mdrexplorer.looks.reflect.*;
import org.netbeans.modules.mdrexplorer.looks.reflect.actions.*;
import java.util.*;
import javax.jmi.reflect.*;
import javax.jmi.model.*;
import org.netbeans.api.looks.*;
import org.netbeans.modules.mdrexplorer.looks.DataRestWrapper;
import org.netbeans.modules.mdrexplorer.looks.RepositoryCache;
import org.netbeans.modules.mdrexplorer.looks.MDREventHandler;
import org.netbeans.modules.mdrexplorer.looks.DataRestWrapper;
import org.netbeans.api.mdr.MDRepository;
import org.netbeans.api.mdr.MDRObject;
/**
 *
 * @author  ms118741, Tomas Zezula
 * @version
 */
public class RefAssocWrapperLook extends BaseObjectLook {
    
    /** Creates new RefObjectLook */
    public RefAssocWrapperLook() {
        super(Utils.getLocalizedString("TXT_RefAssocWrapperLook"));
    }
    
    public String toString() {
        return "MOF/RefAssocWrapper::ALL"; // NOI18N
    }
    
    
    public Object attachTo (Look.NodeSubstitute substitute) {
        super.attachTo (substitute);
        RepositoryCache cache = RepositoryCache.getRepositoryCache();
        MDRepository repository = ((MDRObject)((RefAssocWrapper)substitute.getRepresentedObject()).getRefAssociation()).repository();
        MDREventHandler handler = cache.getEventHandler (repository);
        if (handler != null) {
            handler.addNodeSubstitute(((RefAssocWrapper)substitute.getRepresentedObject()).getRefAssociation(),substitute);
        }
        return handler;
    }
    
    
    public String getName( Look.NodeSubstitute substitute ) {
        return Utils.getRefObjectName( ((RefAssocWrapper)substitute.getRepresentedObject()).getMetaAssociationEnd() );
    }
    
    public String getDisplayName(Look.NodeSubstitute substitute) {
        return this.getName(substitute);
    }
    
    public Object[] getChildObjects( Look.NodeSubstitute substitute ) {
        RefAssociation refAssoc = ((RefAssocWrapper)substitute.getRepresentedObject()).getRefAssociation();
        AssociationEnd associationEnd = ((RefAssocWrapper)substitute.getRepresentedObject()).getMetaAssociationEnd();
        boolean isFirstEnd = ((RefAssocWrapper)substitute.getRepresentedObject()).isFirstEnd();
        MDRepository rep = ((MDRObject)refAssoc).repository ();
        rep.beginTrans (false);
        try {
            Collection links = refAssoc.refAllLinks();
            int count = this.getBrowserChildCount ();
            boolean[] completionFlag = new boolean[1];
            Collection result = Utils.getRefLinkEndWrappers(links,refAssoc,associationEnd, isFirstEnd,count,0,completionFlag);
            if (!completionFlag[0]) {
                result.add ( new DataRestWrapper (new Collection[] {links},count,DataRestWrapper.ASSOC_END,substitute.getRepresentedObject()));
            }
            return result.toArray ();
        } finally {
            rep.endTrans ();
        }
    }
    
    /* No actions
     * override parent's properties action
     */
    public javax.swing.Action[] getActions (Look.NodeSubstitute substitute) {
        return new javax.swing.Action[0];
    }
    
}
