/*
 *                 Sun Public License Notice
 *
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 *
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.lib.jmi.xmi;

import org.netbeans.api.xmi.*;

import javax.jmi.reflect.RefPackage;
import javax.jmi.xmi.MalformedXMIException;

import java.util.*;
import java.io.*;
import java.net.URL;
import org.xml.sax.*;
import javax.xml.parsers.ParserConfigurationException;
import org.netbeans.lib.jmi.util.Logger;

public class SAXReader extends XMIReader {
        
    private XMIInputConfig config;
    
    // init .....................................................................
    
    public SAXReader () {
        this (null);
    }
    
    public SAXReader (XMIInputConfig cfg) {
        this.config = new InputConfig ();
        if (cfg != null) { 
            this.config.setReferenceResolver (cfg.getReferenceResolver ());
            if (config instanceof InputConfig)
                ((InputConfig)this.config).setHeaderConsumer(((InputConfig)cfg).getHeaderConsumer());
        }
    }
    
    // methods ..................................................................
    
    public XMIInputConfig getConfiguration() {
        return config;
    }
    
    public Collection read (InputStream stream, String uri, RefPackage extent) throws IOException, MalformedXMIException {
        // [PENDING] correct this code to throw exceptions correctly
        try {
            // [PENDING] correct this call to use both stream and URI
            return new XmiSAXReader (config).read (stream, uri, new RefPackage[] {extent}, null);
        } catch (ParserConfigurationException e) {
            MalformedXMIException ne = new MalformedXMIException(e.toString());
            Logger.getDefault().annotate(ne, e);
            throw ne;
        } catch (SAXException e) {
            MalformedXMIException ne = new MalformedXMIException(e.toString());
            Logger.getDefault().annotate(ne, e);
            throw ne;
        }
    }
    
    public Collection read (String uri, RefPackage extent) 
    throws IOException, MalformedXMIException {
        return read (new URL(uri), new RefPackage[] {extent}, null);
    }
    
    private Collection read (URL url, RefPackage[] extents, String encoding)
        throws IOException, MalformedXMIException {
        // [PENDING] correct this code to throw exceptions correctly
        try {
            return new XmiSAXReader (config).read (url, extents, encoding);
        } catch (ParserConfigurationException e) {
            MalformedXMIException ne = new MalformedXMIException(e.toString());
            Logger.getDefault().annotate(ne, e);
            throw ne;
        } catch (SAXException e) {
            MalformedXMIException ne = new MalformedXMIException(e.toString());
            Logger.getDefault().annotate(ne, e);
            throw ne;
        }
    }
    
}
