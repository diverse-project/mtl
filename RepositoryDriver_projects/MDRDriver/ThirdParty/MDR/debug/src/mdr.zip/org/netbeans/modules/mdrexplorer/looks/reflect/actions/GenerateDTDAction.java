/*
 *                 Sun Public License Notice
 *
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 *
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrexplorer.looks.reflect.actions;

import org.netbeans.modules.mdrexplorer.looks.reflect.*;

import org.openide.TopManager;
import org.openide.NotifyDescriptor;
import org.openide.nodes.Node;
import org.openide.util.*;
import org.openide.util.actions.NodeAction;
import org.openide.filesystems.FileSystem;
import org.openide.filesystems.FileObject;
import org.openide.loaders.*;

import org.netbeans.api.looks.*;

import org.netbeans.api.mdr.*;

import javax.jmi.reflect.*;

import java.util.ResourceBundle;
import java.io.File;
import java.io.FileOutputStream;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;

public class GenerateDTDAction extends NodeAction {
    
    /** Resource bundle */
    private static final ResourceBundle bundle = NbBundle.getBundle(Utils.class);
    
    protected void performAction(Node[] nodes) {
        generateDTD( nodes [0] );
    }
    
    private void generateDTD( Node node ) {
        final TopManager tm = TopManager.getDefault();
        File temp = null;
        // selects one folder from data systems
        JFileChooser chooser = new JFileChooser();
        // Note: source for ExampleFileFilter can be found in FileChooserDemo,
        // under the demo/jfc directory in the Java 2 SDK, Standard Edition.
        chooser.setFileFilter(new XMIFileFilter());
        java.awt.Component parent = tm.getWindowManager().getMainWindow();
        int returnVal = org.openide.util.Utilities.showJFileChooser(chooser, parent, bundle.getString("LAB_DTDGeneration"));
        if(returnVal == JFileChooser.APPROVE_OPTION) {
            temp = chooser.getSelectedFile();
        }
        final File file = temp;
        final RefPackage refPackage = (RefPackage) ((LookNode) node).getRepresentedObject();

        if (file != null) {
            // map the interfaces in a background thread
            RequestProcessor.postRequest(new Runnable() {
                public void run() {
                    tm.setStatusText(bundle.getString("CTL_DTDGenerationStarted"));
                    try {
                        FileOutputStream fos = new FileOutputStream( file );
                        DTDProducer producer = DTDProducer.getDefault();                                                
                        MDRepository rep = ((MDRObject) refPackage).repository();
                        rep.beginTrans(false);
                        try {
                            producer.generate(fos, refPackage);
                        } finally {
                            rep.endTrans();
                        }                        
                    } catch (java.io.IOException ioex) {
                        org.openide.TopManager.getDefault().getErrorManager().notify ( ioex );
                    }
                    finally {
                        tm.setStatusText(bundle.getString("CTL_DTDGenerationFinished"));
                    }
                }
            });
        }
    }
    
    protected boolean enable(Node[] nodes) {
        if ((nodes == null) || (nodes.length != 1) || !(nodes[0] instanceof LookNode) ||
            !(((LookNode)nodes[0]).getRepresentedObject() instanceof RefPackage))
            return false;
        else
            return true;        
    }
    
    public String getName() {
        return bundle.getString("CTL_ACTION_DTDGeneration");
    }
    
    protected String iconResource() {
        return null;
    }
    
    public HelpCtx getHelpCtx() {
        return HelpCtx.DEFAULT_HELP;
        // If you will provide context help then use:
        // return new HelpCtx (GenerateInterfacesActionAction.class);
    }
    
    private static final class XMIFileFilter extends FileFilter {
        public boolean accept(File f) {
            return f.getName().toUpperCase().endsWith(".DTD") || f.getName().toUpperCase().endsWith(".XMI") || f.isDirectory();
        }
        
        public String getDescription() {
            return bundle.getString("CTL_DTDFiles");
        }
    }
}