/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrexplorer.looks.reflect.actions;

import org.netbeans.modules.mdrexplorer.looks.reflect.*;

import org.openide.TopManager;
import org.openide.NotifyDescriptor;
import org.openide.nodes.Node;
import org.openide.util.*;
import org.openide.util.actions.NodeAction;
import org.openide.filesystems.FileSystem;
import org.openide.filesystems.FileObject;
import org.openide.loaders.*;

import org.netbeans.api.looks.*;

import org.netbeans.api.mdr.*;

import javax.jmi.reflect.*;

import org.w3c.dom.Document;

import java.util.ResourceBundle;
import java.io.File;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;

/** Action sensitive to the node selection that does something useful.
 *
 * @author  Martin Matula
 */
public class LoadXMIAction extends NodeAction {

    /** Resource bundle */
    private static final ResourceBundle bundle = NbBundle.getBundle(Utils.class);

    protected void performAction (Node[] nodes) {
        Node node = nodes[0];
        if (node instanceof LookNode) {
            loadXMI( (LookNode)node );
        }
    }

    private void loadXMI(LookNode lookNode) {
        if ( (!(lookNode.getRepresentedObject() instanceof RefPackage)) &&
             (!(lookNode.getRepresentedObject() instanceof org.openide.TopManager) ) ) {
            throw new IllegalArgumentException("Load XMI action can not be applied to this node : " + lookNode.getRepresentedObject());
        }

        final TopManager tm = TopManager.getDefault();
        final File file;

        File temp = null;
        // selects one folder from data systems
        JFileChooser chooser = new JFileChooser();
        // Note: source for ExampleFileFilter can be found in FileChooserDemo,
        // under the demo/jfc directory in the Java 2 SDK, Standard Edition.
        chooser.setFileFilter(new XMIFileFilter());
	
	java.awt.Component parent = tm.getWindowManager().getMainWindow();
        int returnVal = org.openide.util.Utilities.showJFileChooser(chooser, parent, null);
        if(returnVal == JFileChooser.APPROVE_OPTION) {
            temp = chooser.getSelectedFile();
        }
        file = temp;

        RefPackage refPackage = null;
        if (lookNode.getRepresentedObject() instanceof org.openide.TopManager) {
            org.netbeans.api.mdr.MDRepository repository = 
                org.netbeans.api.mdr.MDRManager.getDefault().getDefaultRepository(); 
            String newName = null;
            NotifyDescriptor.InputLine nd = new NotifyDescriptor.InputLine(bundle.getString("CTL_Instantiate"), bundle.getString("CTL_NewPackageName"));
            if (tm.notify(nd).equals(NotifyDescriptor.OK_OPTION)) {
                newName = nd.getInputText();
            }
        
            try {
                refPackage = repository.createExtent(newName);
            } catch (org.netbeans.api.mdr.CreationFailedException  mer ) {
                org.openide.TopManager.getDefault().getErrorManager().notify (mer);
            } 
        } else if (lookNode.getRepresentedObject() instanceof RefPackage) {
            refPackage = (RefPackage)lookNode.getRepresentedObject();
        }

        final RefPackage refFinalPackage = refPackage;
        refPackage = null;
        
        if (file != null) {
            // map the interfaces in a background thread
            RequestProcessor.postRequest(new Runnable() {
                public void run() {
                    tm.setStatusText(bundle.getString("CTL_XMIImportStarted"));
                    boolean fail = true;
                    MDRepository rep = ((MDRObject) refFinalPackage).repository();
                    try {
                        rep.beginTrans(true);
                        // Read the XMI document
                        XMIReader xmiReader = XMIReader.getDefault();
                        xmiReader.read(file.toURL().toString(), new RefPackage[] { refFinalPackage });
                        fail = false;
                    } catch (Exception ioex) {
                        TopManager.getDefault().notifyException(ioex);
                    } finally {
                        rep.endTrans(fail);
                        tm.setStatusText(bundle.getString("CTL_XMIImportFinished"));
                    }
                }
            });
        }
    }

    protected boolean enable (Node[] nodes) {
        if (nodes.length == 1) {
            /*
            Matter m = (Matter) nodes[0].getCookie(Matter.class);
            return (m instanceof PackageProxy.Matter) && ((PackageProxy.Matter) m).getRefPackage().refOutermostPackage() == null;
             */
            return true;
        }
        
        return false;
    }

    public String getName () {
        return bundle.getString("CTL_ACTION_XMIImport");
    }

    protected String iconResource () {
        return null;
    }

    public HelpCtx getHelpCtx () {
        return HelpCtx.DEFAULT_HELP;
        // If you will provide context help then use:
        // return new HelpCtx (GenerateInterfacesActionAction.class);
    }

    private static final class XMIFileFilter extends FileFilter {
        public boolean accept(File f) {
            return f.getName().toUpperCase().endsWith(".XML") || f.getName().toUpperCase().endsWith(".XMI") || f.isDirectory();
        }
        
        public String getDescription() {
            return bundle.getString("CTL_XMIFiles");
        }
    }
}
