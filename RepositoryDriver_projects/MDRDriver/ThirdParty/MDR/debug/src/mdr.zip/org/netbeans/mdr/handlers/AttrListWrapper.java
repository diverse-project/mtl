/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.mdr.handlers;

import java.util.*;
import org.netbeans.api.mdr.events.AttributeEvent;
import org.netbeans.mdr.util.EventNotifier;

/**
 *
 * @author  mm109185
 */
public final class AttrListWrapper extends AttrCollWrapper implements List {
    private final List innerList;
    
    /** Creates new ListWrapper */
    public AttrListWrapper(FeaturedHandler source, List innerList) {
        super(source, innerList);
        this.innerList = innerList;
    }
    
    public Object remove(int param) {
        boolean fail = true;
        try {
            lock(true);
            AttributeEvent event = new AttributeEvent(
                source, 
                isStatic ? AttributeEvent.EVENT_CLASSATTR_REMOVE : AttributeEvent.EVENT_ATTRIBUTE_REMOVE,
                attrName,
                get(param), null,
                param);
            notifier.firePlannedChange(source, event);
            Object result = innerList.remove(param);
            fail = false;
            return result;
        } finally {
            unlock(fail);
        }
    }
    
    public ListIterator listIterator(int param) {
        try {
            lock(false);
            return new AttrListIteratorWrapper(innerList.listIterator(param));
        } finally {
            unlock();
        }
    }
    
    public void add(int param, Object obj) {
        boolean fail = true;
        try {
            lock(true);
            AttributeEvent event = new AttributeEvent(
                source, 
                isStatic ? AttributeEvent.EVENT_CLASSATTR_ADD : AttributeEvent.EVENT_ATTRIBUTE_ADD,
                attrName,
                null, obj,
                param);
            notifier.firePlannedChange(source, event);
            innerList.add(param, obj);
            fail = false;
        } finally {
            unlock(fail);
        }
    }
    
    public int indexOf(Object obj) {
        try {
            lock(false);
            return innerList.indexOf(obj);
        } finally {
            unlock();
        }
    }
    
    public int lastIndexOf(Object obj) {
        try {
            lock(false);
            return innerList.lastIndexOf(obj);
        } finally {
            unlock();
        }
    }
    
    public Object get(int param) {
        try {
            lock(false);
            return innerList.get(param);
        } finally {
            unlock();
        }
    }
    
    public Object set(int param, Object obj) {
        boolean fail = true;
        try {
            lock(true);
            AttributeEvent event = new AttributeEvent(
                source, 
                isStatic ? AttributeEvent.EVENT_CLASSATTR_SET : AttributeEvent.EVENT_ATTRIBUTE_SET,
                attrName,
                get(param), obj,
                param);
            notifier.firePlannedChange(source, event);
            Object result = innerList.set(param, obj);
            fail = false;
            return result;
        } finally {
            unlock(fail);
        }
    }
    
    public boolean addAll(int param, Collection collection) {
        boolean fail = true;
        try {
            lock(true);
            for (Iterator it = collection.iterator(); it.hasNext();) {
                add(param++, it.next());
            }
            fail = false;
            return true;
        } finally {
            unlock(fail);
        }
    }
    
    public ListIterator listIterator() {
        try {
            lock(false);
            return new AttrListIteratorWrapper(innerList.listIterator());
        } finally {
            unlock();
        }
    }
    
    public List subList(int param, int param1) {
        try {
            lock(false);
            AttrListWrapper result = new AttrListWrapper(source, innerList.subList(param, param1));
            result.setAttrName(attrName);
            return result;
        } finally {
            unlock();
        }
    }
    
    private final class AttrListIteratorWrapper extends AttrIteratorWrapper implements ListIterator {
        private final ListIterator innerListIterator;
        protected int lastReadIndex = 0;
        
        AttrListIteratorWrapper(ListIterator innerIterator) {
            super(innerIterator);
            this.innerListIterator = innerIterator;
        }
        
        public int previousIndex() {
            try {
                lock(false);
                return innerListIterator.previousIndex();
            } finally {
                unlock();
            }
        }
        
        public void set(Object obj) {
            boolean fail = true;
            try {
                lock(true);
                AttributeEvent event = new AttributeEvent(
                    source, 
                    isStatic ? AttributeEvent.EVENT_CLASSATTR_SET : AttributeEvent.EVENT_ATTRIBUTE_SET,
                    attrName,
                    lastRead, obj,
                    lastReadIndex);
                notifier.firePlannedChange(source, event);
                innerListIterator.set(obj);
                fail = false;
            } finally {
                unlock(fail);
            }
        }
        
        public int nextIndex() {
            try {
                lock(false);
                return innerListIterator.nextIndex();
            } finally {
                unlock();
            }
        }
        
        public boolean hasPrevious() {
            try {
                lock(false);
                return innerListIterator.hasPrevious();
            } finally {
                unlock();
            }
        }
        
        public void add(Object obj) {
            boolean fail = true;
            try {
                lock(true);
                AttributeEvent event = new AttributeEvent(
                    source, 
                    isStatic ? AttributeEvent.EVENT_CLASSATTR_ADD : AttributeEvent.EVENT_ATTRIBUTE_ADD,
                    attrName,
                    null, obj,
                    nextIndex());
                notifier.firePlannedChange(source, event);
                innerListIterator.add(obj);
                fail = false;
            } finally {
                unlock(fail);
            }
        }
        
        public final void remove() {
            boolean fail = true;
            try {
                lock(true);
                AttributeEvent event = new AttributeEvent(
                    source, 
                    isStatic ? AttributeEvent.EVENT_CLASSATTR_REMOVE : AttributeEvent.EVENT_ATTRIBUTE_REMOVE,
                    attrName,
                    lastRead, null,
                    lastReadIndex);
                notifier.firePlannedChange(source, event);
                innerIterator.remove();
                fail = false;
            } finally {
                unlock(fail);
            }
        }

        public Object previous() {
            try {
                lock(false);
                lastReadIndex = previousIndex();
                return (lastRead = innerListIterator.previous());
            } finally {
                unlock();
            }
        }
        
        public Object next() {
            try {
                lock(false);
                lastReadIndex = nextIndex();
                return super.next();
            } finally {
                unlock();
            }
        }
    }
}
