/*
 *                 Sun Public License Notice
 *
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 *
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrexplorer.looks.reflect;


import org.netbeans.modules.mdrexplorer.looks.reflect.*;
import org.netbeans.modules.mdrexplorer.looks.reflect.actions.*;
import java.util.*;
import java.awt.*;
import javax.jmi.reflect.*;
import javax.jmi.model.*;
import org.openide.util.actions.SystemAction;
import org.openide.util.SharedClassObject;
import org.netbeans.api.mdr.*;
import org.netbeans.api.looks.*;
import org.netbeans.modules.mdrexplorer.looks.DataRestWrapper;
/**
 *
 * @author  ms118741, Tomas Zezula
 * @version
 */
public class RefGetValueWrapperLook extends BaseObjectLook {
    
    
    /** Creates new RefObjectLook */
    public RefGetValueWrapperLook() {
        super(Utils.getLocalizedString("TXT_RefGetValueWrapperLook"));
    }
    
    public String toString() {
        return "MOF/RefGetValueWrapper::ALL"; // NOI18N
    }
    
    
    public String getName( Look.NodeSubstitute substitute ) {
        return Utils.getRefObjectName( ((RefGetValueWrapper)substitute.getRepresentedObject()).getMetaFeature() );
    }
    
    public String getDisplayName(Look.NodeSubstitute substitute) {
        return this.getName(substitute);
    }
    
    public Object[] getChildObjects( Look.NodeSubstitute substitute ) {
        ArrayList result = new ArrayList();
        RefFeatured refFeatured = ((RefGetValueWrapper)substitute.getRepresentedObject()).getFeatured();
        RefObject refObject = ((RefGetValueWrapper)substitute.getRepresentedObject()).getMetaFeature();
        MDRepository repository = ((MDRObject)refFeatured).repository();
        repository.beginTrans(false);
        try {
            Object value =  refFeatured.refGetValue((StructuralFeature) refObject);
            int count = this.getBrowserChildCount();
            count = (count ==-1 ? Integer.MAX_VALUE : count);
            if (value instanceof Collection) {
                Iterator itValue = ((Collection)value).iterator();
                for (int i=0; itValue.hasNext() && i<count;) {
                    Object collectionValue = itValue.next();
                    if (collectionValue != null && !result.contains( collectionValue )) {
                        result.add( collectionValue );
                        i++;
                    }
                }
                if (itValue.hasNext()) {
                    result.add( new DataRestWrapper(new Collection[] {(Collection)value},count));
                }
            } else {
                if (value != null && count > 0) {
                    result.add( value );
                }
                else if (value != null) {
                    ArrayList list = new ArrayList();
                    list.add(value);
                    result.add(new DataRestWrapper(new Collection[] {list},0));
                }
            }
            return result.toArray();
        }finally {
            repository.endTrans();
        }
    }
    
    /* No actions
     *  override parrent's properties action
     */
    public javax.swing.Action[] getActions(Look.NodeSubstitute substitute) {
        return new javax.swing.Action[0];
    }
    
}
