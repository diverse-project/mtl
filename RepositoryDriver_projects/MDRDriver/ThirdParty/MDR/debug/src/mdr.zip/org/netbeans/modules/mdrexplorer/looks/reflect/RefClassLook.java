/*
 *                 Sun Public License Notice
 *
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 *
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrexplorer.looks.reflect;

import java.util.Collection;
import java.util.Iterator;
import javax.jmi.reflect.*;
import javax.jmi.model.MofClass;
import org.netbeans.api.mdr.*;
import org.netbeans.api.looks.*;
import org.netbeans.modules.mdrexplorer.looks.RepositoryCache;
import org.netbeans.modules.mdrexplorer.looks.MDREventHandler;
import org.netbeans.modules.mdrexplorer.looks.DataRestWrapper;
/** Implements MOF models defaut view.
 *
 * @author  Petr Hrebejk, Tomas Zezula
 */
public class RefClassLook extends BaseObjectLook {
    
    /** Creates new ClassProxyLook
     */
    public RefClassLook() {
        super(Utils.getLocalizedString("TXT_RefClassLook"));
    }
    
    public Object attachTo(Look.NodeSubstitute substitute) {
        super.attachTo(substitute);
        RepositoryCache cache = RepositoryCache.getRepositoryCache();
        MDREventHandler handler = cache.getEventHandler(((org.netbeans.api.mdr.MDRObject)substitute.getRepresentedObject()).repository());
        if (handler != null)
            handler.addNodeSubstitute(substitute);
        return handler;
    }
    
    public String toString() {
        return "MOF/ClassProxy::ALL"; // NOI18N
    }
    
    public String getName( Look.NodeSubstitute substitute ) {
        RefClass rc = (RefClass)substitute.getRepresentedObject();
        return ((MofClass)rc.refMetaObject()).getName();
    }
    
    public Object[] getChildObjects( Look.NodeSubstitute substitute ) {
        RefClass rc = (RefClass)substitute.getRepresentedObject();
        MDRepository repo = ((MDRObject)rc).repository();
        repo.beginTrans(false);
        try {
            Collection objs = rc.refAllOfClass();
            int count = this.getBrowserChildCount();
            count = (count ==-1 ? Integer.MAX_VALUE : count+1);
            Object[] children = new Object[ Math.min(objs.size(),count) ];
            Iterator it = objs.iterator();
            for (int i=0; it.hasNext() && i<count-1; i++) {
                children[i] = it.next();
            }
            if (it.hasNext()) {
                children[children.length-1] = new DataRestWrapper(new Collection [] {objs}, count-1);
            }
            return children;
        }finally {
            repo.endTrans();
        }
    }
}

