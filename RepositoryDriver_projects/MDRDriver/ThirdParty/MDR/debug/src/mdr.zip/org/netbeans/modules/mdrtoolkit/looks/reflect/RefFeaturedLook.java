/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrtoolkit.looks.reflect;

import org.netbeans.modules.mdrtoolkit.looks.reflect.properties.*;

import org.netbeans.modules.mdrtoolkit.looks.reflect.*;
import org.netbeans.modules.mdrtoolkit.looks.reflect.actions.*;

import java.util.*;
import java.awt.*;
import javax.jmi.reflect.*;
import javax.jmi.model.*;

import org.openide.util.actions.SystemAction;
import org.openide.util.SharedClassObject;


import org.openidex.nodes.looks.*;
import java.beans.PropertyEditor;
import java.beans.PropertyEditorSupport;
import org.openide.nodes.*;
import org.openidex.nodes.looks.*;
/**
 *
 * @author  ms118741
 * @version 
 */
public class RefFeaturedLook extends AcceptorLook.Type {

    /** Creates new RefObjectLook */
    public RefFeaturedLook() {
        super( new Delegate(), RefFeatured.class, true );
    }

    public String toString() {
        return "MOF/RefFeatured::ALL"; // NOI18N
    }

    private static class Delegate extends BaseObjectLook {
    
        public String getName( Look.NodeSubstitute substitute ) {
            return Utils.getRefObjectName(substitute) + " [" + Utils.getRefObjectMetaName(substitute) + "]";
        }

        public Node.PropertySet[] getPropertySets( Look.NodeSubstitute substitute ) {
            return RefFeaturedProps.getPropertySets( (RefFeatured)substitute.getRepresentedObject(), substitute );
        }
    }
}
