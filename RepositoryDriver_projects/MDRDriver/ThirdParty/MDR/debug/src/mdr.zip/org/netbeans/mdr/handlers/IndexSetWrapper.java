/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.mdr.handlers;

import java.util.*;
import java.lang.reflect.Array;
import javax.jmi.reflect.RefBaseObject;

import org.netbeans.mdr.storagemodel.*;
import org.netbeans.mdr.util.DebugException;

/**
 * Wraps collection of storage content with handlers.
 *
 * @author  mm109185
 */
public class IndexSetWrapper implements Collection {
    protected final Collection inner;
    protected final MdrStorage storage;
    
    /** Creates new CollectionWrapper */
    public IndexSetWrapper(MdrStorage mdrStorage, Collection inner) {
        this.inner = inner;
        this.storage = mdrStorage;
    }
    
    protected void lock(boolean writeAccess) {
        storage.getRepositoryMutex().enter(writeAccess);
    }
    
    protected void unlock() {
        storage.getRepositoryMutex().leave();
    }
    
    protected void unlock(boolean fail) {
        storage.getRepositoryMutex().leave(fail);
    }
    
    protected static Object wrap(Object obj) {
        if (obj == null) {
            return null;
        } else if (obj instanceof StorableBaseObject) {
            return BaseObjectHandler.getHandler((StorableBaseObject) obj);
        } else if (obj instanceof AssociationLink) {
            return AssociationLinkWrapper.wrapLink((AssociationLink) obj);
        } else {
            throw new DebugException("Invalid object in collection: " + obj.getClass().getName());
        }
    }
    
    protected static Object unwrap(Object obj) {
        if (obj == null) {
            return null;
        } else if (obj instanceof RefBaseObject) {
            return ((BaseObjectHandler) obj)._getDelegate().getMofId();
        } else if (obj instanceof AssociationLinkWrapper) {
            return ((AssociationLinkWrapper) obj).getInnerLink();
        } else {
            return obj;
        }
    }    
    
    protected static Object[] wrapArray(Object[] array) {
        for (int i = 0; i < array.length; i++) {
            array[i] = wrap(array[i]);
        }
        
        return array;
    }
    
    public boolean contains(Object obj) {
        try {
            lock(false);
            return inner.contains(unwrap(obj));
        } finally {
            unlock();
        }
    }
    
    public Iterator iterator() {
        try {
            lock(false);
            return new IndexIteratorWrapper(inner.iterator());
        } finally {
            unlock();
        }
    }
    
    public int size() {
        try {
            lock(false);
            return inner.size();
        } finally {
            unlock();
        }
    }
    
    public boolean isEmpty() {
        try {
            lock(false);
            return inner.isEmpty();
        } finally {
            unlock();
        }
    }
    
    public boolean containsAll(Collection collection) {
        try {
            lock(false);
            return inner.containsAll(new CollectionUnwrapper(collection));
        } finally {
            unlock();
        }
    }
    
    public Object[] toArray(Object[] obj) {
        try {
            lock(false);
            Object[] value = wrapArray(inner.toArray());
            Object[] result = obj;
            if (value.length > result.length) {
                if (value.getClass() == result.getClass()) {
                    return value;
                } else {
                    result = (Object[]) Array.newInstance(obj.getClass().getComponentType(), 
                        value.length);
                }
            } else if (value.length < result.length) {
                result[value.length] = null;
            }
            System.arraycopy(value, 0, result, 0, value.length);
            return result;
        } finally {
            unlock();
        }
    }
    
    public Object[] toArray() {
        return toArray(new Object[size()]);
    }
    
    public void clear() {
        throw new UnsupportedOperationException();
    }
    
    public boolean addAll(Collection collection) {
        throw new UnsupportedOperationException();
    }
    
    public boolean remove(Object obj) {
        throw new UnsupportedOperationException();
    }
    
    public boolean add(Object obj) {
        throw new UnsupportedOperationException();
    }
    
    public boolean retainAll(Collection collection) {
        throw new UnsupportedOperationException();
    }
    
    public boolean removeAll(Collection collection) {
        throw new UnsupportedOperationException();
    }
    
    protected class IndexIteratorWrapper implements Iterator {
        protected Iterator innerIterator;
        
        public IndexIteratorWrapper(Iterator innerIterator) {
            this.innerIterator = innerIterator;
        }
        
        public boolean hasNext() {
            try {
                lock(false);
                return innerIterator.hasNext();
            } finally {
                unlock();
            }
        }
        
        public Object next() {
            try {
                lock(false);
                return wrap(innerIterator.next());
            } finally {
                unlock();
            }
        }
        
        public void remove() {
            throw new UnsupportedOperationException();
        }
    }
}
