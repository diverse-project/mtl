/*
 *                 Sun Public License Notice
 *
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 *
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrexplorer.looks;

import java.io.IOException;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.text.MessageFormat;
import org.netbeans.api.mdr.MDRObject;
import org.netbeans.api.mdr.MDRManager;
import org.netbeans.api.mdr.MDRepository;
/**
 *
 * @author  tz97951
 */
public class MDRTransferable implements Transferable {
    
    public static final String mdrObjectMimeType = "application/x-java-mdr-object";     //NOI18N
    private static final String FORMAT = "{0}; class={1}";                              //NOI18N
    private static final String MDR_OBJECT = "org.netbeans.api.mdr.MDRObject";          //NOI18N
    private static final String MDR_REPOSITORY = "org.netbeans.api.mdr.MDRepository";   //NOI18N
    private static final String MDR_MANAGER = "org.netbeans.api.mdr.MDRManager";        //NOI18N
    private static final String GENERIC_OBJECT = "java.lang.Object";                    //NOI18N
    
    protected Object transferedObject;
    protected String stringifiedTransferedObject;
    protected DataFlavor[] flavors;
    
    /** Creates a new instance of MDRTransferable */
    public MDRTransferable (Object transferedObject) {
        this (transferedObject, null);
    }
    
    public MDRTransferable (Object transferedObject, String stringifiedTransferedObject) {
        this.transferedObject = transferedObject;
        this.stringifiedTransferedObject = stringifiedTransferedObject;
    }
    
    public DataFlavor[] getTransferDataFlavors () {
        if (this.flavors == null) {
            this.initFlavors ();
        }
        return this.flavors;
    }
    
    public Object getTransferData (DataFlavor df) throws UnsupportedFlavorException, IOException {
        if (this.flavors == null)
            this.initFlavors ();
        int index = this.getDataFlavorIndex (df);
        switch (index) {
            case 0:
            case 1:
                return this.transferedObject;
            case 2:
                return this.stringifiedTransferedObject;
            default:
                throw new UnsupportedFlavorException (df);
        }
    }
    

    public boolean isDataFlavorSupported(DataFlavor flavor) {
        return this.getDataFlavorIndex (flavor) != -1;
    }
    
    protected void initFlavors () {
        try {
            String className;
            if (transferedObject instanceof MDRObject) {
                className = MDR_OBJECT;
            }
            else if (transferedObject instanceof MDRManager) {
                className = MDR_MANAGER;
            }
            else if (transferedObject instanceof MDRepository) {
                className = MDR_REPOSITORY;
            }
            else {
                className = GENERIC_OBJECT;
            }
            if (this.stringifiedTransferedObject == null) {
                this.flavors = new DataFlavor[] { new DataFlavor (MessageFormat.format(FORMAT, new Object[]{DataFlavor.javaJVMLocalObjectMimeType, className})),
                                                  new DataFlavor (MessageFormat.format(FORMAT, new Object[]{mdrObjectMimeType, className}))};
            }
            else {
                this.flavors = new DataFlavor[] { new DataFlavor (MessageFormat.format(FORMAT, new Object[]{DataFlavor.javaJVMLocalObjectMimeType, className})),
                                                  new DataFlavor (MessageFormat.format(FORMAT, new Object[]{mdrObjectMimeType, className})),
                                                  DataFlavor.stringFlavor};
            }
        }catch (ClassNotFoundException cnf) {
	}
        catch (IllegalArgumentException iae) {
        }
    }
    
    protected int getDataFlavorIndex (DataFlavor df) {
        if (this.flavors == null) {
            this.initFlavors ();
        }
        for (int i=0; i< this.flavors.length; i++) {
            if (flavors[i].equals (df))
                return i;
        }
        return -1;
    }
    
}
