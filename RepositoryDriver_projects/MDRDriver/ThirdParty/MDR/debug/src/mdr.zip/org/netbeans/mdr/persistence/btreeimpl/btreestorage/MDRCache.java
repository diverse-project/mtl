/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.mdr.persistence.btreeimpl.btreestorage;

import java.lang.ref.*;
import java.io.*;
import java.text.*;
import java.util.*;

import org.netbeans.mdr.persistence.*;

/**
* An in-memory cache of MDR objects.  At any given moment, there are four
* kinds of objects in the cache:
* <ol>
* <li>
* Objects which are referenced by client code, and so cannot be collected.
* <li>
* Objects which have been created but not yes written to disk, and so
* should not be collected until they are written out.
* <li>
* Objects which have been marked dirty, and so should not be collected until
* they are written out.
* <li>
* Objects which are nother referenced nor dirty, and so are eligible for 
* collection.
* </ol>
* The cache also keep s track of the keys of objects which have been deleted.
* <p>
* The creator of the cache specifies how many objects
* to cache in memory.  Hard references are kept to the last N objects
* used, to enforce this.  The cache keeps soft references to the other
* objects of the third type, so 
* how often they are collected depends upon memory usage and the 
* JVM's GC implementation. 
*/

public class MDRCache {

    /* hash MOF ID's to references */
    private HashMap hashOnId;

    /* Hard references */
    //private Object hardRef[];
    private CacheReference hardRef[];
    
    /* current slot in above index */
    private int hardIndex;

    /* queue for soft references */
    private ReferenceQueue queue;

    /* List of new objects */
    private HashMap newOnes;

    /* List of dirty objects */
    private HashMap dirty;

    /* List of deleted IDs */
    private HashMap deleted;

    /* our overflow handler */
    OverflowHandler handler;

    /* our threshhold for changed objects */
    int threshhold;

    /* caching statistics */
    int hits;
    int misses;
    int maxSize;

    /** Create the cache
    * @param size how many objects to cache in memory 
    * @param hndlr handler to call when the cache has too many changed objects
    * @param limit number of changed objects to allow
    */
    public MDRCache(int size, OverflowHandler hndlr, int limit) {
    	this(size);
	handler = hndlr;
	threshhold = Integer.getInteger(
	    "org.netbeans.mdr.persistence.btreeimpl.btreestorage.MDRCache.threshhold", 
	    limit).intValue();
    }

    /** Create the cache
    * @param size how many objects to cache in memory */
    public MDRCache(int size) {
        hashOnId = new HashMap();
        deleted = new HashMap();
        //hardRef = new Object[size];
        hardRef = new CacheReference[size];
        hardIndex = 0;
        queue = new ReferenceQueue();
        dirty = new HashMap();
        newOnes = new HashMap();
    }

    /** returns true if the cache contains any changed objects
    * @return true if any objects have been modified or deleted
    */
    public synchronized boolean hasChanges() {
        return dirty.size() + newOnes.size() + deleted.size() > 0;
    }


    /** add a new object to the cache
    * @param m the object's MOF ID
    * @param o the object to add
    */
    public synchronized void put(Object m, Object o) throws StorageException {
        CacheReference cr = new CacheReference(m, o, queue);
        CacheReference oldCr = (CacheReference)hashOnId.put(m, cr);
        //cr.inCache = true;
        if (oldCr != null) {
            //oldCr.inCache = false;
            if (oldCr.get() != null && oldCr.get() != o) {
                throw new StorageBadRequestException(
                    MessageFormat.format("Duplicate MOF ID: {0}", 
                                         new Object[] {m} ));
            }
            oldCr.clear();
        }
        //makeHardRef(o);
        makeHardRef(cr);
        checkQueue();
        int curSize = hashOnId.size();
        if (curSize > maxSize)
            maxSize = curSize;
    }

    /** get an object from the cache
    * @param m the object's MOF ID
    */
    public synchronized Object get(Object m) {
        Object o = null;
        CacheReference cr = (CacheReference)hashOnId.get(m);
        if (cr != null)
            o = cr.get();
        if (o != null) {
            makeHardRef(cr);
            hits++;
        }
        else {
            misses++;
        }
        checkQueue();
        return o;
    }

    /** replace an object in the cache
    * @param m the object's key
    * @param o the object
    */
    synchronized void replace(Object m, Object o) throws StorageException {
        removeFromCache(m);
        put(m, o);
    }

    /** remove an object from the cache
    * @param m the object's MOF ID
    * @return true if the object was found in the cache
    */
    public synchronized void remove(Object m) {
        CacheReference cr = (CacheReference)hashOnId.remove(m);

        if (!removeFromCache(m)) {
            deleted.put(m, m);
        }

        checkQueue();
    }

    /** remove all traces from the cache.  
    * @return true if the object was new
    */
    private boolean removeFromCache(Object m) {
        CacheReference cr = (CacheReference)hashOnId.remove(m);

        if (cr != null)  {
            cr.clear();
            //cr.inCache = false;
        }
        boolean wasNew = (newOnes.remove(m) != null);
        dirty.remove(m);

        return wasNew;
    }


    /** clear all unecessary objects from the cache
    */
    public synchronized void clear() {
        Arrays.fill(hardRef, null);
        System.gc();
        checkQueue();
    }

    /* create a hard reference to the supplied object */
    //private void makeHardRef(Object o) {
    private void makeHardRef(CacheReference cr) {    
        /**
        hardRef[hardIndex++] = o;
        if (hardIndex >= hardRef.length) {
            hardIndex = 0;
        }
        
        BHM: This was not very nice after 20 gets We'd have 20
             identical objects in the cache which definitely isn't
             what we want.
        */
        
        if ( cr.isHard() ) {
            // The reference is already in cache we don't need to do
            // anything
            return;
        }
        else {           
            if (hardRef[hardIndex] != null) {
                // Old Reference may be GCed 
                hardRef[hardIndex].weaken();
            }
            cr.harden();
            hardRef[hardIndex] = cr;
            
            hardIndex++;
            if ( hardIndex >= hardRef.length ) {
                hardIndex = 0;
            }
        }
    }

    /* check for queued references, and remove them from the hash table */
    private void checkQueue() {
	int i = 0;
        CacheReference cr;
        while ((cr = (CacheReference)queue.poll()) != null) {
            //if (cr.inCache) {
            Object k = cr.getKey();
            if (k == null)
                // the reference was already replaced by another one.
                continue;
            
            CacheReference cr2 = (CacheReference)hashOnId.remove(k);
            i += cr2 == null ? 0 : 1;
            // cr.inCache = false;
            //}
        }
        /*
	if (i > 0) {
	    Logger.getDefault().log("Removed " + i + 
		" references; hash size now " + hashOnId.size() + " was " + (hashOnId.size() + i));
            Logger.getDefault().log( " HardRefs " + hardIndex );
	}
        */
    }

    /* Check to see if we have exceeded our threshhold for dirty objects
    */
    private void checkThreshhold() throws StorageException {
	int allChanged = newOnes.size() + dirty.size();  
	// Logger.getDefault().log("checkThreshhold called at level " + allChanged);
    	if (allChanged >= threshhold)
	    handler.cacheThreshholdReached(this, allChanged);
    }

    /* throw an exception when a bad key is processed */
    private void badKey(Object key) throws StorageException {
	throw new StorageBadRequestException(
	    MessageFormat.format(
		"No object with ID {0}", new Object[] {key}));
    }

    /**
    * mark that the object with the given MOF ID is new
    * @param key MOF ID
    */
    public synchronized void setNew(Object key) throws StorageException{
        Object o = get(key);
        if (o == null) {
	    badKey(key);
        }
        newOnes.put(key, o);
	if (handler != null)
	    checkThreshhold();
    }
    
    /** check if the object with the given key is new
    * @return true if it is new
    */
    public synchronized boolean isNew(Object key) {
        return newOnes.get(key) != null;
    } 

    /** Get an iterator over the keys of all active objects in the cache
    * @return the iterator
    */
    public synchronized Iterator iterateActive() {
        return hashOnId.keySet().iterator();
    }

    /** Get an iterator over the keys of deleted objects
    * @return the iterator
    */
    public synchronized Iterator iterateDeleted() {
        return deleted.keySet().iterator();
    }

    /** Get an iterator over the keys of new objects
    * @return the iterator
    */
    public synchronized Iterator iterateNew() {
        return newOnes.keySet().iterator();
    }

    /** return the number of new objects 
    * @return number of new objects
    */
    public int numberNew() {
        return newOnes.size();
    }

    /** return the number of deleted objects 
    * @return number of deleted objects
    */
    public int numberDeleted() {
        return deleted.size();
    }

    /** check if the object with the given key is deleted
    * @return true if it is deleted
    */
    public synchronized boolean isDeleted(Object key) {
        return deleted.get(key) != null;
    } 

    /**
    * mark that the object with the given MOF ID is dirty
    * @param key MOF ID
    */
    public synchronized void setDirty(Object key) throws StorageException{
        Object o = get(key);
        if (o == null) {
	    badKey(key);
        }
        if (newOnes.get(key) == null) {
            dirty.put(key, o);
	    if (handler != null)
		checkThreshhold();
        }
    }

    /** Get all of the new objects
    * @return the keys of the new objects
    */
    public synchronized Collection getNew() {
        return newOnes.keySet();
    }

    /** Get all of the dirty objects
    * @return the keys of the dirty objects
    */
    public synchronized Collection getDirty() {
        return dirty.keySet();
    }

    /** Get all of the deleted IDs
    * @return the deleted IDs 
    */
    public synchronized Collection getDeleted() {
        return deleted.values();
    }

    /** Clear the set of new, dirty, and deleted objects, 
    * presumably after having written them all out.
    */
    public synchronized void clearLists() {
        dirty.clear();
        newOnes.clear();
        deleted.clear();
    }

    /**
    * Show caching statistics
    */
    public void showStats(PrintStream strm) {
    	showStats(new PrintWriter(strm));
    }

    /**
    * Show caching statistics
    */
    public void showStats(PrintWriter strm) {
        strm.println(
            "Cache hits: " + hits + " misses: " + misses + 
            " hit rate: " + 100. * (float)hits / (float)(hits + misses));
        strm.println("Maximum size: "  + maxSize);
	strm.flush();
    }

    /**
    * The cache handler is called when the number of changes in the cache 
    * reaches its threshhold.  The handler is expected to do something
    * to reduce the number of changed objects in the cache, for instance,
    * write them to disk
    */
    public interface OverflowHandler {
	
	/** Notify handler that the cache has reached its threshhold
    	* @param cache cache which reached threshhold
    	* @param size number of changed objects currently in cache
	*/
	void cacheThreshholdReached(MDRCache cache, int size) 
						throws StorageException;
    }
}
