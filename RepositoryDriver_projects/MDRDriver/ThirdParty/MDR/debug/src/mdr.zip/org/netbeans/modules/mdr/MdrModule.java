/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdr;

import org.openide.modules.ModuleInstall;
import org.netbeans.mdr.NBMDRepositoryImpl;
import org.netbeans.api.mdr.MDRManager;
//import org.netbeans.modules.mdrjava.*;

/** Module installation class for MDR module
 *
 * @author Petr Hrebejk
 */
public class MdrModule extends ModuleInstall {
    //private ModuleInstall javaModule = new MdrJavaModule();
    
    /** Called when module is installed for the first time.
     */
    public void installed () {
        restored();
    }

    /** Module is being loaded into the IDE.
     */
    public void restored () {
    }

    /** Module was uninstalled.
     */
    public void uninstalled () {
        closing();
        MDRManagerImpl.uninstall(); // cleanup
    }

    /** Module is being closed.
     * @return True if the close is O.K.
     */
    public boolean closing () {
        MDRManager.getDefault().shutdownAll();
        return true; // agree to close
    }
}
