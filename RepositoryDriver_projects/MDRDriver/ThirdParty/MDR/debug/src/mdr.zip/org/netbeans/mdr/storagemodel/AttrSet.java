/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.mdr.storagemodel;

import java.util.*;

import javax.jmi.reflect.RefObject;
import javax.jmi.reflect.DuplicateException;

import org.netbeans.mdr.persistence.StorageException;

/**
 *
 * @author  mm109185
 */
public class AttrSet extends AttrCollection {
    public AttrSet() {
        inner = new HashSet();
    }
    
    AttrSet(StorableFeatured mdrObject, StorableClass.AttributeDescriptor desc) throws StorageException {
        this(mdrObject, desc, null);
    }
    
    protected AttrSet(StorableFeatured mdrObject, StorableClass.AttributeDescriptor desc, Collection values) throws StorageException {
        super(mdrObject, desc, null);

        if (values != null) {
            checkMaxSize(values.size());
            inner = new HashSet(values.size() * 2);
            for (Iterator it = values.iterator(); it.hasNext();) {
                Object value = it.next();
                checkType(value);
                if (!inner.add(value)) {
                    throw new DuplicateException(value, getMetaElement());
                }
                if (isRefObject) {
                    setAttribComposite((RefObject) value);
                }
            }
        } else {
            inner = new HashSet();
        }
    }
}
