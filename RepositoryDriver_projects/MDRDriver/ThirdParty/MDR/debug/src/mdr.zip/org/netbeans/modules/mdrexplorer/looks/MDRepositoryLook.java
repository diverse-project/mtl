/*
 *                 Sun Public License Notice
 *
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 *
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrexplorer.looks;

import java.util.Collection;
import java.util.ArrayList;
import javax.jmi.reflect.RefPackage;
import javax.jmi.model.MofPackage;

import org.openide.util.NbBundle;
import org.netbeans.api.mdr.*;
import org.netbeans.api.mdr.events.*;
import org.netbeans.api.looks.*;
import org.netbeans.spi.looks.*;
import org.netbeans.modules.mdrexplorer.looks.DataRestWrapper;
//import org.netbeans.modules.freestyle.*;

/** All metadata repositories in the system
 *
 * @author Petr Hrebejk, Tomas Zezula
 */
public class MDRepositoryLook extends LimitedChildrenLook {
    
    private static final String MDREPOSITORY_ICON = "org/netbeans/modules/mdrexplorer/looks/resources/repository"; // NOI18N";
    
    
    /** Creates new RootLook */
    public MDRepositoryLook() {
        super(NbBundle.getMessage(MDRepositoryLook.class,"TXT_MDRepositoryLook"));
    }
    
    protected Object attachTo (Look.NodeSubstitute substitute) {
        super.attachTo (substitute);
        MDREventHandler handler = RepositoryCache.getRepositoryCache().addRepository ((MDRepository)substitute.getRepresentedObject());
        handler.addNodeSubstitute (substitute);
        return handler;
    }
    
    
    public Object[] getChildObjects(Look.NodeSubstitute substitute) {
        Object[] result = null;
        MDRepository repository = (MDRepository)substitute.getRepresentedObject();;
        
        String[] packages = repository.getExtentNames();
        java.util.ArrayList temp = new java.util.ArrayList();
        javax.jmi.reflect.RefPackage packageObject = null;
        if ( (packages != null) && (packages.length > 0) ) {
            int count = this.getBrowserChildCount ();
            count = (count ==-1 ? Integer.MAX_VALUE : count);
            for (int cnt = 0, i = 0; cnt < packages.length && i < count; cnt++ ) {
                packageObject = repository.getExtent(packages[cnt]);
                if (packageObject != null) {
                    temp.add(packageObject);
                    RepositoryCache.getRepositoryCache().addPackageName(packageObject, packages[cnt]);
                    i++;
                }
            }
            if (packages.length>count) {
                ArrayList arrayList = new ArrayList ();
                for (int i=count; i<packages.length; i++) {
                    packageObject = repository.getExtent(packages[i]);
                    if (packageObject != null) {
                        arrayList.add(packageObject);
                        RepositoryCache.getRepositoryCache().addPackageName(packageObject, packages[i]);
                    }
                }
                temp.add (new DataRestWrapper ( new Collection[] {arrayList},0));
            }
            if (temp.size() > 0) {
                result = temp.toArray();
            }
        }
        return result;
    }
    
    
    public String iconBase(Look.NodeSubstitute substitute) {
        return MDREPOSITORY_ICON;
    }
    
    public String getName( Look.NodeSubstitute substitute ) {
        return NbBundle.getMessage(MDRepositoryLook.class,"TXT_MDRepository");
    }
    
    public String getDisplayName() {
        return this.getName();
    }
    
}
