/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.mdr.persistence.btreeimpl.btreestorage;

/** The address of a cached page */
class PageID {
    /** the index of the file this page belongs to */
    int fileIndex;

    /** the offset into the file of this page */
    int offset;

    /** create a PageID
    * @param fIdx file index
    * @param ofset offset
    */
    PageID(int fIdx, int ofst) {
        fileIndex = fIdx;
        offset = ofst;
    }

    /** two page IDs are equal if their file indexes and offsets are equal */
    public boolean equals(Object o) {
        if (!(o instanceof PageID))
            return false;

        PageID page = (PageID)o;
        return page.fileIndex == this.fileIndex &&
               page.offset == this.offset;
    }

    /** hase a pageID on its file index and offset */
    public int hashCode() {
        return fileIndex + offset;
    }

    /** for debugging */
    public String toString() {
        return Integer.toString(fileIndex) + ":" + offset;
    }
}
