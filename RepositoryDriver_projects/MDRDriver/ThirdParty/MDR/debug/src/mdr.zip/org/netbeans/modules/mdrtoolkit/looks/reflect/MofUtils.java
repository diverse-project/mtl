/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrtoolkit.looks.reflect;


import org.netbeans.modules.mdrtoolkit.looks.reflect.properties.*;
import org.netbeans.modules.mdrtoolkit.looks.reflect.actions.*;

import java.util.*;
import java.awt.*;
import javax.jmi.reflect.*;
import javax.jmi.model.*;

import org.openide.util.actions.SystemAction;
import org.openide.util.SharedClassObject;

import org.openidex.nodes.looks.*;
import org.openidex.nodes.looks.*;
import org.openide.nodes.*;

/**
 *
 * @author  ms118741
 * @version 
 */
public class MofUtils {

    private static final String META = "META_";
    private static final String NAME = "name";
    private static final String NAME_SEPARATOR = ".";
    private static final String NO_VALUE = "NoValue";

    /** Creates new Utils */
    public MofUtils() {
    }

    public static String getRefObjectName(Look.NodeSubstitute substitute) {
        return getRefObjectName( (RefObject)substitute.getRepresentedObject() );
    }
    public static String getRefObjectName(RefObject refObject) {
            String result = null;

            RefObject metaObject = refObject.refClass().refMetaObject();
            try {
                RefObject attribute = ((MofClass)metaObject).lookupElementExtended( NAME );
                if (attribute instanceof Attribute) {
                    Object value = ((RefFeatured)refObject).refGetValue( (StructuralFeature) attribute );
                    result = (value == null) ? NO_VALUE : value.toString();
                }
            } catch (NameNotFoundException e) {
                if (result == null) {
                    result = META + ((MofClass)refObject.refMetaObject()).getName();
                }
            }
            return result;
    }

    public static String resolveFullyQualifiedName(java.util.List fullyQualifiedName) {
        String result = "";
        if (fullyQualifiedName != null) {
            for (Iterator it = fullyQualifiedName.iterator(); it.hasNext(); ) {
                result += it.next();
                if (it.hasNext()) {
                    result += NAME_SEPARATOR;
                }
            }
        }
        return result;
    }
/*
    public static Node.PropertySet[] getAssocLinkEndPropertySets(RefBaseObject assocEnd) {
        Node.PropertySet[] featuredProps = Look.NO_PROPERTY_SETS;
        Node.PropertySet[] refObjectProps = Look.NO_PROPERTY_SETS;
        Node.PropertySet[] refBaseObjectProps = Look.NO_PROPERTY_SETS;

        if (assocEnd instanceof RefFeatured) {
            featuredProps = RefFeaturedProps.getPropertySets( (RefFeatured)assocEnd );
        }
        if (assocEnd instanceof RefObject) {
            refObjectProps = RefObjectProps.getPropertySets( (RefObject)assocEnd );
        }
        if (assocEnd instanceof RefBaseObject) {
            refBaseObjectProps = RefBaseObjectProps.getPropertySets( assocEnd );
        }

        Node.PropertySet[] result = new Node.PropertySet[featuredProps.length + refObjectProps.length + refBaseObjectProps.length];
        System.arraycopy(featuredProps, 0, result, 0, featuredProps.length);
        System.arraycopy(refObjectProps, 0, result, featuredProps.length, refObjectProps.length);
        System.arraycopy(refBaseObjectProps, 0, result, refObjectProps.length + featuredProps.length, refBaseObjectProps.length);
        return result;
    }
 */
}
