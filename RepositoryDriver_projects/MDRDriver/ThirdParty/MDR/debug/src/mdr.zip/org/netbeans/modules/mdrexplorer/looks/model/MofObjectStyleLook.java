/*
 *                 Sun Public License Notice
 *
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 *
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrexplorer.looks.model;

import java.util.Collection;
import java.util.Iterator;
import javax.jmi.model.*;
import javax.jmi.reflect.*;
import org.openide.nodes.*;
import org.openide.util.actions.SystemAction;
import org.netbeans.api.looks.*;
import org.netbeans.spi.looks.*;
import org.netbeans.modules.mdrexplorer.looks.*;
import org.netbeans.modules.mdrexplorer.looks.reflect.Utils;
import org.netbeans.modules.mdrexplorer.looks.reflect.actions.*;

/** Handles Names and Icons for all MOF Objects
 *
 * @author  Petr Hrebejk, Tomas Zezula
 */
public class MofObjectStyleLook extends DefaultLook {
    
    private static final String ICON_BASE_DIR =
    "org/netbeans/modules/mdrexplorer/looks/model/resources/"; // NOI18N
    private static final String DEFAULT_ICON_BASE =
    "org/netbeans/modules/mdrexplorer/looks/model/resources/default"; // NOI18N
    
    private static final String PACKAGE_ICON = ICON_BASE_DIR + "package"; // NOI18N
    private static final String CLASS_ICON = ICON_BASE_DIR + "class"; // NOI18N
    private static final String ASSOCIATION_ICON = ICON_BASE_DIR + "association"; // NOI18N
    private static final String ATTRIBUTE_ICON = ICON_BASE_DIR + "attribute"; // NOI18N
    private static final String OPERATION_ICON = ICON_BASE_DIR + "operation"; // NOI18N
    private static final String EXCEPTION_ICON = ICON_BASE_DIR + "exception"; // NOI18N
    private static final String PARAMETER_ICON = ICON_BASE_DIR + "parameter"; // NOI18N
    private static final String CONSTRAINT_ICON = ICON_BASE_DIR + "constraint"; // NOI18N
    private static final String ASSOCIATION_END_ICON = ICON_BASE_DIR + "associationEnd"; // NOI18N
    private static final String REFERENCE_ICON = ICON_BASE_DIR + "reference"; // NOI18N
    private static final String IMPORT_ICON = ICON_BASE_DIR + "import"; // NOI18N
    private static final String TAG_ICON = ICON_BASE_DIR + "tag"; // NOI18N
    private static final String DATA_TYPE_ICON = ICON_BASE_DIR + "dataType"; // NOI18N
    
    public MofObjectStyleLook() {
        super(Utils.getLocalizedString(MofObjectStyleLook.class, "TXT_MofObjectStyleLook"));
    }
    
    public String getName( Look.NodeSubstitute substitute ) {
        ModelElement me = (ModelElement)substitute.getRepresentedObject();
        return  me.getName();
    }
    
    public String getDisplayName(Look.NodeSubstitute substitute) {
        return this.getName(substitute);
    }
    
    public String iconBase( Look.NodeSubstitute substitute) {
        
        ModelElement ro = (ModelElement)substitute.getRepresentedObject();
        
        if ( ro instanceof javax.jmi.model.MofPackage ) {
            return PACKAGE_ICON;
        }
        else if ( ro instanceof javax.jmi.model.MofClass ) {
            return CLASS_ICON;
        }
        else if ( ro instanceof javax.jmi.model.Association ) {
            return ASSOCIATION_ICON;
        }
        else if ( ro instanceof javax.jmi.model.Attribute ) {
            return ATTRIBUTE_ICON;
        }
        else if ( ro instanceof javax.jmi.model.Operation ) {
            return OPERATION_ICON;
        }
        else if ( ro instanceof javax.jmi.model.MofException ) {
            return EXCEPTION_ICON;
        }
        else if ( ro instanceof  javax.jmi.model.Parameter ) {
            return PARAMETER_ICON;
        }
        else if ( ro instanceof javax.jmi.model.Constraint ) {
            return CONSTRAINT_ICON;
        }
        else if ( ro instanceof javax.jmi.model.AssociationEnd ) {
            return ASSOCIATION_END_ICON;
        }
        else if ( ro instanceof javax.jmi.model.Reference ) {
            return REFERENCE_ICON;
        }
        else if ( ro instanceof javax.jmi.model.Import ) {
            return IMPORT_ICON;
        }
        else if ( ro instanceof javax.jmi.model.Tag ) {
            return TAG_ICON;
        }
        else if ( ro instanceof javax.jmi.model.DataType ) {
            return DATA_TYPE_ICON;
        }
        else {
            return DEFAULT_ICON_BASE;
        }
    }
    
    public javax.swing.Action[] getActions(Look.NodeSubstitute substitute) {
        javax.swing.Action[] baseActions =  new javax.swing.Action[] {
            SystemAction.get(SaveXMIAction.class),
            SystemAction.get(Map2JavaAction.class),
            SystemAction.get(DeleteObjectAction.class)
        };
        return baseActions;
    }
    
}