/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.mdr.persistence.btreeimpl.btreestorage;

/** this class allows a parameter to return a long value */
public class LongHolder {

    /* the value of the LongHolder */
    private long value;

    /** Create an LongHolder */
    LongHolder() {
        this(0);
    }

    /** Create an LongHolder initialized to a specific value 
    * @param val the value of the LongHolder
    */
    LongHolder(long val) {
        value = val;
    }

    /** Get the value of the LongHolder 
    * @return the value
    */
    long getValue() {
        return value;
    }

    /** Set the value of the LongHolder 
    * @param val the new value of the LongHolder
    */
    void setValue(long val) {
        value = val;
    }
}

