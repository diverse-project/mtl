/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrtoolkit.looks.model;

import java.awt.Image;
import java.util.Collection;
import java.util.Iterator;
import javax.jmi.model.*;
import javax.jmi.reflect.*;

import org.openide.nodes.*;
import org.openide.util.actions.SystemAction;

import org.openidex.nodes.looks.*;
import org.netbeans.modules.mdrtoolkit.looks.*;
import org.netbeans.modules.mdrtoolkit.looks.reflect.actions.*;

/** Handles Names and Icons for all MOF Objects
 *
 * @author  Petr Hrebejk
 */
public class MofObjectStyleLook extends AcceptorLook.Type {
   
    public MofObjectStyleLook() {
        super( new Delegate(), ModelElement.class );
    }
    
    private static class Delegate extends DefaultLook { 
        private static final String ICON_BASE_DIR =
            "/org/netbeans/modules/mdrtoolkit/looks/model/resources/"; // NOI18N

        private static final String DEFAULT_ICON_BASE =
            "/org/netbeans/modules/mdrtoolkit/looks/model/resources/default"; // NOI18N

        private static final String PACKAGE_ICON = ICON_BASE_DIR + "package"; // NOI18N
        private static final String CLASS_ICON = ICON_BASE_DIR + "class"; // NOI18N
        private static final String ASSOCIATION_ICON = ICON_BASE_DIR + "association"; // NOI18N
        private static final String ATTRIBUTE_ICON = ICON_BASE_DIR + "attribute"; // NOI18N
        private static final String OPERATION_ICON = ICON_BASE_DIR + "operation"; // NOI18N
        private static final String EXCEPTION_ICON = ICON_BASE_DIR + "exception"; // NOI18N
        private static final String PARAMETER_ICON = ICON_BASE_DIR + "parameter"; // NOI18N
        private static final String CONSTRAINT_ICON = ICON_BASE_DIR + "constraint"; // NOI18N
        private static final String ASSOCIATION_END_ICON = ICON_BASE_DIR + "associationEnd"; // NOI18N
        private static final String REFERENCE_ICON = ICON_BASE_DIR + "reference"; // NOI18N
        private static final String IMPORT_ICON = ICON_BASE_DIR + "import"; // NOI18N
        private static final String TAG_ICON = ICON_BASE_DIR + "tag"; // NOI18N
        private static final String DATA_TYPE_ICON = ICON_BASE_DIR + "dataType"; // NOI18N

        public String getName( Look.NodeSubstitute substitute ) {
            /*
            if ( substitute.getRepresentedObject() instanceof ModelPakage ) {
                return null;
            }
            */
            ModelElement me = (ModelElement)substitute.getRepresentedObject();
            return  me.getName();
        }

        public Image getIcon( Look.NodeSubstitute substitute, int type) {

            ModelElement ro = (ModelElement)substitute.getRepresentedObject();

            if ( ro instanceof javax.jmi.model.MofPackage ) {
                return IconBaseSupport.getIcon( PACKAGE_ICON, type );
            }
            else if ( ro instanceof javax.jmi.model.MofClass ) {
                return IconBaseSupport.getIcon( CLASS_ICON, type );
            }
            else if ( ro instanceof javax.jmi.model.Association ) {
                return IconBaseSupport.getIcon( ASSOCIATION_ICON, type );
            }
            else if ( ro instanceof javax.jmi.model.Attribute ) {
                return IconBaseSupport.getIcon( ATTRIBUTE_ICON, type );
            }
            else if ( ro instanceof javax.jmi.model.Operation ) {
                return IconBaseSupport.getIcon( OPERATION_ICON, type );
            }
            else if ( ro instanceof javax.jmi.model.MofException ) {
                return IconBaseSupport.getIcon( EXCEPTION_ICON, type );
            }
            else if ( ro instanceof  javax.jmi.model.Parameter ) {
                return IconBaseSupport.getIcon( PARAMETER_ICON, type );
            }
            else if ( ro instanceof javax.jmi.model.Constraint ) {
                return IconBaseSupport.getIcon( CONSTRAINT_ICON, type );
            }
            else if ( ro instanceof javax.jmi.model.AssociationEnd ) {
                return IconBaseSupport.getIcon( ASSOCIATION_END_ICON, type );
            }
            else if ( ro instanceof javax.jmi.model.Reference ) {
                return IconBaseSupport.getIcon( REFERENCE_ICON, type );
            }
            else if ( ro instanceof javax.jmi.model.Import ) {
                return IconBaseSupport.getIcon( IMPORT_ICON, type );
            }
            else if ( ro instanceof javax.jmi.model.Tag ) {
                return IconBaseSupport.getIcon( TAG_ICON, type );
            }
            else if ( ro instanceof javax.jmi.model.DataType ) {
                return IconBaseSupport.getIcon( DATA_TYPE_ICON, type );
            }
            else {    
                return IconBaseSupport.getIcon( DEFAULT_ICON_BASE, type );
            }
        }
        
        public Node.PropertySet[] getPropertySets(Look.NodeSubstitute substitute) {

            ModelElement me = (ModelElement)substitute.getRepresentedObject();
            MofClass mo = (MofClass)me.refMetaObject();

            Sheet.Set[] npss = new Sheet.Set[] {
                new Sheet.Set( )
            };
            
            npss[0].setName( "Attributes" );
            npss[0].setDisplayName( "Attributes" );
            npss[0].setShortDescription( "Attributes");
         
            addAllAttributes( npss[0], mo, me );
            for ( Iterator it = mo.allSupertypes().iterator(); it.hasNext(); ) {
                MofClass mc = (MofClass)it.next();
                addAllAttributes( npss[0], mc, me );
            }
            
            return npss;
        }
        
        private void addAllAttributes( Sheet.Set sheetSet, MofClass mc, ModelElement me ) {
            // Get all contained elements
            for ( Iterator it = mc.getContents().iterator(); it.hasNext(); ) {
                ModelElement e = (ModelElement)it.next();
                if ( e instanceof Attribute ) {
                    sheetSet.put( new MofPropertySupport( 
                        (Attribute)e, 
                        me,
                        ((Attribute)e).getName(), 
                        String.class,
                        ((Attribute)e).getName(), 
                        ((Attribute)e).getName() ) );
                }
            }
        }
        
        public SystemAction[] getActions( Look.NodeSubstitute substitute ) {
            return new SystemAction[] { new Map2JavaAction() };
        }
        
    }
       
    static class MofPropertySupport extends PropertySupport.ReadOnly {
     
        private RefObject object;
        private Attribute metaObject;
        
        MofPropertySupport( 
                Attribute mo, 
                RefObject o, 
                String name, 
                Class type, 
                String displayName, 
                String shortDescription ) {
            super( name, type, displayName, shortDescription );
            metaObject = mo;
            object = o;
        }
        
        public Object getValue( ) {
            return object.refGetValue( metaObject ).toString();        
        }
    }
        
}
