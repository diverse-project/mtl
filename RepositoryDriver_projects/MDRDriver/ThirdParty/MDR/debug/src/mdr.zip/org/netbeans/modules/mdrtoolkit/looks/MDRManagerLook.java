/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrtoolkit.looks;

import java.io.File;

import org.openide.TopManager;
import org.openide.util.NbBundle;
import org.openide.util.Lookup;

import org.netbeans.api.mdr.*;
import org.openidex.nodes.looks.*;

/** All metadata repositories in the system
 *
 * @author Petr Hrebejk
 */
public class MDRManagerLook extends AcceptorLook.Type {
        
    /** Creates new RootLook */
    public MDRManagerLook() {
        super( new Delegate(), TopManager.class );
    }
    
    private static class Delegate extends DefaultLook {
        
        public Object[] getChildObjects( Look.NodeSubstitute substitute ) {
            
            MDRManager manager = MDRManager.getDefault();
            String[] mdrNames = manager.getRepositoryNames(); 
            MDRepository[] mdrs = new MDRepository[ mdrNames.length ];
            
            for( int i = 0; i < mdrNames.length; i++ ) {
                mdrs[i] = manager.getRepository( mdrNames[i] );
            }
        
            return mdrs;
        }
    }
}
