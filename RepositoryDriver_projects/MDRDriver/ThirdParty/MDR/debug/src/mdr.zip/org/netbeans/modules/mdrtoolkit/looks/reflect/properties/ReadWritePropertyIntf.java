/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrtoolkit.looks.reflect.properties;

/**
 *
 * @author  ms118741
 * @version 
 */
public interface ReadWritePropertyIntf {

    public String getSheetName();
    public String getPropertyName();
    public String getPropertyDesc();
    public Class getPropertyClass();
    
    public Object getValue();
    public void setValue(Object value);
    public boolean isPropertyEditor();

    public String getAsTextEditor();
    public void setAsTextEditor(String string);
    public void setValueEditor(Object value);
    public Object getValueEditor();
    public String[] getTagsEditor();
    public boolean supportsCustomEditor();
    public javax.jmi.reflect.RefBaseObject getNavigableObject();
}
