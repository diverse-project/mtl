/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.mdrshell;

import java.util.*;
import java.io.*;

import koala.dynamicjava.interpreter.*;
import koala.dynamicjava.parser.wrapper.*;

import org.netbeans.api.mdr.MDRManager;
import org.netbeans.mdr.handlers.*;
import org.openide.ErrorManager;

/**
 *
 * @author  phrebejk
 * @version 
 */
public class DJava extends Object {

    /** Creates new DJava */
    public DJava() {
    }

    static koala.dynamicjava.interpreter.Interpreter interpreter;
    /**
     * Initialize the engine.
     */
    public static void initialize ( ) {
        // create an interpreter
        interpreter = new TreeInterpreter(new JavaCCParserFactory());
        BaseObjectHandler.setClassLoaderProvider(new CLProviderImpl());

        // this is here just to make MDR boot when starting up the shell (not lazily)
        MDRManager.getDefault().getDefaultRepository().getExtentNames(); 
    }

    public static Object eval ( String line ) throws Exception {
        try {
            Reader r = new StringReader(line + ";");
            return interpreter.interpret(r, line );
        } catch (Exception e) {
            ErrorManager.getDefault().notify(e);
            throw e;
        }
    }

    /**
     * Declare a bean
     */
    public static void declareVariable ( String name, Object object )  {
        interpreter.defineVariable( name, object );
    }

    private static class CLProviderImpl implements ClassLoaderProvider {
        public ClassLoader getClassLoader() {
            return interpreter.getClassLoader();
        }
        
        /** Implementation of this method can define a given class.
         * The defined class should be then visible from the ClassLoader returned
         * from {@link #getClassLoader} method.
         * @param className name of the class to define.
         * @param
         * @return Defined class or null (if null is return, MDR will define the
         * class in its own classloader. This class will then not be accessible from outside
         * of MDR
         */
        public Class defineClass(String className, byte[] classFile) {
            return interpreter.defineClass(className, classFile);
        }
    }
}
