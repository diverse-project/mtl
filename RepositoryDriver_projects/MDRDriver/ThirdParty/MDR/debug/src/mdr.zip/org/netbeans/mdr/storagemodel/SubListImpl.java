/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.mdr.storagemodel;

import java.util.*;

/**
 *
 * @author  mm109185
 */
abstract class SubListImpl implements List {
    private final int firstIndex;
    private final int lastIndex;
    private final ListIterator innerIterator;

    /** Creates new SubListImpl */
    public SubListImpl(int firstIndex, int lastIndex, ListIterator iterator) {
        this.firstIndex = firstIndex;
        this.lastIndex = lastIndex;
        this.innerIterator = iterator;
    }

    public int size() {
        return lastIndex - firstIndex;
    }
    
    public ListIterator listIterator(int index) {
        return innerIterator;
    }
    
    private abstract class SubListIterator implements ListIterator {
        private int currentIndex;
        
        private SubListIterator(int fromIndex) {
            currentIndex = fromIndex;
        }
        

    }
}
