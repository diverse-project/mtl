/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.mdr.handlers;

import java.util.Collection;
import java.util.List;
import java.util.ListIterator;

import org.netbeans.mdr.util.TransactionMutex;

/**
 *
 * @author  mm109185
 */
public final class AttrImmutListWrapper extends AttrImmutCollWrapper implements List {
    protected final List innerList;
    
    /** Creates new ListWrapper */
    public AttrImmutListWrapper(TransactionMutex mutex, List innerList) {
        super(mutex, innerList);
        this.innerList = innerList;
    }
    
    public Object remove(int param) {
        throw new UnsupportedOperationException();
    }
    
    public ListIterator listIterator(int param) {
        try {
            lock(false);
            return new AttrImmutListIteratorWrapper(innerList.listIterator(param));
        } finally {
            unlock();
        }
    }
    
    public void add(int param, Object obj) {
        throw new UnsupportedOperationException();
    }
    
    public int indexOf(Object obj) {
        try {
            lock(false);
            return innerList.indexOf(obj);
        } finally {
            unlock();
        }
    }
    
    public int lastIndexOf(Object obj) {
        try {
            lock(false);
            return innerList.lastIndexOf(obj);
        } finally {
            unlock();
        }
    }
    
    public Object get(int param) {
        try {
            lock(false);
            return innerList.get(param);
        } finally {
            unlock();
        }
    }
    
    public Object set(int param, Object obj) {
        throw new UnsupportedOperationException();
    }
    
    public boolean addAll(int param, Collection collection) {
        throw new UnsupportedOperationException();
    }
    
    public ListIterator listIterator() {
        try {
            lock(false);
            return new AttrImmutListIteratorWrapper(innerList.listIterator());
        } finally {
            unlock();
        }
    }
    
    public List subList(int param, int param1) {
        try {
            lock(false);
            return new AttrImmutListWrapper(mutex, innerList.subList(param, param1));
        } finally {
            unlock();
        }
    }
    
    private final class AttrImmutListIteratorWrapper extends AttrImmutIteratorWrapper implements ListIterator {
        private final ListIterator innerListIterator;
        
        AttrImmutListIteratorWrapper(ListIterator innerIterator) {
            super(innerIterator);
            this.innerListIterator = innerIterator;
        }
        
        public int previousIndex() {
            try {
                lock(false);
                return innerListIterator.previousIndex();
            } finally {
                unlock();
            }
        }
        
        public void set(Object obj) {
            throw new UnsupportedOperationException();
        }
        
        public int nextIndex() {
            try {
                lock(false);
                return innerListIterator.nextIndex();
            } finally {
                unlock();
            }
        }
        
        public boolean hasPrevious() {
            try {
                lock(false);
                return innerListIterator.hasPrevious();
            } finally {
                unlock();
            }
        }
        
        public void add(Object obj) {
            throw new UnsupportedOperationException();
        }
        
        public Object previous() {
            try {
                lock(false);
                return innerListIterator.previous();
            } finally {
                unlock();
            }
        }
    }
}
