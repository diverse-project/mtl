/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.mdr.handlers;

import java.util.*;
import org.netbeans.api.mdr.events.AttributeEvent;
import org.netbeans.mdr.util.EventNotifier;

/**
 *
 * @author  mm109185
 */
public class AttrCollWrapper extends AttrImmutCollWrapper {
    protected final EventNotifier.Abstract notifier;
    protected final FeaturedHandler source;
    protected String attrName = null;
    protected final boolean isStatic;
    
    public AttrCollWrapper(FeaturedHandler source, Collection inner) {
        super(source._getMdrStorage().getRepositoryMutex(), inner);
        EventNotifier en = source._getMdrStorage().getEventNotifier();
        this.isStatic = source instanceof ClassProxyHandler;
        this.notifier = isStatic ? (EventNotifier.Abstract) en.CLASS : (EventNotifier.Abstract) en.INSTANCE;
        this.source = source;
    }
    
    void setAttrName(String name) {
        this.attrName = name;
    }
    
    public final Iterator iterator() {
        try {
            lock(false);
            return new AttrIteratorWrapper(inner.iterator());
        } finally {
            unlock();
        }
    }
    
    public final void clear() {
        boolean fail = true;
        try {
            lock(true);
            Object elements[] = inner.toArray();
            for (int i = 0; i < elements.length; i++) {
                remove(elements[i]);
            }
            fail = false;
        } finally {
            unlock(fail);
        }
    }
    
    public final boolean addAll(Collection collection) {
        boolean fail = true;
        try {
            lock(true);
            boolean result = false;
            for (Iterator it = collection.iterator(); it.hasNext();) {
                result |= add(it.next());
            }
            fail = false;
            return result;
        } finally {
            unlock(fail);
        }
    }
    
    public final boolean remove(Object obj) {
        boolean fail = true;
        try {
            lock(true);
            AttributeEvent event = new AttributeEvent(
                source, 
                isStatic ? AttributeEvent.EVENT_CLASSATTR_REMOVE : AttributeEvent.EVENT_ATTRIBUTE_REMOVE,
                attrName,
                obj, null,
                AttributeEvent.POSITION_NONE);
            notifier.firePlannedChange(source, event);
            boolean result = inner.remove(obj);
            fail = false;
            return result;
        } finally {
            unlock(fail);
        }
    }
    
    public final boolean add(Object obj) {
        boolean fail = true;
        try {
            lock(true);
            AttributeEvent event = new AttributeEvent(
                source, 
                isStatic ? AttributeEvent.EVENT_CLASSATTR_ADD : AttributeEvent.EVENT_ATTRIBUTE_ADD,
                attrName,
                null, obj,
                AttributeEvent.POSITION_NONE);
            notifier.firePlannedChange(source, event);
            boolean result = inner.add(obj);
            fail = false;
            return result;
        } finally {
            unlock(fail);
        }
    }
    
    public boolean retainAll(Collection collection) {
        boolean fail = true;
        try {
            boolean result = false;
            lock(true);
            Object elements[] = inner.toArray();
            for (int i = 0; i < elements.length; i++) {
                if (!collection.contains(elements[i])) {
                    remove(elements[i]);
                    result = true;
                }
            }
            fail = false;
            return result;
        } finally {
            unlock(fail);
        }
    }
    
    public boolean removeAll(Collection collection) {
        boolean fail = true;
        try {
            boolean result = false;
            lock(true);
            for (Iterator it = collection.iterator(); it.hasNext();) {
                result |= remove(it.next());
            }
            fail = false;
            return result;
        } finally {
            unlock(fail);
        }
    }
    
    protected class AttrIteratorWrapper extends AttrImmutIteratorWrapper {
        protected Object lastRead = null;
        
        protected AttrIteratorWrapper(Iterator innerIterator) {
            super(innerIterator);
        }
        
        public Object next() {
            return (lastRead = super.next());
        }
        
        public void remove() {
            boolean fail = true;
            try {
                lock(true);
                AttributeEvent event = new AttributeEvent(
                    source, 
                    isStatic ? AttributeEvent.EVENT_CLASSATTR_REMOVE : AttributeEvent.EVENT_ATTRIBUTE_REMOVE,
                    attrName,
                    lastRead, null,
                    AttributeEvent.POSITION_NONE);
                notifier.firePlannedChange(source, event);
                innerIterator.remove();
                fail = false;
            } finally {
                unlock(fail);
            }
        }
    }
}
