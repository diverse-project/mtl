/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.mdrtoolkit.looks.model;

import java.awt.Image;
import java.util.*;
import javax.jmi.reflect.*;
import javax.jmi.model.*;

import org.openide.nodes.Node;
import org.openide.util.NbBundle;
import org.netbeans.api.mdr.*;

import org.netbeans.lib.jmi.query.mof.FeatureFilter;
import org.netbeans.lib.jmi.query.CollectionQuery;

import org.openidex.nodes.looks.*;

import org.netbeans.modules.mdrtoolkit.looks.RepositoryCache;
import org.netbeans.modules.mdrtoolkit.looks.IconBaseSupport;

/** Implements MOF models defaut view.
 *
 * @author  Petr Hrebejk
 */
public class RootPackages extends AcceptorLook.Type {
   
    /** Creates new PackageProxy
     */
    public RootPackages() {
        super( new Delegate(), ModelPackage.class );
    }
    
    private static class Delegate extends DefaultLook {       
    
        public Object[] getChildObjects(Look.NodeSubstitute substitute ) {

            ModelPackage mp = (ModelPackage)substitute.getRepresentedObject();
            MofPackageClass pc = mp.getMofPackage();
            ArrayList rps = new ArrayList();
            
            for ( Iterator it = pc.refAllOfClass().iterator(); it.hasNext(); ) {
                MofPackage p = (MofPackage)it.next();
                if ( p.getContainer() == null ) {
                    rps.add( p );
                }
            }
            
            Object[] children = new Object[ rps.size() ];
            rps.toArray( children );
            return children;
        }
        
        private static final String ICON_BASE_DIR =
            "/org/netbeans/modules/mdrtoolkit/looks/model/resources/"; // NOI18N
        private static final String PACKAGE_PROXY_ICON = ICON_BASE_DIR + "packageproxy"; // NOI18N
        
        public Image getIcon( Look.NodeSubstitute substitute, int type ) {           
            return IconBaseSupport.getIcon( PACKAGE_PROXY_ICON, type );
        }
        
        public String getName( Look.NodeSubstitute substitute ) {
            RefPackage packageProxy = (RefPackage)substitute.getRepresentedObject();    
            String packageName = (String)RepositoryCache.getRepositoryCache().getObjectNameChache().get( packageProxy );
            if (packageName == null) {
                packageName = ((MofPackage)packageProxy.refMetaObject()).getName();
            }
            return packageName;
        }
        
    }
        
    
}
