/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans, Community Edition. The Initial
 * Developer of the Original Code is Sun Microsystems, Inc. Portions
 * Copyright 1997-2001 Sun Microsystems, Inc. All Rights Reserved.
 */

package org.netbeans.api.looks;



import org.openide.nodes.*;


import org.netbeans.spi.looks.FilterLook;
import org.openide.util.NbBundle;

/** A bean look to display an object as a JavaBean.
 * 
 * @author Jaroslav Tulach
 */
final class BeanLook extends FilterLook {
    
    /** Creates new NodeProxySupport */
    public BeanLook() {
        super (Look.NODES);
    }
    
    public String getName () {
        return "JavaBeans"; // NOI18N
    } 
     
    /** The human presentable name of the look.
     * @return human presentable name
     */
    public String getDisplayName() {
        return NbBundle.getMessage (BeanLook.class, "LAB_JavaBeans");
    }    
    
    /** Replaces each object with its bean node.
     */
    protected Object delegateObject (NodeSubstitute subst) {
        try {
            return new BeanNode (subst.getRepresentedObject ());
        } catch (java.beans.IntrospectionException ex) {
            return ex;
        }
    }
    
}
