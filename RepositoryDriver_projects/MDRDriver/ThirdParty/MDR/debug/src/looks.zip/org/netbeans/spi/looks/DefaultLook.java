/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans, Community Edition. The Initial
 * Developer of the Original Code is Sun Microsystems, Inc. Portions
 * Copyright 1997-2001 Sun Microsystems, Inc. All Rights Reserved.
 */

package org.netbeans.spi.looks;

import java.awt.Image;
import java.awt.datatransfer.Transferable;
import java.io.IOException;
import java.text.MessageFormat;
import java.util.ArrayList;

import javax.naming.NamingEnumeration;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.naming.Binding;
import javax.swing.Action;

import org.openide.nodes.*;
import org.openide.util.Utilities;
import org.openide.util.HelpCtx;
import org.openide.util.Lookup;
import org.openide.util.datatransfer.NewType;
import org.openide.util.datatransfer.PasteType;

import org.netbeans.api.looks.*;
import org.openide.util.NbBundle;

/** 
 * This is a suitable base superclass for newly created looks. It implements all methods of the
 * abstract <code>Look</code> and by default does nothing and returns neutral 
 * values (nulls, false) from all its methods. 
 * <P>
 * Some methods are linked together to make it easier for subclasses to 
 * implement reasonable functionality (iconBase, actionBase), etc.
 *
 * @author Jaroslav Tulach
 */
public abstract class DefaultLook extends Look {
    /** messages to create a resource identification for each type of
    * icon from the base name for the icon.
    */
    private static final MessageFormat[] icons = {
        // color 16x16
        new MessageFormat ("{0}.gif"), // NOI18N
        // color 32x32
        new MessageFormat ("{0}32.gif"), // NOI18N
        // mono 16x16
        new MessageFormat ("{0}.gif"), // NOI18N
        // mono 32x32
        new MessageFormat ("{0}32.gif"), // NOI18N
        // opened color 16x16
        new MessageFormat ("{0}Open.gif"), // NOI18N
        // opened color 32x32
        new MessageFormat ("{0}Open32.gif"), // NOI18N
        // opened mono 16x16
        new MessageFormat ("{0}Open.gif"), // NOI18N
        // opened mono 32x32
        new MessageFormat ("{0}Open32.gif"), // NOI18N
    };
    /** To index normal icon from previous array use
    *  + ICON_BASE.
    */
    private static final int ICON_BASE = -1;
    /** for indexing opened icons */
    private static final int OPENED_ICON_BASE = 3;
    
    /** name of the look */
    private String name;
    
    /** Creates new instance of look does no work.
     * @param name the name to assign to the look
     * @see getName
     */
    public DefaultLook(String name) {
        this.name = name;
    }

    
    /** The human presentable name of the look. The default implementation
     * calls <code>NbBundle.getMessage (getClass (), "LAB_" + getName ()</code>
     * to simplify the work. That means one should put the token
     * <PRE>
     *      LAB_myname=localized name
     * </PRE>
     * into the <code>Bundle.properties</code> file defined in the same package
     * as this class (where myname is the name provided into the constructor).
     * <P>
     * Warning: If you expect to have subclasses, override this method with
     * better implementation!
     * <P>
     * @return human presentable name
     */
    public String getDisplayName() {
        return NbBundle.getMessage (getClass (), "LAB_" + name); // NOI18N
    }
    
    /** Returns name of the look as provided in constructor.
     * @return Name of the look.
     */
    public String getName() {
        return name;
    }
    
    // General methods ---------------------------------------------------------
    
    /** Does neutral behaviour (doing nothing, returning null)
     */
    public Lookup createLookup (Look.NodeSubstitute substitute) {
        return null;
    }

    
    /** Does neutral behaviour (doing nothing, returning null)
     */
    public Look[] availableLooks (Look.NodeSubstitute substitute) {
        return null;
    }
    
    // Methods for STYLE -------------------------------------------------------
    
    /** Does neutral behaviour (doing nothing, returning null)
     */
    public String getDisplayName( Look.NodeSubstitute substitute ) {
        return null;
    }
    
    /** Does neutral behaviour (doing nothing, returning null)
     */
    public String getName( Look.NodeSubstitute substitute ) {
        return null;
    }
    
    /** Does neutral behaviour (doing nothing, returning null)
     */
    public void setName(Look.NodeSubstitute substitute, String newName) {
    }
    
    /** Does neutral behaviour (doing nothing, returning null)
     */
    public String getShortDescription ( Look.NodeSubstitute substitute ) {
        return null;
    }
    
    /** Finds icon using the value returned from <link>iconBase</link>
     * @return an icon or null if not found
     */
    public Image getIcon( Look.NodeSubstitute substitute, int type ) {
        return findIcon (substitute, type, ICON_BASE);
    }

    /** Finds icon using the value returned from <link>iconBase</link>
     * @return an icon or null if not found
    */
    public Image getOpenedIcon( Look.NodeSubstitute substitute, int type ) {
        return findIcon (substitute, type, OPENED_ICON_BASE);
    }
    
    /** Does neutral behaviour (doing nothing, returning null)
     */
    public HelpCtx getHelpCtx( Look.NodeSubstitute substitute ) {
        return null;
    }
    
    // Methods for CHILDREN ----------------------------------------------------
    
    /** Does neutral behaviour (doing nothing, returning null)
     */
    public Object[] getChildObjects( Look.NodeSubstitute substitute ) {
        return null;
    }
    
    // Methods for ACTIONS & NEW TYPES -----------------------------------------
    
    /** Does neutral behaviour (doing nothing, returning null)
     */
    public NewType[] getNewTypes( Look.NodeSubstitute substitute ) {
        return null;
    }
    
    /** Calls actionBase (substitute, false) and extracts actions
     * from that context.
     *
     * @return the actions at the context or null
     */
    public Action[] getActions( Look.NodeSubstitute substitute ) {
        return actionsForContext (actionBase (substitute, false));
    }
    
    /** Calls actionBase (substitute, true) and extracts actions
     * from that context.
     *
     * @return the actions at the context or null
     */
    public Action[] getContextActions( Look.NodeSubstitute substitute ) {
        return actionsForContext (actionBase (substitute, true));
    }
    
    /** Extracts the first action from getActions, if any.
     * @return the action or null
     */
    public Action getDefaultAction( Look.NodeSubstitute substitute ) {
        Action[] arr = getActions (substitute);
        return arr != null && arr.length > 0 ? arr[0] : null;
    }
    
    // Methods for PROPERTIES AND CUSTOMIZER -----------------------------------
    
    /** Does neutral behaviour (doing nothing, returning null)
     */
    public Node.PropertySet[] getPropertySets( Look.NodeSubstitute substitute ) {
        return null;
    }

    /** Is the customizer for represented object available? Checks whether
     * getCustomizer (substitute) returns non-null value
     *
     * @param substitute The <CODE>Look.NodeSubstitute</CODE> of the node to operate on.
     * @return true if the customizer is available, false otherwise
     */
    public boolean hasCustomizer(Look.NodeSubstitute substitute) {
        return getCustomizer (substitute) != null;
    }
    
    /** Does neutral behaviour (doing nothing, returning null)
     */
    public java.awt.Component getCustomizer( Look.NodeSubstitute substitute ) {        
        return null;
    }
    
    // Methods for CLIPBOARD OPERATIONS ----------------------------------------
     
    /** Does neutral behaviour (doing nothing, returning false)
     */
    public boolean canRename( Look.NodeSubstitute substitute ) {
        return false;
    }
    
    /** Does neutral behaviour (doing nothing, returning false)
     */
    public boolean canDestroy( Look.NodeSubstitute substitute ) {
        return false;
    }
    
    /** Does neutral behaviour (doing nothing, returning false)
     */
    public boolean canCopy( Look.NodeSubstitute substitute ) {
        return false;
    }
    
    /** Does neutral behaviour (doing nothing, returning false)
     */
    public boolean canCut( Look.NodeSubstitute substitute ) {
        return false;
    }
    
    /** Does neutral behaviour (doing nothing, returning null)
     */
    public PasteType[] getPasteTypes( Look.NodeSubstitute substitute, Transferable t) {
        return null;
    }
    
    /** Does neutral behaviour (doing nothing, returning null)
     */
    public PasteType getDropType( Look.NodeSubstitute substitute, Transferable t, int action, int index) {
        return null;
    }
    
    /** Does neutral behaviour (doing nothing, returning null)
     */
    public Transferable clipboardCopy( Look.NodeSubstitute substitute ) throws IOException {
        return null;
    }
    
    /** Does neutral behaviour (doing nothing, returning null)
     */
    public Transferable clipboardCut( Look.NodeSubstitute substitute ) throws IOException {
        return null;
    }
    
    /** Does neutral behaviour (doing nothing, returning null)
     */
    public Transferable drag( Look.NodeSubstitute substitute ) throws IOException {
        return null;
    }
        
    /** Does neutral behaviour (doing nothing, returning null)
     */
    public void destroy(Look.NodeSubstitute substitute) throws IOException {
    }
    
    
    //
    // Icon management
    //
    
    /** Allows subclasses to specify an icon in easier way without need to
    * load the actual objects.
    *
    * <p>For example, if the returned base is <code>/resource/MyIcon</code>, the
    * following images may be used according to the icon state and
    * {@link java.beans.BeanInfo#getIcon presentation type}:
    *
    * <ul><li><code>resource/MyIcon.gif</code><li><code>resource/MyIconOpen.gif</code>
    * <li><code>resource/MyIcon32.gif</code><li><code>resource/MyIconOpen32.gif</code></ul>
    *
    * <P>
    * The default implementation returns null.
    *
    * @param subst the substitute to locate icon for
    * @return the base for icon search (no initial slash) or <code>null</code> if this look does not provide an icon
    */
    protected String iconBase (NodeSubstitute subst) {
        return null;
    }

    /** Allows subclasses to specify actions in a easy way - by providing a
    * name of a JNDI context name where to find the javax.swing.Action objects.
    *
    * <p>By default the method returns name of this class (separated by slashes)
    * with a prefix Looks/Actions. So for a class <code>org.nb.mymod.MyLook</code>
    * the default action context is <em>Looks/Actions/org/nb/mymod/MyLook</em>.
    * As a result it is not necessary to override this method in many cases.
    * 
    * @param subst the substitute to locate actions for
    * @param context false if <code>getActions</code> was called, 
    *    true if <code>getContextActions</code> was called
    * @return the name of a context
    */
    protected String actionBase (NodeSubstitute subst, boolean context) {
        return "Looks/Actions/" + getClass ().getName ().replace ('.', '/');
    }
    
    /** Reads actions from a JNDI context.
     * @param name of the context.
     * @return array of actions
     */
    private static Action[] actionsForContext (String name) {
        try {
            NamingEnumeration en = org.netbeans.api.naming.NamingSupport.createSFSInitialContext().listBindings (name);
            if (!en.hasMoreElements ()) {
                return null;
            }

            ArrayList arr = new ArrayList ();
            while (en.hasMoreElements()) {
                Binding b = (Binding)en.nextElement ();
                arr.add (b.getObject());
            }

            return (Action[])arr.toArray (new Action[arr.size ()]);
        } catch (NamingException ex) {
            return null;
        }
    }
    
    /** Tries to find the right icon for the iconbase.
    * @param type type of icon (from BeanInfo constants)
    * @param ib base where to scan in the array
    * @return icon or null
    */
    private Image findIcon (NodeSubstitute subst, int type, int ib) {
        String[] base = { iconBase (subst) };
        if (base[0] == null) {
            return null;
        }
        
        String res = icons[type + ib].format (base);
        Image im = Utilities.loadImage (res);

        if (im != null) return im;

        // try the first icon
        res = icons[java.beans.BeanInfo.ICON_COLOR_16x16 + ib].format (base);

        im = Utilities.loadImage (res);

        if (im != null) return im;

        if (ib == OPENED_ICON_BASE) {
            // try closed icon also
            return findIcon (subst, type, ICON_BASE);
        }

        // if still not found return default icon
        return null;
    }
    
}
