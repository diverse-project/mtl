/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is Forte for Java, Community Edition. The Initial
 * Developer of the Original Code is Sun Microsystems, Inc. Portions
 * Copyright 1997-2000 Sun Microsystems, Inc. All Rights Reserved.
 */

package org.netbeans.spi.looks;

import java.lang.ref.WeakReference;
import java.lang.ref.ReferenceQueue;

import org.openide.nodes.Node;
import org.openide.util.RequestProcessor;

import org.netbeans.api.looks.*;

/** 
 * Utility class which allows to fire events on the LookNode according
 * to events of the represented object. This class should be used as a base
 * class for EventListener registered to represented objects.
 * <P>
 * The LookNode interior is hold by a WeakReference so the Node can be 
 * garbage collected even if the represented object still exists.<BR>
 * If you really want the node is not garbage collected while the 
 * represented object exists then hardreference the <CODE>Node.Interior</CODE>
 * from the subclass.
 * <P>
 * Helper methods allow automatic changes of Icon, Name and DisplayName
 * if some properies are changed.
 */
public abstract class EventTranslator extends WeakReference {

    /** Queue with all weak references */
    private static ReferenceQueue QUEUE = new ReferenceQueue ();
    /** How often clean */
    private static int CLEANER_TIME = 25000;
    /** Clearner task */
    private static RequestProcessor.Task CLEANER_TASK = RequestProcessor.postRequest(
        new Cleaner (), CLEANER_TIME, Thread.MIN_PRIORITY
        );
    
    /** Fake instance to fire event on when the node was garbage collected. */
    private static Look.NodeSubstitute NULL_SUBSTITUTE;

    /** Creates new EventTranslator for given LookNode.Interior
     * @param LookNode.Interior the node to fire events on.
     */
    public EventTranslator ( Look.NodeSubstitute substitute ) {
        super( substitute, QUEUE );
    }

    /** This method is called when the node was garbage collected. You shoud
     * unregister from all objects where this object was registered as a 
     * listener.
     */ 
    protected abstract void unregister();

    /** Gets the substitute to fire on
     */
    protected Look.NodeSubstitute getSubstitute() {
        Look.NodeSubstitute substitute = (Look.NodeSubstitute)get();

        if ( substitute == null || substitute.getRepresentedObject() == null ) {
            unregister();

            if ( NULL_SUBSTITUTE == null ) {
                NULL_SUBSTITUTE = new NullNodeSubstitute();
            }
            return NULL_SUBSTITUTE;
        }
        else {
            return substitute;
        }
    }
    
    
    // Innerclasses ------------------------------------------------------------
    
    /** Class that periodically runs cleaning of the queue.
    */
    private static final class Cleaner extends Object implements Runnable {
        public void run () {
            for (;;) {
                EventTranslator et = (EventTranslator)QUEUE.poll();
                if (et == null) 
                    break;
                et.unregister();
            }

            CLEANER_TASK.schedule (CLEANER_TIME);
        }
    }
    
    /** Empty Look.NodeSubstitute which does not fire any events
     */
    private static final class NullNodeSubstitute extends Look.NodeSubstitute {
        public NullNodeSubstitute () {
        }
        
        public Object getRepresentedObject() {
            return null;
        }; 
        
        public void firePropertyChange( String name, Object o, Object n ) {
        }

        public void fireNameChange( String o, String n ) {
        }
        
        public void fireDisplayNameChange( String o, String n ) {
        }
        
        public void fireShortDescriptionChange(String o, String n) {
        }

        public void fireIconChange() {
        }

        public void fireOpenedIconChange() {
        }

        public void firePropertySetsChange( Node.PropertySet[] o, Node.PropertySet[] n ) {
        }
       
        public void fireNodeDestroyed() {
        }

        public void refreshChildren() {
        }
    }
    
}