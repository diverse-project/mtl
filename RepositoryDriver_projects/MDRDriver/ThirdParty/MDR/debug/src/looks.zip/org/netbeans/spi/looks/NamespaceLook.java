/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is Forte for Java, Community Edition. The Initial
 * Developer of the Original Code is Sun Microsystems, Inc. Portions
 * Copyright 1997-2002 Sun Microsystems, Inc. All Rights Reserved.
 */

package org.netbeans.spi.looks;

import java.util.List;
import java.util.Enumeration;

import javax.naming.*;

import org.openide.nodes.*;
import org.openide.util.enum.*;

import org.netbeans.api.looks.*;
import java.util.ArrayList;

/** 
 * Searches for a look in namespace given name of context to search in
 * and a a possible set of names that should be checked.
 *
 * @author Jaroslav Tulach
 * @version 0.2
 */
public abstract class NamespaceLook extends ProxyLook {
    /** InitialContext or NamingException depending on how we succeded to find the correct look */
    private static Object context;

    /** Prefix to prepend to all namespace names */
    private String prefix;
    
    /** Constructs new namespace looks with provided subspace to search
     *
     * @param prefix prefix to search, e.g. <sample>Looks/Types/</sample>, etc.
     */
    public NamespaceLook (String prefix) {
        this.prefix = prefix;
    }
    
    /** Finds the correct look in namespace according to the enumeration
     * of possible names provided by <code>namesFor</code> method.
     *
     * @param method ignored
     * @param substitute the substitute which method will be called with or
     *   null if we are in notification of changes and we have no substitute
     * @return the look to delegate to or null
     */
    protected final Look[] delegateTo (long method, NodeSubstitute substitute) {
        return new Look[] { findLook (
            prefix, namesFor (substitute.getRepresentedObject ()), null
        ) };
    }
    
    /** Defines the list of names that should be searched for a given 
     * represented object.
     *
     *
     * <P>
     * Subclasses are allowed to provide different implementation which can
     * base the naming based on for example public ID
     * for <code>org.w3c.dom.Document</code>.
     *
     * <P>
     * The <link>Look.DEFAULT</link> uses the this class and returns enumeration
     * of all superclasses and superinterfaces for provided object.
     *
     * @param obj the represented object
     * @return enumeration of String
     * @see Look.DEFAULT
     * @since Made non abstract in version 0.2
     */
    protected Enumeration namesFor (Object obj) {
        return obj == null ? EmptyEnumeration.EMPTY : forClass (obj.getClass ());
    }
    
    /** Offers all looks available in the namespace. Takes input from
     * namesFor and finds all looks that represent some name in enumeration.
     * 
     * @param subst substitute to find looks for
     * @return array of available looks
     */
    public Look[] availableLooks (NodeSubstitute subst) {
        Enumeration en = namesFor (subst.getRepresentedObject ());
        ArrayList looks = new ArrayList ();
        
        // collects all looks into array list looks
        findLook (prefix, en, looks);
        
        return (Look[])looks.toArray (new Look[0]);
    }
        
    
    /** Finds look(s) for a class.
     * @param prefix prefix string to add to each name or null
     * @param names list of Strings to check their names (c1/c2/name)
     * @param looks list where to add all found looks or null if just find one
     * @return look found or null 
     */
    private static Look findLook (String prefix, Enumeration names, List looks) {
        if (context == null) {
            try {
                context = org.netbeans.api.naming.NamingSupport.createSFSInitialContext();
            } catch (NamingException ex) {
                context = ex;
            }
        }
        
        if (context instanceof Context) {
            return findLook ((Context)context, prefix, names, looks);
        } else {
            return null;
        }
    }
    
    /** Searches for a look in given namespace and in the order specified by
     * given names.
     *
     * @param namespace the root context to search from
     * @param prefix prefix string to add to each name or null
     * @param names list of Strings to check their names (c1/c2/name)
     * @param toAdd list where to add all found looks
     * @return the look or null
     */
    private static Look findLook (
        Context namespace, String prefix, Enumeration names, List toAdd
    ) {
        java.util.Collection checks = new java.util.HashSet();
        while (names.hasMoreElements ()) {
            try {
                String check = (String)names.nextElement ();
                if (!checks.add(check))
                    continue;
                if (prefix != null) {
                    check = prefix + check;
                }
                
                NamingEnumeration en = namespace.listBindings (check);
                while (en.hasMoreElements ()) {
                    Binding b = (Binding)en.next ();
                    Object o = b.getObject ();
                    if (o instanceof Look) {
                        if (toAdd != null) {
                            // we are searching for all looks
                            toAdd.add (o);
                        } else {
                            // we need just one
                            return (Look)o;
                        }
                    }
                }
            } catch (NamingException ex) {
            }
        }
        return null;
    }

    /** Enumeration for a java class.
     * @param c class 
     * @return enumeration of names of implemented/extended classes in form suitable
     *      for findLook
     */
    private static Enumeration forClass (Class c) {
        QueueEnumeration en = new QueueEnumeration () {
            protected void process (Object o) {
                Class x = (Class)o;
                Class s = x.getSuperclass();
                put (x.getInterfaces ());
                if (s != null && s != Object.class) {
                    // if not object process all interfaces and super classes
                    put (s);
                }
            }
        };
        if (c != Object.class) {
            en.put (c);
        }
        
        AlterEnumeration alter = new AlterEnumeration (en) {
            protected Object alter (Object clazz) {
                Class c = (Class)clazz;
                return c.getName ().replace ('.', '/');
            }
        };
        
        return new SequenceEnumeration (alter, new SingletonEnumeration ("java/lang/Object")); // NOI18N
    }
}
