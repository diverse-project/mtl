/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is Forte for Java, Community Edition. The Initial
 * Developer of the Original Code is Sun Microsystems, Inc. Portions
 * Copyright 1997-2000 Sun Microsystems, Inc. All Rights Reserved.
 */

package org.netbeans.spi.looks;



import org.openide.nodes.*;

import org.netbeans.api.looks.*;
import org.openide.util.NbBundle;

/** 
 * This is base class for delegating to other looks or nodes. All methods 
 * delegate to the delegate, unless they are masked.
 * <P>
 * All the methods contain  simple deleagation to the {@link Look} 
 * passed as parameter into the constructor, if the mask contains flag
 * for the method.<P>
 * Use the methods: {@link #setLookMask}, {@link #lookMask}, {@link #lookMask}, 
 * {@link #lookUnmask} for work with the mask.<BR> 
 * The default state is to delegate all methods (i.e. the mask is set to
 * {@link #ALL_METHODS}.)
 *
 * @author Petr Hrebejk
 */
public class FilterLook extends ProxyLook {
    /** Contains current mask of the node */
    private long mask;
    
    /** Contains the Look to delegate to. Array of one member */
    private Look[] delegate;
    
    /** Creates new filter and delegates all methods to the provided delegate
     * @param delegate The Look to delegate to.
     */
    public FilterLook (Look delegate) {
        this (delegate, ALL_METHODS);
    }
    
    /** Creates new filter look and sets its filtering
     * @param delegate look to delegate to
     * @param mask the mask to use (one of method contants)
     */
    public FilterLook (Look delegate, long mask) {
        this.delegate = new Look[] { delegate };
        this.mask = mask;
    }
    
    /** Name of the look. Composed from the name of the delegate.
     */
    public String getName () {
        return "Filter[" + delegate[0].getName ();
    }
    
    /** Display name of the look. Composed from the name of the delegate.
     */
    public String getDisplayName () {
        return NbBundle.getMessage (FilterLook.class, "LAB_Filter", delegate[0].getDisplayName ());
    }
    
    /** A method that checks whether given method should be delegated to 
     * the look provided in constructor or not. 
     * <P>
     * The default implementation ignores the context and just checks 
     * the mask which can be modified by <link>lookMask</link>, <link>lookUnmask</link>
     * methods.
     * <P>
     * Subclasses might override 
     * this method with implementation that bases its decision on different criteria.
     *
     * @param method one of the constants defined here that identifies the method
     *    we want to delegate to
     * @param substitute the substitute that the method will be called with or 
     *    null if we are in notification of changes and we have no substitute
     * @return either the delegate look or null
     */
    protected final Look[] delegateTo (long method, NodeSubstitute substitute) {
        return ( mask & method ) > 0 ? delegate : null;
    }
    
    // Methods of look itself -------------------------------------------------
    
    /** Sets mask for this look. Only methods contained in the mask
     * will be delegated. Other methods will return neutral values.
     * @param mask The mask to be set.
     */
    protected final void setLookMask( long mask ) {
        this.mask = mask;
    }
    
    /** Returns the current mask for this filter look.
     * @return Current mask.
     */
    protected final long getLookMask( ) {
        return mask;
    }
    
    /** Masks given methods. Removes given methods from given mask. 
     * The masked methods will be no longer delegated.
     * @param methods Logical <CODE>OR</CODE> of methods which have to be masked.
     * @return Current mask.
     */
    protected final long lookMask( long methods ) {
        mask |= methods;
        return mask;
    }
     
    /** Unmasks given methods. Adds given methods from given mask. 
     * The masked methods will start to be delegated.
     * @param methods Logical <CODE>OR</CODE> of methods which have to be unmasked.
     * @return Current mask.
     */
    protected final long lookUnmask( long methods ) {
        mask &= ~methods; 
        return mask;
    }
}
