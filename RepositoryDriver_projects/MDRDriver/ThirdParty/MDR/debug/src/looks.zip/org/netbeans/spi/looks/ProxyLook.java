/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is Forte for Java, Community Edition. The Initial
 * Developer of the Original Code is Sun Microsystems, Inc. Portions
 * Copyright 1997-2000 Sun Microsystems, Inc. All Rights Reserved.
 */

package org.netbeans.spi.looks;

import java.awt.Image;
import java.awt.datatransfer.Transferable;
import java.io.IOException;

import javax.swing.Action;

import org.openide.nodes.*;
import org.openide.util.HelpCtx;
import org.openide.util.Lookup;
import org.openide.util.datatransfer.NewType;
import org.openide.util.datatransfer.PasteType;

import org.netbeans.api.looks.*;
import java.util.ArrayList;
import org.openide.util.lookup.ProxyLookup;
import java.util.Arrays;
import java.util.HashMap;

/** 
 * This is base class for delegating to other looks. All methods are 
 * enumerated by numeric constants and by overriding <link>delegateTo</link>
 * subclasses can easily decide which methods and where delegate.
 * <P>
 * It is safe to assume that some of the functionality will be delegated
 * and some of it will not, but it is desirable to delegate the
 * <link>ATTACH_TO</link> to all looks because it allows the proxied looks 
 * to store information needed later. On the other hand not delegating
 * this call is possible if it is known that the proxied to look will
 * not need such informations later.
 * <P>
 * Also it is not suggested to switch the looks that is being delegated to
 * during different calls, because it can also result in calls to a look 
 * that has not have been attached by calling attachTo.
 * <P>
 * It is also possible to change the represented object for a looks 
 * those are being delegated to (see method <link>delegateObject</link>)
 * but again it is necessary to allow delegation of <link>ATTACH_TO</link>.
 *
 * @author Jaroslav Tulach
 */
public abstract class ProxyLook extends Look {
    /** Mask for enabling (unmasking) all methods */
    public static final long ALL_METHODS = Long.MAX_VALUE;
    /** Mask for disabling (masking) all methods */
    public static final long NO_METHODS = 0;
    /** Mask for the method {@link #getCookie}. */
    public static final long CREATE_LOOKUP = 1;
    /** Mask for the method {@link #getHandle}. */
//    public static final long GET_HANDLE = CREATE_LOOKUP << 1;
    /** Mask for the method {@link #getDisplayName}. */
    public static final long GET_DISPLAY_NAME = CREATE_LOOKUP << 1;
    /** Mask for the method {@link #getName}. */
    public static final long GET_NAME = GET_DISPLAY_NAME << 1;
    /** Mask for the method {@link #setName}. */
    public static final long SET_NAME = GET_NAME << 1;
    /** Mask for the method {@link #getShortDescription}. */
    public static final long GET_SHORT_DESCRIPTION = SET_NAME << 1;
    /** Mask for the method {@link #getIcon}. */
    public static final long GET_ICON = GET_SHORT_DESCRIPTION << 1;
    /** Mask for the method {@link #getOpenedIcon}. */
    public static final long GET_OPENED_ICON = GET_ICON << 1;
    /** Mask for the method {@link #getHelpCtx}. */
    public static final long GET_HELP_CTX = GET_OPENED_ICON << 1;
    /** Mask for the method {@link #getChildObjects}. */
    public static final long GET_CHILD_OBJECTS = GET_HELP_CTX << 1;
    /** Mask for the method {@link #getNewTypes}. */
    public static final long GET_NEW_TYPES = GET_CHILD_OBJECTS << 1;
    /** Mask for the method {@link #getActions}. */
    public static final long GET_ACTIONS = GET_NEW_TYPES << 1;
    /** Mask for the method {@link #getContextActions}. */
    public static final long GET_CONTEXT_ACTIONS = GET_ACTIONS << 1;
    /** Mask for the method {@link #getDefaultAction}. */
    public static final long GET_DEFAULT_ACTION = GET_CONTEXT_ACTIONS << 1;
    /** Mask for the method {@link #getPropertySets}. */
    public static final long GET_PROPERTY_SETS = GET_DEFAULT_ACTION << 1;
    /** Mask for the method {@link #getCustomizer}. */
    public static final long GET_CUSTOMIZER = GET_PROPERTY_SETS << 1;
    /** Mask for the method {@link #canRename}. */
    public static final long CAN_RENAME = GET_CUSTOMIZER << 1;
    /** Mask for the method {@link #canDestroy}. */
    public static final long CAN_DESTROY = CAN_RENAME << 1;
    /** Mask for the method {@link #canCopy}. */
    public static final long CAN_COPY = CAN_DESTROY << 1;
    /** Mask for the method {@link #canCut}. */
    public static final long CAN_CUT = CAN_COPY << 1;
    /** Mask for the method {@link #getPasteTypes}. */
    public static final long GET_PASTE_TYPES = CAN_CUT << 1;
    /** Mask for the method {@link #getDropType}. */
    public static final long GET_DROP_TYPE = GET_PASTE_TYPES << 1;
    /** Mask for the method {@link #clipboardCopy}. */
    public static final long CLIPBOARD_COPY = GET_DROP_TYPE << 1;
    /** Mask for the method {@link #clipboardCut}. */
    public static final long CLIPBOARD_CUT = CLIPBOARD_COPY << 1;
    /** Mask for the method {@link #drag}. */
    public static final long DRAG = CLIPBOARD_CUT << 1;
    /** Mask for the method {@link #destroy}. */
    public static final long DESTROY = DRAG << 1;
    /** Mask for the method {@link #hasCustomizer}. */
    public static final long HAS_CUSTOMIZER = DESTROY << 1;
    
    /** Creates new instance of look does no work.
     */
    public ProxyLook() {
    }
    
    /** A heart of this class -
     * method that can decide where to delegate approriate call. 
     * 
     * <P>
     * The default implementation ignores all parameters and just returns null
     * so no action is ever done.
     * Subclasses might override 
     * this method with implementation that bases its decision on different criteria.
     *
     * @param method one of the constants defined here that identifies the method
     *    we want to delegate to
     * @param substitute the substitute which method will be called with
     * @return the array of looks that we want to delegate to (may contain nulls on 
     *      places of looks we do not want to delegate to) or null if no delegation needed
     *
     * @warning the caller should maintain the delegates' positions in the returned
     * array and rather pass a null at some position, if the Look should not be delegated to,
     * instead of compacting of the array. The ProxyLook takes performance advantage from the
     * fact, that delegate positions are mostly the same.
     */
    protected Look[] delegateTo (long method, NodeSubstitute substitute) {
        return null;
    }

    /** Controls whether we delegate to all looks provided by <link>delegateTo</link>
     * method or just the first one that returns a value. Useful for methods that 
     * return an array of objects.
     * 
     * <P>
     * The default implementation return true to signal that we delegate to all.
     *
     * @param method one of the constants defined here that identifies the method
     *    we want to delegate to
     * @param substitute the substitute which method will be called with
     * @return true of false
     */
    protected boolean delegateAll (long method, NodeSubstitute substitute) {
        return true;
    }
    
    /** Extracts represented object for provided substitute.
     * <P>
     * Default implementation just calls substitute.getRepresentedObject (), but 
     * subclasses might use this method to change the represented object
     * for the look they delegate to.
     *
     * @param substitute the substitute to find represented object for
     * @return the represented object for the substitute (not null)
     */
    protected Object delegateObject (NodeSubstitute substitute) {
        return substitute.getRepresentedObject ();
    }
    
    // General methods ---------------------------------------------------------
    
    /** Performs specialized setup for the ProxyLook. Subclasses may receive
     * attach notification when they override {@link #proxyAttachTo} instead of 
     * this method.
     * @return opaque data needed by the ProxyLook implementation.
     */
    protected final Object attachTo(Look.NodeSubstitute substitute) {
        // Cannot be overriden because it performs important action of 
        // creating substitute S, without it the look we delegate to will
        // not work correctly
        Object o = super.attachTo(substitute);
        return new Object[] {
            new Object[0], o
        };
    }
        
    /**
     * Retrieves the data attached to the particular NodeSubstitute for the
     * ProxyLook itself.
     * @return the attached data Object, or null if no data was attached.
     */
    protected final Object getAttachedData(Look.NodeSubstitute subst) {
        Object o = super.getAttachedData(subst);
        if (!(o instanceof Object[])) {
            return null;
        }
        
        Object[] a = (Object[])o;
        if (a.length > 1) {
            return a[1];
        } else
            return null;
    }
    
    /** Delegates to delegate or does neutral behaviour (doing nothing, returning null)
     */
    public Lookup createLookup (Look.NodeSubstitute substitute) {
        Look[] delegate = delegateTo (CREATE_LOOKUP, substitute);
        if (delegate != null && delegate.length > 0) {
            if (delegate.length == 1) {
                return delegate[0] == null ? null : delegate[0].createLookup (s (substitute, delegate[0], 0));
            } else {
                ArrayList ll = new ArrayList (delegate.length);
                for (int i = 0; i < delegate.length; i++) {
                    Lookup lookup = delegate[i] == null ? null : delegate[i].createLookup (s (substitute, delegate[i], i));
                    if (lookup != null) {
                        ll.add (lookup);
                    }
                }
                
                if (ll.size () > 0) {
                    Lookup[] arr = new Lookup[ll.size ()];
                    ll.toArray (arr);
                    return new ProxyLookup (arr);
                } else {
                    return null;
                }
            }
        } else {
            return null;
        }
    }

    /** Delegates to delegate or does neutral behaviour (doing nothing, returning null)
     */
    public Look[] availableLooks(Look.NodeSubstitute substitute) {
        return null;
    }
    
    // Methods for STYLE -------------------------------------------------------
    
    /** Delegates to delegate or does neutral behaviour (doing nothing, returning null)
     */
    public String getDisplayName( Look.NodeSubstitute substitute ) {
        Look[] delegate = delegateTo (GET_DISPLAY_NAME, substitute);
        if (delegate != null) {
            for (int i = 0; i < delegate.length; i++) {
                if (delegate[i] != null) {
                    String h = delegate[i].getDisplayName (s (substitute, delegate[i], i));
                    if (h != null) {
                        return h;
                    }
                }
            }
        }
        return null;
    }
    
    /** Delegates to delegate or does neutral behaviour (doing nothing, returning null)
     */
    public String getName( Look.NodeSubstitute substitute ) {
        Look[] delegate = delegateTo (GET_NAME, substitute);
        if (delegate != null) {
            for (int i = 0; i < delegate.length; i++) {
                if (delegate[i] != null) {
                    String h = delegate[i].getName (s (substitute, delegate[i], i));
                    if (h != null) {
                        return h;
                    }
                }
            }
        }
        return null;
    }
    
    /** Delegates to delegate or does neutral behaviour (doing nothing, returning null)
     */
    public void setName(Look.NodeSubstitute substitute, String newName) {
        Look[] delegate = delegateTo (SET_NAME, substitute);
        if (delegate != null) {
            for (int i = 0; i < delegate.length; i++) {
                if (delegate[i] != null) {
                    delegate[i].setName (s (substitute, delegate[i], i), newName);
                }
            }
        }
    }
    
    /** Delegates to delegate or does neutral behaviour (doing nothing, returning null)
     */
    public String getShortDescription ( Look.NodeSubstitute substitute ) {
        Look[] delegate = delegateTo (GET_SHORT_DESCRIPTION, substitute);
        if (delegate != null) {
            for (int i = 0; i < delegate.length; i++) {
                if (delegate[i] != null) {
                    String h = delegate[i].getShortDescription (s (substitute, delegate[i], i));
                    if (h != null) {
                        return h;
                    }
                }
            }
        }
        return null;
    }
    
    /** Delegates to delegate or does neutral behaviour (doing nothing, returning null)
     */
    public Image getIcon( Look.NodeSubstitute substitute, int type ) {
        Look[] delegate = delegateTo (GET_ICON, substitute);
        if (delegate != null) {
            for (int i = 0; i < delegate.length; i++) {
                if (delegate[i] != null) {
                    Image h = delegate[i].getIcon (s (substitute, delegate[i], i), type);
                    if (h != null) {
                        return h;
                    }
                }
            }
        }
        return null;
    }
    
    /** Delegates to delegate or does neutral behaviour (doing nothing, returning null)
     */
    public Image getOpenedIcon( Look.NodeSubstitute substitute, int type ) {
        Look[] delegate = delegateTo (GET_OPENED_ICON, substitute);
        if (delegate != null) {
            for (int i = 0; i < delegate.length; i++) {
                if (delegate[i] != null) {
                    Image h = delegate[i].getOpenedIcon (s (substitute, delegate[i], i), type);
                    if (h != null) {
                        return h;
                    }
                }
            }
        }
        return null;
    }
    
    /** Delegates to delegate or does neutral behaviour (doing nothing, returning null)
     */
    public HelpCtx getHelpCtx( Look.NodeSubstitute substitute ) {
        Look[] delegate = delegateTo (GET_HELP_CTX, substitute);
        if (delegate != null) {
            for (int i = 0; i < delegate.length; i++) {
                if (delegate[i] != null) {
                    HelpCtx h = delegate[i].getHelpCtx (s (substitute, delegate[i], i));
                    if (h != null) {
                        return h;
                    }
                }
            }
        }
        return null;
    }
    
    // Methods for CHILDREN ----------------------------------------------------
    
    /** Delegates to delegate or does neutral behaviour (doing nothing, returning null)
     */
    public Object[] getChildObjects( Look.NodeSubstitute substitute ) {
        Look[] delegate = delegateTo (GET_CHILD_OBJECTS, substitute);

        if (delegate == null) {
            return null;
        }

        boolean merge = delegateAll (GET_CHILD_OBJECTS, substitute);
        
        Object arrays = null;
        
        // Create list of subarrays        
        for (int i = 0; i < delegate.length; i++) {
            Look look = delegate[i];
            if (look == null) {
                continue;
            }
            
            Object data[] = look.getChildObjects (s (substitute, delegate[i], i));
            if (data == null || data.length == 0 ) {
                continue; 
            }
            
            if (!merge) {
                // we are not merging and need keys just by one look 
                return data;
            }
            
            // add all those objects into array
            if (arrays == null) {
                arrays = data;
            } else {
                ArrayList l;
                if (arrays instanceof Object[]) {
                    // arrays contains Object[] convert to ArrayList
                    Object[] arr = (Object[])arrays;
                    l = new ArrayList (arr.length * 2);
                    l.addAll (Arrays.asList (arr));
                    arrays = l;
                } else {
                    l = (ArrayList)arrays;
                }
                l.addAll (Arrays.asList (data));
            }
        }
        
        if (arrays == null) {
            // Return if there is nothing to merge
            return null;
        }
       
        return arrays instanceof Object[] ? (Object[])arrays : ((ArrayList)arrays).toArray ();
    }
    
    // Methods for ACTIONS & NEW TYPES -----------------------------------------
    
    /** Delegates to delegate or does neutral behaviour (doing nothing, returning null)
     */
    public NewType[] getNewTypes( Look.NodeSubstitute substitute ) {
        Look[] delegate = delegateTo (GET_NEW_TYPES, substitute);

        if (delegate == null) {
            return null;
        }

        boolean merge = delegateAll (GET_NEW_TYPES, substitute);
        
        Object arrays = null;
        
        // Create list of subarrays        
        for (int i = 0; i < delegate.length; i++) {
            Look look = delegate[i];
            if (look == null) {
                continue;
            }
            
            NewType[] data = look.getNewTypes (s (substitute, delegate[i], i));
            if (data == null || data.length == 0 ) {
                continue; 
            }
            
            if (!merge) {
                // we are not merging and need keys just by one look 
                return data;
            }
            
            // add all those objects into array
            if (arrays == null) {
                arrays = data;
            } else {
                ArrayList l;
                if (arrays instanceof Object[]) {
                    // arrays contains Object[] convert to ArrayList
                    Object[] arr = (Object[])arrays;
                    l = new ArrayList (arr.length * 2);
                    l.addAll (Arrays.asList (arr));
                    arrays = l;
                } else {
                    l = (ArrayList)arrays;
                }
                l.addAll (Arrays.asList (data));
            }
        }
        
        if (arrays == null) {
            // Return if there is nothing to merge
            return null;
        }
       
        return arrays instanceof NewType[] ? (NewType[])arrays : (NewType[])((ArrayList)arrays).toArray (new NewType[0]);
    }
    
    /** Delegates to delegate or does neutral behaviour (doing nothing, returning null)
     */
    public Action[] getActions( Look.NodeSubstitute substitute ) {
        Look[] delegate = delegateTo (GET_ACTIONS, substitute);

        if (delegate == null) {
            return null;
        }

        boolean merge = delegateAll (GET_ACTIONS, substitute);
        
        Object arrays = null;
        
        // Create list of subarrays        
        for (int i = 0; i < delegate.length; i++) {
            Look look = delegate[i];
            if (look == null) {
                continue;
            }
            
            Action[] data = look.getActions (s (substitute, delegate[i], i));
            if (data == null || data.length == 0 ) {
                continue; 
            }
            
            if (!merge) {
                // we are not merging and need keys just by one look 
                return data;
            }
            
            // add all those objects into array
            if (arrays == null) {
                arrays = data;
            } else {
                ArrayList l;
                if (arrays instanceof Object[]) {
                    // arrays contains Object[] convert to ArrayList
                    Object[] arr = (Object[])arrays;
                    l = new ArrayList (arr.length * 2);
                    l.addAll (Arrays.asList (arr));
                    arrays = l;
                } else {
                    l = (ArrayList)arrays;
                }
                l.addAll (Arrays.asList (data));
            }
        }
        
        if (arrays == null) {
            // Return if there is nothing to merge
            return null;
        }
       
        return arrays instanceof Action[] ? (Action[])arrays : (Action[])((ArrayList)arrays).toArray (new Action[0]);
    }
    
    /** Delegates to delegate or does neutral behaviour (doing nothing, returning null)
     */
    public Action[] getContextActions( Look.NodeSubstitute substitute ) {
        Look[] delegate = delegateTo (GET_CONTEXT_ACTIONS, substitute);

        if (delegate == null) {
            return null;
        }

        boolean merge = delegateAll (GET_CONTEXT_ACTIONS, substitute);
        
        Object arrays = null;
        
        // Create list of subarrays        
        for (int i = 0; i < delegate.length; i++) {
            Look look = delegate[i];
            if (look == null) {
                continue;
            }
            
            Action[] data = look.getContextActions (s (substitute, delegate[i], i));
            if (data == null || data.length == 0 ) {
                continue; 
            }
            
            if (!merge) {
                // we are not merging and need keys just by one look 
                return data;
            }
            
            // add all those objects into array
            if (arrays == null) {
                arrays = data;
            } else {
                ArrayList l;
                if (arrays instanceof Object[]) {
                    // arrays contains Object[] convert to ArrayList
                    Object[] arr = (Object[])arrays;
                    l = new ArrayList (arr.length * 2);
                    l.addAll (Arrays.asList (arr));
                    arrays = l;
                } else {
                    l = (ArrayList)arrays;
                }
                l.addAll (Arrays.asList (data));
            }
        }
        
        if (arrays == null) {
            // Return if there is nothing to merge
            return null;
        }
       
        return arrays instanceof Action[] ? (Action[])arrays : (Action[])((ArrayList)arrays).toArray (new Action[0]);
    }
    
    /** Delegates to delegate or does neutral behaviour (doing nothing, returning null)
     */
    public Action getDefaultAction( Look.NodeSubstitute substitute ) {
        Look[] delegate = delegateTo (GET_DEFAULT_ACTION, substitute);
        if (delegate != null) {
            for (int i = 0; i < delegate.length; i++) {
                if (delegate[i] != null) {
                    Action h = delegate[i].getDefaultAction (s (substitute, delegate[i], i));
                    if (h != null) {
                        return h;
                    }
                }
            }
        }
        return null;
    }
    
    // Methods for PROPERTIES AND CUSTOMIZER -----------------------------------
    
    /** Delegates to delegate or does neutral behaviour (doing nothing, returning null)
     */
    public Node.PropertySet[] getPropertySets( Look.NodeSubstitute substitute ) {
        Look[] delegate = delegateTo (GET_PROPERTY_SETS, substitute);
        if (delegate == null) {
            return null;
        }
        
        boolean merge = delegateAll (GET_PROPERTY_SETS, substitute);
        
        ArrayList setsList = null;
        HashMap nameMap = null;
        
        // Create list of property sets and the name map
        for (int index = 0; index < delegate.length; index++) {
            Look look = delegate[index];
            if (look == null) {
                continue;
            }

            Node.PropertySet[] sets = look.getPropertySets( s (substitute, delegate[index], index) );
            if ( sets == null || sets.length == 0 ) {
                continue; // Look does not provide any properties
            }
            
            if (!merge) {
                // no need to do merging, return the first reasonable value
                return sets;
            }
            
            if (setsList == null) {
                if (index + 1 == delegate.length) {
                    // I am the last look in the raw, no need to do merging
                    return sets;
                }
                setsList = new ArrayList ();
                nameMap = new HashMap (37);
            }
                
            
            // Merge the property sets. We use sheet sets for
            // more comfortable work with propertySets
            for ( int i = 0; i < sets.length; i++ ) {
                if ( sets[i].getName() == null ) {
                    continue; // Ignore unnamed lists
                }
                Sheet.Set es = (Sheet.Set)nameMap.get( sets[i].getName() );
                if ( es == null ) { //Such sheet does not exist yet
                    es = new Sheet.Set( );
                    es.setName( sets[i].getName() );
                    es.setDisplayName( sets[i].getDisplayName() );
                    es.setShortDescription( sets[i].getShortDescription() );
                    es.put( sets[i].getProperties() );
                    setsList.add( es );
                    nameMap.put( sets[i].getName(), es );
                }
                else { // Sheet exists => merge properties
                    Node.Property[] props = sets[i].getProperties();
                    if ( props == null || props.length == 0 ) {
                        continue;
                    }
                    else {
                        es.put( sets[i].getProperties() );
                    }
                }                
            }        
        }
        
        if ( setsList == null || setsList.size() == 0 ) {
            return null;
        }
        else {
            Node.PropertySet[] result = new Node.PropertySet[ setsList.size() ];
            setsList.toArray( result );
            return result;
        }
    }
    
    /** Delegates to delegate or does neutral behaviour (doing nothing, returning null)
     */
    public java.awt.Component getCustomizer( Look.NodeSubstitute substitute ) {        
        Look[] delegate = delegateTo (GET_CUSTOMIZER, substitute);
        if (delegate != null) {
            for (int i = 0; i < delegate.length; i++) {
                if (delegate[i] != null) {
                    java.awt.Component h = delegate[i].getCustomizer (s (substitute, delegate[i], i));
                    if (h != null) {
                        return h;
                    }
                }
            }
        }
        return null;
    }
    
    /** Delegates to delegate or does neutral behaviour (doing nothing, returning null)
     */
    public boolean hasCustomizer( Look.NodeSubstitute substitute ) {        
        Look[] delegate = delegateTo (HAS_CUSTOMIZER, substitute);
        if (delegate != null) {
            for (int i = 0; i < delegate.length; i++) {
                if (delegate[i] != null) {
                    if (delegate[i].hasCustomizer (s (substitute, delegate[i], i))) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    // Methods for CLIPBOARD OPERATIONS ----------------------------------------
     
    /** Delegates to delegate or does neutral behaviour (doing nothing, returning false)
     */
    public boolean canRename( Look.NodeSubstitute substitute ) {
        Look[] delegate = delegateTo (CAN_RENAME, substitute);
        if (delegate != null) {
            for (int i = 0; i < delegate.length; i++) {
                if (delegate[i] != null) {
                    boolean b = delegate[i].canRename (s (substitute, delegate[i], i));
                    if (b) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    /** Delegates to delegate or does neutral behaviour (doing nothing, returning false)
     */
    public boolean canDestroy( Look.NodeSubstitute substitute ) {
        Look[] delegate = delegateTo (CAN_DESTROY, substitute);
        if (delegate != null) {
            for (int i = 0; i < delegate.length; i++) {
                if (delegate[i] != null) {
                    boolean b = delegate[i].canDestroy (s (substitute, delegate[i], i));
                    if (b) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    /** Delegates to delegate or does neutral behaviour (doing nothing, returning false)
     */
    public boolean canCopy( Look.NodeSubstitute substitute ) {
        Look[] delegate = delegateTo (CAN_COPY, substitute);
        if (delegate != null) {
            for (int i = 0; i < delegate.length; i++) {
                if (delegate[i] != null) {
                    boolean b = delegate[i].canCopy (s (substitute, delegate[i], i));
                    if (b) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    /** Delegates to delegate or does neutral behaviour (doing nothing, returning false)
     */
    public boolean canCut( Look.NodeSubstitute substitute ) {
        Look[] delegate = delegateTo (CAN_CUT, substitute);
        if (delegate != null) {
            for (int i = 0; i < delegate.length; i++) {
                if (delegate[i] != null) {
                    boolean b = delegate[i].canCut (s (substitute, delegate[i], i));
                    if (b) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    /** Delegates to delegate or does neutral behaviour (doing nothing, returning null)
     */
    public PasteType[] getPasteTypes( Look.NodeSubstitute substitute, Transferable t) {
        Look[] delegate = delegateTo (GET_PASTE_TYPES, substitute);

        if (delegate == null) {
            return null;
        }

        boolean merge = delegateAll (GET_PASTE_TYPES, substitute);
        
        Object arrays = null;
        
        // Create list of subarrays        
        for (int i = 0; i < delegate.length; i++) {
            Look look = delegate[i];
            if (look == null) {
                continue;
            }
            
            PasteType[] data = look.getPasteTypes (s (substitute, delegate[i], i), t);
            if (data == null || data.length == 0 ) {
                continue; 
            }
            
            if (!merge) {
                // we are not merging and need keys just by one look 
                return data;
            }
            
            // add all those objects into array
            if (arrays == null) {
                arrays = data;
            } else {
                ArrayList l;
                if (arrays instanceof Object[]) {
                    // arrays contains Object[] convert to ArrayList
                    Object[] arr = (Object[])arrays;
                    l = new ArrayList (arr.length * 2);
                    l.addAll (Arrays.asList (arr));
                    arrays = l;
                } else {
                    l = (ArrayList)arrays;
                }
                l.addAll (Arrays.asList (data));
            }
        }
        
        if (arrays == null) {
            // Return if there is nothing to merge
            return null;
        }
       
        return arrays instanceof PasteType[] ? (PasteType[])arrays : (PasteType[])((ArrayList)arrays).toArray (new PasteType[0]);
    }
    
    /** Delegates to delegate or does neutral behaviour (doing nothing, returning null)
     */
    public PasteType getDropType( Look.NodeSubstitute substitute, Transferable t, int action, int index) {
        Look[] delegate = delegateTo (GET_DROP_TYPE, substitute);
        if (delegate != null) {
            for (int i = 0; i < delegate.length; i++) {
                if (delegate[i] != null) {
                    PasteType b = delegate[i].getDropType (s (substitute, delegate[i], i), t, action, index);
                    if (b != null) {
                        return b;
                    }
                }
            }
        }
        return null;
    }
    
    /** Delegates to delegate or does neutral behaviour (doing nothing, returning null)
     */
    public Transferable clipboardCopy( Look.NodeSubstitute substitute ) throws IOException {
        Look[] delegate = delegateTo (CLIPBOARD_COPY, substitute);
        if (delegate != null) {
            for (int i = 0; i < delegate.length; i++) {
                if (delegate[i] != null) {
                    Transferable b = delegate[i].clipboardCopy (s (substitute, delegate[i], i));
                    if (b != null) {
                        return b;
                    }
                }
            }
        }
        return null;
    }
    
    /** Delegates to delegate or does neutral behaviour (doing nothing, returning null)
     */
    public Transferable clipboardCut( Look.NodeSubstitute substitute ) throws IOException {
        Look[] delegate = delegateTo (CLIPBOARD_CUT, substitute);
        if (delegate != null) {
            for (int i = 0; i < delegate.length; i++) {
                if (delegate[i] != null) {
                    Transferable b = delegate[i].clipboardCut (s (substitute, delegate[i], i));
                    if (b != null) {
                        return b;
                    }
                }
            }
        }
        return null;
    }
    
    /** Delegates to delegate or does neutral behaviour (doing nothing, returning null)
     */
    public Transferable drag( Look.NodeSubstitute substitute ) throws IOException {
        Look[] delegate = delegateTo (DRAG, substitute);
        if (delegate != null) {
            for (int i = 0; i < delegate.length; i++) {
                if (delegate[i] != null) {
                    Transferable b = delegate[i].drag (s (substitute, delegate[i], i));
                    if (b != null) {
                        return b;
                    }
                }
            }
        }
        return null;
    }
        
    /** Delegates to delegate or does neutral behaviour (doing nothing, returning null)
     */
    public void destroy(Look.NodeSubstitute substitute) throws IOException {
        Look[] delegate = delegateTo (DESTROY, substitute);
        if (delegate != null) {
            for (int i = 0; i < delegate.length; i++) {
                if (delegate[i] != null) {
                    delegate[i].destroy (s (substitute, delegate[i], i));
                }
            }
        }
    }

    /** Method that tries to get the right substitute S from given substitute.
     */
    private Look.NodeSubstitute s (Look.NodeSubstitute subst, Look l, int index) {
        Object[] holder = (Object[])ProxyLook.super.getAttachedData(subst);
        synchronized (holder) {
            Object[] arr = (Object[])holder[0];
            if (index < arr.length) {
                Look.NodeSubstitute ns = (Look.NodeSubstitute)arr[index];
                if (ns != null && ns.getLook() == l ) {
                    // we already have seen/initialized this Look.
                    return ns;
                }
            } else {
                Object[] newSubst = new Object[index + 1];
                System.arraycopy(arr, 0, newSubst, 0, arr.length);
                holder[0] = arr = newSubst;
            }
            S s = new S (l, subst);
            arr[index] = s;
            return s;
        }
    }
    
    // Innerclasses ------------------------------------------------------------
    
    /** Our special substitute to filter events fired from the underlaying look
     * and also to store its special attached data.
     */
    final class S extends Look.NodeSubstitute {
        /** substitute we represent it will contain reference to us in getAttachedData */
        private Look.NodeSubstitute substitute;
        
        S (Look look, Look.NodeSubstitute substitute) {
            this.substitute = substitute;
            
            super.attachTo (look);
        }
        
        /** Returns the object represented by the node
         * @return Object represented by the node this interior belongs to.
         */
        public Object getRepresentedObject() {
            return delegateObject (substitute);
        }        
        
        /** Fires a (Bean) property change event (for
         * {@link org.openide.node.Node#PROP_PROPERTY_SETS}).
         * @param o the old set
         * @param n the new set
         */
        public void firePropertySetsChange(Node.PropertySet[] o, Node.PropertySet[] n) {
            Look[] delegate = delegateTo (GET_PROPERTY_SETS, this) ;
            if (doFire (delegate)) {
                substitute.firePropertySetsChange( o, n );
            }
        }
        
        /** Fires the Event notificationg about name change.
         */
        public void fireNameChange(String o, String n) {
            Look[] delegate = delegateTo (GET_NAME, this) ;
            if (doFire (delegate)) {
                substitute.fireNameChange( o, n );
            }
        }
        
        /** Fires the Event notificationg about display name change.
         */
        public void fireDisplayNameChange(String o, String n) {
            Look[] delegate = delegateTo (GET_DISPLAY_NAME, this) ;
            if (doFire (delegate)) {
                substitute.fireDisplayNameChange( o, n );
            }
        }
        
        /** Tells the node that the children have to be refreshed.
         */
        public void refreshChildren() {
            Look[] delegate = delegateTo (GET_CHILD_OBJECTS, this) ;
            if (doFire (delegate)) {
                substitute.refreshChildren( );
            }
        }
        
        /** Fire a change event for {@link org.openide.nodes.Node#PROP_OPENED_ICON} on
         * associated node.
         */
        public void fireOpenedIconChange() {
            Look[] delegate = delegateTo (GET_OPENED_ICON, this) ;
            if (doFire (delegate)) {
                substitute.fireOpenedIconChange();
            }
        }
        
        /** To all node listeners fire node destroyed notification.
         */
        public void fireNodeDestroyed() {
            Look[] delegate = delegateTo (DESTROY, this) ;
            if (doFire (delegate)) {
                substitute.fireNodeDestroyed();
            }
        }
        
        /** Fire a change event for {@link org.openide.nodes.Node#PROP_ICON} on
         * associated node.
         */
        public void fireIconChange() {
            Look[] delegate = delegateTo (GET_ICON, this) ;
            if (doFire (delegate)) {
                substitute.fireIconChange();
            }
        }
        
        /** Fires the Event notificationg about short description change.
         */
        public void fireShortDescriptionChange(String o, String n) {
            Look[] delegate = delegateTo (GET_SHORT_DESCRIPTION, this) ;
            if (doFire (delegate)) {
                substitute.fireShortDescriptionChange( o, n );
            }
        }
        
        /** Fire a property change event on the associated node.
         * @param name name of changed property (from {@link #getPropertySets})
         * @param o old value
         * @param n new value
         */
        public void firePropertyChange(String name, Object o, Object n) {
            Look[] delegate = delegateTo (GET_PROPERTY_SETS, this) ;
            if (doFire (delegate)) {
                substitute.firePropertyChange( name, o, n );
            }
        }
        
        /** Do fire. 
         */
        private boolean doFire (Look[] arr) {
            if (arr == null) return false;
            
            for (int i = 0; i < arr.length; i++) {
                if (arr[i] != null) return true;
            }
            return false;
        }
        
    } // end of S
    

}
