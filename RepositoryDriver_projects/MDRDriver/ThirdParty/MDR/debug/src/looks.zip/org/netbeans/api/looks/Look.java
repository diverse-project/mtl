/*
 *                 Sun Public License Notice
 *
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 *
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2000 Sun
 * Microsystems, Inc. All Rights Reserved.
 */

package org.netbeans.api.looks;

import java.awt.Image;
import java.awt.datatransfer.Transferable;
import java.io.IOException;

import javax.swing.Action;

import org.openide.nodes.*;
import org.openide.util.HelpCtx;
import org.openide.util.datatransfer.NewType;
import org.openide.util.datatransfer.PasteType;
import org.openide.util.Lookup;

import java.lang.ref.WeakReference;
import java.util.Enumeration;
import org.openide.util.enum.AlterEnumeration;
import org.openide.util.enum.FilterEnumeration;
import java.util.NoSuchElementException;

/** Base class for all looks. This class handles basic reading of properties
 * from XML description.
 * <P>
 * Notice the difference between the methods which take the parameter of
 * type NodeSubstitute and the methods which don't. The first methods are
 * those which implement the functionality of the look. The second are methods 
 * which represent properties of the Look itself.
 * <P>
 *
 * @author Petr Hrebejk
 */
public abstract class Look implements Node.Cookie, java.io.Serializable {
    /** Look that works with <link>Node</link>. If the represented object
     * is <code>Node</code> the look takes its name, actions, properties, etc.
     * Very useful for bridging to already written nodes.
     */
    public static final Look NODES = new NodeProxyLook ();
    
    /** Look that finds the correct look by the type of the 
     * represented object. It searches naming space of "Looks/Types/"
     * @see NamespaceLook
     */
    public static final Look DEFAULT = new TypesLook ();
    
    /** Look that presents an object as a JavaBean. Uses java.beans.Introspector
     * to get the properties and delegates to the object all other methods.
     */
    public static final Look BEANS = new BeanLook ();
    
    /** lock to synchronize access to substitute variable.
     */
    private static final String NLOCK = "NLock";
    
    /** reference to the NodeSubstitute link list. Lists all substitutes this
     * look is attached to.
     */
    private NLink substitutes;
    
    // Methods of look itself --------------------------------------------------

    /** Returns name of the look. This name should identify the look.
     * @return Name of the look.
     */
    public abstract String getName();
    
    /** The human presentable name of the look. 
     * @return human presentable name
     */
    public abstract String getDisplayName ();
    
    // General methods ---------------------------------------------------------
    
    /** 
     * Called on the current look when node is newly created or the look is
     * set on the Node. Overriding this 
     * method allows to register listners on represented objects and asociate
     * them with the node.
     * <p>
     * Implementors may not wait for any other threads at it may be potentially called
     * from LookNode's lock.
     * <P>
     * The look can return an instance of any object in order to store its 
     * own data with the substitute. The data can then be obtained by calling
     * <link>Look.NodeSubstitute.getAttachedData</link>. 
     * 
     * @param substitute The <CODE>Look.NodeSubstitute</CODE> of the which was created.
     * @return the object that contains data of the look associated with the
     *      substitute or <code>null</code> if no such data are needed
     */ 
    protected Object attachTo( Look.NodeSubstitute substitute ) {
        return createAttachedData(substitute);
    }

    /**
     * This method is called during the process of attaching a Look to a 
     * <link>NodeSubstitute</link>. Subclasses can override this method to attach
     * custom data to the NodeSubstitute instance so they can retrieve it
     * later.<BR>
     * @param substitute The <CODE>Look.NodeSubstitute</CODE> of the which was created.
     * @return the object that contains data of the look associated with the
     *      substitute or <code>null</code> if no such data are needed
     */
    protected Object createAttachedData(Look.NodeSubstitute subst) {
        return null;
    }
    
    /**
     * Retrieves the data, previously attached to the <link>NodeSubstitute</link>.
     * The method returns null, if this Look is no longer selected one for the 
     * <code>NodeSubstitute</code> or <link>createAttachedData</link> returned
     * null.
     * @see #createAttachedData
     * @param substitute The <CODE>Look.NodeSubstitute</CODE> of the node to operate on.
     * @return The instance previously returned from <link>createAttachedData</link>
     * or null if there was no data, or the Look is not selected on the <code>Node</code>
     */
    protected Object getAttachedData(Look.NodeSubstitute subst) {
        if (subst == null)
            return null;
        return subst.getAttachedData(this);
    }
    
    /** Creates lookup object with additional "cookies" for the LookNode using
     * the provided node substitute. The LookNode attaches calls this method just
     * once and attaches listener to the returned lookup so all changes in it
     * will result in PROP_COOKIE change in the LookNode.
     *
     *
     * @param substitute The <CODE>Look.NodeSubstitute</CODE> of the node to operate on.
     * @return the lookup to be used by the LookNode or null if no additional cookies are
     *      provided
     */
    public abstract Lookup createLookup (Look.NodeSubstitute substitute);
    
    /** A list of possible looks this look can be replaced with.
     * This list depends on the look itself and should contain looks 
     * a user might find meaningful to use instead of this one.
     *
     * @param substitute substitute to find modes for
     * @return the array of looks or null if the no switching is available
     */
    public abstract Look[] availableLooks ( Look.NodeSubstitute substitute );
    
    // Methods for STYLE -------------------------------------------------------
    
    /** Gets localized name of given Node. This name will be showed in the 
     * visual representation of the node. 
     * @param substitute The <CODE>Look.NodeSubstitute</CODE> of the node to operate on.
     * @return Localized name of the node. Implementation of {@link LookNode} 
     *         defaults this to the programmatic name of the node.
     */
    public abstract String getDisplayName( Look.NodeSubstitute substitute );
    
    /** Gets the progammatic name of given node. This name can be used for 
     * operations on node paths in the node hierarchy and thus shouldn't be
     * localized.
     * @param substitute The <CODE>Look.NodeSubstitute</CODE> of the node to operate on.
     * @return Programmatic name of the node. 
     */
    public abstract String getName( Look.NodeSubstitute substitute );
    
    /** This method is clalled when the user renames the node using inplace
     * editing in the view.
     * @param substitute The <CODE>Look.NodeSubstitute</CODE> of the renamed node.
     * @param newName The new name set by the user.
     */
    public abstract void setName( Look.NodeSubstitute substitute, String newName );
    
    /** Gets short description of given node. The short description is usually
     * visualized as a tooltip, but may have another forms as well.
     * @param substitute The <CODE>Look.NodeSubstitute</CODE> of the node to operate on.
     * @return A localized short description associated with the node. 
     *         Implementation of {@link LookNode} defaults this to display name 
     *         of the node.
     */
    public abstract String getShortDescription( Look.NodeSubstitute substitute );
    
    /** Find an icon for this node (in the closed state).
     * @param substitute The <CODE>Look.NodeSubstitute</CODE> of the node to operate on.
     * @param type Constant from {@link java.beans.BeanInfo}
     * @return Icon to use to represent the node in the closed state. 
     *         Implementation of {@link LookNode} provides default icon for nodes.
     */
    public abstract Image getIcon( Look.NodeSubstitute substitute, int type );
    
    /** Find an icon for this node (in the open state).
     * This icon is used when the node may have children and is expanded.
     * @param substitute The <CODE>Look.NodeSubstitute</CODE> of the node to operate on.
     * @param type Constant from {@link java.beans.BeanInfo}
     * @return Icon to use to represent the node in the open state. 
     *        Implementation of {@link LookNode} defaults this to the closed
     *        state icon.
     */
    public abstract Image getOpenedIcon( Look.NodeSubstitute substitute, int type );
    
    /** Get context help associated with this node.
     * @param substitute The <CODE>Look.NodeSubstitute</CODE> of the node to operate on.
     * @return The context help object (could be <code>null</code> or 
     *         {@link HelpCtx#DEFAULT_HELP}) 
     */
    public abstract HelpCtx getHelpCtx( Look.NodeSubstitute substitute );
    
    // Methods for CHILDREN ----------------------------------------------------
    
    /** Gets objects which are children of object represented by the node in the
     * hierarchy represented by this Look.
     * @param substitute The <CODE>Look.NodeSubstitute</CODE> of the node to operate on.
     * @return Array of objects which should be represend as node children of 
     *         the node, can return <code>null</code> that is equivalant to empty array
     */
    public abstract Object[] getChildObjects( Look.NodeSubstitute substitute );
    
    // Methods for ACTIONS & NEW TYPES -----------------------------------------
    
    /** Get the new types that can be created in given node.
     * For example, a node representing a Java package will permit classes to 
     * be added.
     * @param substitute The <CODE>Look.NodeSubstitute</CODE> of the node to operate on.
     * @return Array of new type operations that are allowed,
     *     can return <code>null</code> that is equivalant to empty array
     */
    public abstract NewType[] getNewTypes( Look.NodeSubstitute substitute );
    
    /** Get the set of actions associated with the node.
     * This may be used e.g. in constructing a {@link #getContextMenu context menu}.
     * <P>
     * If the look returns null, the implementation {@ling LookNode} returns 
     * the actions in {@link NodeOp#getDefaultActions} obtained by the super call.
     * @param substitute The <CODE>Look.NodeSubstitute</CODE> of the node to operate on.
     * @return Array of the Actions applicable to the node or <CODE>null</CODE>
     *         if actions in {@link NodeOp#getDefaultActions} should be used.
     */
    public abstract Action[] getActions( Look.NodeSubstitute substitute );
    
    /** Get a special set of actions for situations when this node is displayed 
     * as a context.
     * @see org.openide.nodes.Node#getContextActions For more detailed description.
     * @param substitute The <CODE>Look.NodeSubstitute</CODE> of the The node to operate on.
     * @return Actions for a context. In the LookNode implementation, 
     *        same as {@link #getActions}.
     * 
     */
    public abstract Action[] getContextActions( Look.NodeSubstitute substitute );
    
    /** Get the default action for this node.
     * This action can but need not be one from the list returned
     * from {@link #getActions}. If so, the popup menu returned from 
     * {@link #getContextMenu} is encouraged to highlight the action.
     * @param substitute The <CODE>Look.NodeSubstitute</CODE> of the node to operate on.
     * @return Default action, or <code>null</code> if there should be none.
     */
    public abstract Action getDefaultAction( Look.NodeSubstitute substitute );
    
    // Methods for PROPERTIES AND CUSTOMIZER -----------------------------------
    
    /** Get the list of property sets for given node. E.g. typically there 
     * may be one for normal Bean properties, one for expert
     * properties, and one for hidden properties.
     * @param substitute The <CODE>Look.NodeSubstitute</CODE> of the The node to operate on.
     * @return Property sets for the node, can return <code>null</code> that is equivalant to empty array
     */
    public abstract Node.PropertySet[] getPropertySets( Look.NodeSubstitute substitute );
    
    /** Is the customizer for represented object available? If so, the method
     * getCustomizer should return non-null value.
     *
     * @param substitute The <CODE>Look.NodeSubstitute</CODE> of the node to operate on.
     * @return true if the customizer is available, false otherwise
     */
    public abstract boolean hasCustomizer( Look.NodeSubstitute substitute );
    
    /** Get the customizer for represented object if available.
     * @param substitute The <CODE>Look.NodeSubstitute</CODE> of the node to operate on.
     * @return The component, or <CODE>null</CODE> if there is no customizer. 
     */
    public abstract java.awt.Component getCustomizer( Look.NodeSubstitute substitute );
    
    // public boolean hasCustomizer (); Not necesary
    
    // Methods for CLIPBOARD OPERATIONS ----------------------------------------
    
    /** Test whether this node can be renamed.
     * If true, {@link #setName} will be called when the user changes the name
     * of the node.
     * @param substitute The <CODE>Look.NodeSubstitute</CODE> of the node to operate on.
     * @return <code>true</code> if the node can be renamed.
     */
    public abstract boolean canRename( Look.NodeSubstitute substitute );
    
    /** Test whether this node can be deleted.
     * @param substitute The <CODE>Look.NodeSubstitute</CODE> of the node to operate on.
     * @return <CODE>True</CODE> if can be deleted.
     */
    public abstract boolean canDestroy( Look.NodeSubstitute substitute );
    
    /** Test whether this node permits copying.
     * @param substitute The <CODE>Look.NodeSubstitute</CODE> of the node to operate on.
     * @return <code>True</code> if so.
     */
    public abstract boolean canCopy( Look.NodeSubstitute substitute );
    
    /** Test whether this node permits cutting.
     * @param substitute The <CODE>Look.NodeSubstitute</CODE> of the node to operate on.
     * @return <code>True</code> if so.
     */
    public abstract boolean canCut( Look.NodeSubstitute substitute );
    
    /** Determine which paste operations are allowed when a given 
     * transferable is in the clipboard. For example, a node representing a 
     * Java package will permit classes to be pasted into it.
     * @param substitute The <CODE>Look.NodeSubstitute</CODE> of the node to operate on.
     * @param t The transferable in the clipboard.
     * @return Array of operations that are allowed, can return <code>null</code> that is equivalant to empty array
     */
    public abstract PasteType[] getPasteTypes( Look.NodeSubstitute substitute, Transferable t);
    
    /** Determine if there is a paste operation that can be performed
     * on provided transferable. Used by drag'n'drop code to check
     * whether the drop is possible.
     * @param substitute The <CODE>Look.NodeSubstitute</CODE> of the node to operate on.
     * @param t The transferable.
     * @param action The drag'n'drop action to do DnDConstants.ACTION_MOVE, 
     *        ACTION_COPY, ACTION_LINK.
     * @param index Index between children the drop occured at or -1 if not specified.
     * @return <CODE>Null</CODE> if the transferable cannot be accepted or the paste type
     *         to execute when the drop occures.
     */
    public abstract PasteType getDropType( Look.NodeSubstitute substitute, Transferable t, int action, int index);
    
    /** Called when a node is to be copied to the clipboard.
     * @param substitute The <CODE>Look.NodeSubstitute</CODE> of the node Copy was invoked on.
     * @return The transferable object representing the content of the clipboard.
     * @throws IOException When the copy cannot be performed.
     */
    public abstract Transferable clipboardCopy( Look.NodeSubstitute substitute ) throws IOException;
    
    /** Called when the node is to be cut to the clipboard.
     * @param substitute The <CODE>Look.NodeSubstitute</CODE> of the node to be cutted.
     * @return The transferable object representing the content of the clipboard.
     * @throws IOException When the copy cannot be performed.
     */
    public abstract Transferable clipboardCut( Look.NodeSubstitute substitute ) throws IOException;
    
    /** Called when a drag is started with this node.
     * The node can attach a transfer listener to ExTransferable and
     * will be then notified about progress of the drag (accept/reject).
     * @param substitute The <CODE>Look.NodeSubstitute</CODE> of the node which was dragged.
     * @return Transferable to represent this node during a drag.
     * @throws IOException If a drag cannot be started.
     */
    public abstract Transferable drag( Look.NodeSubstitute substitute ) throws IOException;
    
    /** Called when node was destroyed.
     * @param substitute Look.NodeSubstitute of the destroyed ndoe.
     */
    public abstract void destroy( Look.NodeSubstitute substitute ) throws IOException;
    
    /** List of all NodeSubstitutes that use this look. Is useful when the look
     * changes some of its properties and needs to update all substitutes.
     *
     * @return enumeration of NodeSubstitute
     */
    protected final Enumeration nodeSubstitutes () {
        Enumeration en = new Enumeration () {
            private NLink current = substitutes;
            
            public boolean hasMoreElements () {
                return current != null;
            }
            
            public Object nextElement () {
                synchronized (NLOCK) {
                    if (current == null) {
                        throw new NoSuchElementException ();
                    }
                    
                    Object o = current;
                    current = current.next;
                    return o;
                }
            }
        };
        
        AlterEnumeration alt = new AlterEnumeration (en) {
            private NLink previous;
            
            public Object alter (Object o) {
                NLink n = (NLink)o;
                if (n == null) {
                    return null;
                }

                synchronized (NLOCK) {
                    NodeSubstitute subst = (NodeSubstitute)n.get ();
                    if (subst == null || subst.getLook () != Look.this) {
                        // need to exclude this object from the list
                
                        if (previous == null) {
                            // we need to change looks first substitute
                            Look.this.substitutes = n.next;
                        } else {
                            // need to skip this one from the previous 
                            previous.next = n.next;
                        }
                        
                        // anyway we will not accept the object
                        return null;
                    }
                    
                    return subst;
                }
            }
        };
        
        // exclude nulls
        return new FilterEnumeration (alt);
    }
    
    
    // Innerclasses ------------------------------------------------------------
    
    /** Class passed to the Look methods as parameter. Each LookNode contains 
     * exactly one instance of this class. Metods of the class allow access
     * to the properties and methods od the node needed for the Look.
     * @version 0.2
     */
    public static abstract class NodeSubstitute {
        /** the look this substitute is attached to or null */
        private Look look;
        /** data of the look attached to this substitute */
        private Object data;
        
        /** Attaches the substitute to a provided look. Does nothing if
         * the previously attached look is the same as the provided one.
         * If it is different, the substitute is detached from a look and
         * attached to the new one.
         *
         * <P>
         * Method attachTo is called on the look to let it know about this
         * substitute and to let it store additional data <link>getAttachedData</link>
         * with this NodeSubstitute.
         *
         * @param look look to attach to or null if we should detach
         */
        protected final void attachTo (Look look) {
            synchronized (NLOCK) {
                if (look == this.look) {
                    // ok no change
                    return;
                }

                this.look = look;
                if (look == null) {
                    // clear all values
                    data = null;
                    return;
                }
                
                
                NLink l = look.substitutes;
                look.substitutes = new NLink (this, l);

                this.data = look.attachTo (this);
            }
        }
        
        /** Access to the look this substitute is attached to.
         * @return the look we are attached to or null if not attached at all
         */
        public final Look getLook () {
            return look;
        }
        
        
        /** Fire a property change event on the associated node.
         * @param name name of changed property (from {@link #getPropertySets})
         * @param o old value
         * @param n new value
         */
        abstract public void firePropertyChange( String name, Object o, Object n );

        /** Fires the Event notificationg about name change.
         */
        abstract public void fireNameChange( String o, String n ); 
        
        /** Fires the Event notificationg about display name change.
         */
        abstract public void fireDisplayNameChange( String o, String n );
        
        /** Fires the Event notificationg about short description change.
         */
        abstract public void fireShortDescriptionChange(String o, String n); 

        /** Fire a change event for {@link org.openide.nodes.Node#PROP_ICON} on
         * associated node.
         */
        abstract public void fireIconChange();

        /** Fire a change event for {@link org.openide.nodes.Node#PROP_OPENED_ICON} on
         * associated node.
         */
        abstract public void fireOpenedIconChange(); 

        /** Fires a (Bean) property change event (for 
         * {@link org.openide.node.Node#PROP_PROPERTY_SETS}).
         * @param o the old set
         * @param n the new set
         */
        abstract public void firePropertySetsChange( Node.PropertySet[] o, Node.PropertySet[] n );
       
        /** To all node listeners fire node destroyed notification.
         */
        abstract public void fireNodeDestroyed();

        /** Tells the node that the children have to be refreshed.
         */
        abstract public void refreshChildren(); 
        
        
        //
        // Informations for the Look
        //
        
        /** Returns the object represented by the node
         * @return Object represented by the node this interior belongs to.
         */
        public abstract Object getRepresentedObject(); 
        
        /** Returns the data associated with the substitute by the Look
         * Made package-private from version 0.2. Use <link>Look.getAttachedData</link>
         * instead.
         * @see Look.createAttachedData
         * @return the object provided by <code>Look.createAttachedData</code>
         */
        final Object getAttachedData(Look look) {
            synchronized (NLOCK) {
                if (getLook() != look)
                    return null;
            }
            return data;
        }
    } // end of NodeSubstitute

    /** NodeSubstitute linked list with weak references.
     */
    private static final class NLink extends WeakReference {
        /** link to next NLink or null */
        public NLink next;
        
        public NLink (NodeSubstitute substitute, NLink next) {
            super (substitute);
            this.next = next;
        }
    } // end of NLink
}
