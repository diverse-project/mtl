/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2000 Sun
 * Microsystems, Inc. All Rights Reserved.
 */

package org.netbeans.api.looks;

import java.beans.*;
import java.awt.Image;
import java.awt.datatransfer.Transferable;
import java.io.IOException;
import java.util.Map;
import javax.swing.Action;

import org.openide.nodes.*;

import org.openide.util.HelpCtx;
import org.openide.util.Utilities;
import org.openide.util.actions.SystemAction;
import org.openide.util.datatransfer.NewType;
import org.openide.util.datatransfer.PasteType;
import org.openide.util.Lookup;
import org.openide.util.LookupEvent;
import org.openide.util.LookupListener;
import org.openide.util.Mutex;
import org.openide.util.MutexException;
import java.util.HashMap;
import java.util.Iterator;

import org.netbeans.spi.looks.ProxyLook;

/** 
 * Node that represents an object using Looks.
 *
 * @author Petr Hrebejk
 */
public final class LookNode extends Node implements Node.Cookie {
    /** it is our private lock changes of delegates for given nodes */
    private final Mutex MUTEX = new Mutex ();
    
    /** Use this constant for returning no Actions. */
    private static final SystemAction[] NO_SYSTEM_ACTIONS = {};
    
    /** Use this constant for returning empty NewTypes. */
    private static final NewType[] NO_NEW_TYPES = {};
    
    /** Use this constant for returning empty PasteTypes. */
    private static final PasteType[] NO_PASTE_TYPES = {};
    
    /** Use this constant for returning empty PropertySets. */
    private static final Node.PropertySet[] NO_PROPERTY_SETS = {};

    /** Name of the default icon 16x16 */
    private static final String DEFAULT_ICON_16_NAME = 
        "org/netbeans/modules/looks/resources/defaultNode.gif"; // NOI18N

    /** Name of the default icon 32x32 */
    private static final String DEFAULT_ICON_32_NAME = 
        "org/netbeans/modules/looks/resources/defaultNode32.gif"; //NOI18N
    
    /** Maximum of looks that is kept in memory. This should not be
     * infihite, but it also should be adjusted to the user experience -
     * how many selections are important to the user!?
     */
    private static final int MAX_MEMORY = 30;
    
    /** the base look associated with this node */
    private Look base;
    
    /** the actual look associated with this node */
    private Look look;
    
    /** Object represented (delegeted) by interior */
    private SubstituteImpl substitute;
    
    /** represented object */
    private Object representedObject;
    
    /** mapping from names of nodes to names of looks. Each node can have
     * such mapping - it will influence the persistence of selected objects
     *
     * Map with <String, String>
     */
    private Map map;
    
    /** Creates new LookNode with <link>Look.DEFAULT</link> as associated look.
     *
     * @param representedObject The object which the node will represent.
     */
    public LookNode( Object representedObject ) {
        this (representedObject, Look.DEFAULT);
    }
    
    /** Creates new LookNode.
     * @param representedObject The object which the node will represent.
     * @param look explicit look that will be set
     */
    public LookNode( Object representedObject, Look look) {
        this (representedObject, look, look);
    }
    
    /** Creates new LookNode.
     * @param representedObject The object which the node will represent.
     * @param base the base look to use
     * @param look explicit look that will be set 
     */
    /*public*/ LookNode (Object representedObject, Look base, Look look) {
        super (new LookChildren ());
        
        this.base = base;
        this.look = look;
        
        this.representedObject = representedObject;

        // Create the interior
        substitute = new SubstituteImpl(this, look);
    }

    
    // Additional methods for LookNode -----------------------------------------
       
    /** Used to get Substitute of this LookNode
     * @return NodeSubstitute
     */
    final SubstituteImpl getSubstitute(){
        return (SubstituteImpl) MUTEX.readAccess (new Mutex.Action () {
            public Object run () {
                return substitute;
            }
        });
    }

    final Object[] getChildObjects() {
        return (Object []) MUTEX.readAccess (new Operation (ProxyLook.GET_CHILD_OBJECTS));
    }
    
    /** Returns represented object which this LookNode represents.
     * @return The object represented by this node.
     */
    public Object getRepresentedObject() {
        return representedObject;
    }
    
    /** Sets the actual look for this node. After changing the Look several property
     * changes are fired:
     * <CODE>PROP_COOKIE, PROP_NAME, PROP_NAME, PROP_DISPLAY_NAME, PROP_ICON,
     * PROP_OPENED_ICON</CODE> and children are refresehed.
     * @look New look of the node.
     */
    public void setLook( final Look look ) {        
        String name = look.getName ();
        
        MUTEX.writeAccess (new Runnable () {
            public void run () {
                LookNode.this.look = look; // new current look

                substitute.clean (); // not used anymore
                SubstituteImpl newsubst = new SubstituteImpl (LookNode.this, look);

                substitute = newsubst;

                // commented out as hotfix of #24424
                //recordLook (this, base, name);
            }
        });
        // fire possible change notifications
        
        fireCookieChange();
        refreshChildren(true);
        fireNameChange( null, null );
        fireDisplayNameChange( null, null );
        fireIconChange();
        fireOpenedIconChange();
    }

    /** Refreshes children on the node */
    void refreshChildren(boolean brutal) {
        ((LookChildren)getChildren()).refreshChildren(brutal);
    }
    
    // methods to track the state of the tree
    
    /** Stores the name of the selected look.
     * @param node node to store the name for
     * @param nameLook look that should be used to create node's names
     * @param look the name of the look
     */
    private static void recordLook (LookNode node, Look nameLook, String look) {
        StringBuffer buf = new StringBuffer (512);
        
        for (;;) {
            Node parent = node.getParentNode();
            if (parent == null) break;
            
            parent = (LookNode)parent.getCookie (LookNode.class);
            if (parent == null) break;
            
            node = (LookNode)parent;
            buf.insert (0, nameLook.getName (node.getSubstitute ()));
        }
        
        synchronized (node) {
            if (node.map == null) {
                node.map = new HashMap ();
            }
            
            if (node.map.size () > MAX_MEMORY) {

                int rand = (int)(Math.random() * MAX_MEMORY);
                
                Iterator it = node.map.entrySet ().iterator();
                while (rand-- > 0) {
                    it.next ();
                }
                it.remove();
            }
            
            node.map.put (buf.toString ().intern(), look);
        }
    }
    
    
    /** Finds proposed look in storage (if any) for this node.
     * @return name of suggested look for our current state or null
     */
    Look findLookForChild (LookNode child) {
        String name = child.getName ();
        LookNode node = this;
        
        StringBuffer buf = new StringBuffer (512);
        buf.append (name);
        
        for (;;) {
            if (node == null) {
                return null;
            }
            
            if (node.map != null) {
                name = (String)node.map.get (buf.toString ());
                
                if (name != null) {
                    // found a name now find the look
                    return child.lookByName (child.getBaseLook(), name);
                }
                
            }
            
            buf.insert (0, node.getName ());
            
            
            Node p = node.getParentNode ();
            if (p == null) {
                break;
            }
            
            node = (LookNode)p.getCookie(LookNode.class);
            if (node == null) {
                return null;
            }
        }
        
        return null;
    }
    
    /** Finds a look by name.
     * @param look the look to search in
     * @param name name to find
     * @return the look or null
     */
    private final Look lookByName (Look base, String name) {
        if (name.equals (base.getName ())) {
            return base;
        }
        
        Look[] arr = base.availableLooks (getSubstitute ());
        for (int i = 0; i < arr.length; i++) {
            base = lookByName (arr[i], name);
            if (base != null) {
                return base;
            }
        }
        return null;
    }
        
    // General methods ---------------------------------------------------------
    
    /** 
     * Gets the actual look set on this node. 
     * @return Look set on this Node
     * 
     */
    public Look getLook() {
        return look;
    }
    
    /** Getter for the base look.
     */
    final Look getBaseLook () {
        return base;
    }

    /** Gets Cookie of given type. The set of Cookies is determined by the
     * Look. Look of the node can allways be asked using <CODE>getCookie( 
     * Look.class )</CODE> and the LookNode self can be asked by 
     * <CODE>getCookie( LookNode.class )</CODE>.
     * @param type the representation class of the cookie
     * @return a cookie assignable to that class, or <code>null</code> 
     * the Look does not provide such cookie.
     */
    public Node.Cookie getCookie (Class type) {
        if ( type == Look.class ) {
            // Look is available in cookies
            return getLook();
        } else if ( type == LookNode.class ) {
            return this;
        } else {            
            // Ask the Looks for additional cookies
            Object c = getSubstitute ().getCookie (type);

            return c instanceof Node.Cookie ? (Node.Cookie)c : null;
        }
    }

    /** Determines Handle by querying the Look.
     * @return the handle, or <code>null</code> if this node is not persistable
     */
    public Node.Handle getHandle() {
        if (map != null) {
            return new H (map, getRepresentedObject ());
        } else {
            return DefaultHandle.createHandle (this);
        }
    }
    
    /** 
     * Returns a node representing the same object as the original node. Looks
     * passed in constructor and in setLook method are copied as well.
     *
     * @return LookNode representing the same object.
     */
    public Node cloneNode () {
        return new LookNode( getRepresentedObject(), base, look); 
    }

    
    // Methods for STYLE -------------------------------------------------------
    
    /** Determines displayName by querying the Look.
     * @return DisplayName provided by the Look or result 
     * of {@link #getName()}.
     */
    public String getDisplayName() {
        return (String) MUTEX.readAccess (new Mutex.Action () {
            public Object run () {
                String  displayName = getLook().getDisplayName( substitute );

                if ( displayName == null ) {
                    return getName();
                } else {
                    return displayName;
                }
            }
        });
    }
    
    /** Empty method, setting <CODE>displayName</CODE> on the 
     * <CODE>LookNode</CODE> has no efect. The <CODE>displayName</CODE> should
     * be determined by associated <CODE>Look</CODE>.
     * @param name Parameter is ignored. 
     */
    public void setDisplayName( String name ) {
    }
    
    /** Determines name by querying the Look.
     * @return Name provided by the Look or <CODE>null</CODE>.
     */
    public String getName() {
        return (String) MUTEX.readAccess (new Operation (ProxyLook.GET_NAME));
    }
    
    /** Invoking this method on LookNode invokes method {@link Look#setName( 
     * Look.NodeSubstitute, String )}. Look is responsible for handling the call.
     */
    public void setName( String s ) {
        MUTEX.readAccess (new Operation (ProxyLook.SET_NAME, s));
    }
    
    /** Empty method, setting <CODE>shortDescription</CODE> on the 
     * <CODE>LookNode</CODE> has no efect. The <CODE>shortDescription</CODE> 
     * should be determined by associated <CODE>Look</CODE>.
     * @param shortDescription Parameter is ignored.
     */
    public void setShortDescription( String shortDescription ) {
    }
    
    /** Determines shortDescription by querying the Look.
     * @return Name provided by the Look or result of {@link getDisplayName()}.
     */
    public String getShortDescription() {
        return (String) MUTEX.readAccess (new Mutex.Action () {
            public Object run () {
                String shortDescription = getLook().getShortDescription( substitute );

                if ( shortDescription == null ) {
                    return getDisplayName();
                } else {
                    return shortDescription;
                }
            }
        });
    }
    
    /** Determines icon for closed state by querying the Look.
     * @return Icon provided by the Look 
     */
    public Image getIcon( int type ) {
        Image icon = (Image) MUTEX.readAccess (new Operation (ProxyLook.GET_ICON, new Integer (type)));
        
        if ( icon == null ) {
            if ( type == BeanInfo.ICON_COLOR_32x32 || type == BeanInfo.ICON_MONO_32x32 ) {
                return Utilities.loadImage( DEFAULT_ICON_32_NAME );
            }
            return Utilities.loadImage( DEFAULT_ICON_16_NAME );
        }
        else {
            return icon;
        }
    }
    
    /** Determines icon for opened state by querying the Look.
     * @return Icon provided by the Look or the result of
     * {@link getIcon()}.
     */
    public Image getOpenedIcon( final int type ) {
        return (Image) MUTEX.readAccess (new Mutex.Action () {
            public Object run () {
                Image icon = getLook().getOpenedIcon( substitute, type );

                if ( icon == null ) {
                    return getIcon( type );
                } else {
                    return icon;
                }
            }
        });
    }
    
    /** Determines HelpCtx for opened state by querying the Look.
     * @return HelpCtx provided by the Look.
     */
    public HelpCtx getHelpCtx () {
        return (HelpCtx) MUTEX.readAccess (new Operation (ProxyLook.GET_HELP_CTX));
    }
    
    // Methods for ACTIONS & NEW TYPES -----------------------------------------
    
    /** Determines NewTypes for opened state by querying the Look.
     * @return NewTypes provided by the Look.
     */
    public NewType[] getNewTypes() {
        NewType arr [] = (NewType []) MUTEX.readAccess (new Operation (ProxyLook.GET_NEW_TYPES));
        return arr == null ? NO_NEW_TYPES : arr;
    }
    
    public SystemAction[] getActions() {
        return toSA (getCommands ());
    }
    
    /** Implementation of the getActions command with the expected signature
     * of a method that will be used in future
     *
     * @return the actions supported by this node
     */
    private Action[] getCommands () {
        Action[] systemActions;
        Action[] mergedActions;

        systemActions = (Action[]) MUTEX.readAccess (new Operation (ProxyLook.GET_ACTIONS));
        
        if (systemActions == null) {
            systemActions = super.getActions();
        }
        
        int actlen = systemActions.length;
        mergedActions = new Action[actlen + 2];
        System.arraycopy( systemActions, 0, mergedActions, 0, actlen );
        Action sla = LookProperties.getSetLookAction ();
        
        System.arraycopy( new Action[]{
         null,
         sla
        }, 0, mergedActions, actlen, 2 );
        
        return mergedActions;

    }
    
    
    public SystemAction [] getContextActions() {
        Action[] arr = (Action[]) MUTEX.readAccess (new Operation (ProxyLook.GET_CONTEXT_ACTIONS));
        return arr != null ? toSA (arr) : NO_SYSTEM_ACTIONS;
    }
    
    public SystemAction getDefaultAction() {
        Action a = (Action) MUTEX.readAccess (new Operation (ProxyLook.GET_DEFAULT_ACTION));
        return a instanceof SystemAction ? (SystemAction)a : null;
    }
    
    /** A convertor that takes array of Actions and return array of SystemActions
     * @param arr array of Action
     * @return array of SystemActions
     */
    private static SystemAction[] toSA (Action[] arr) {
        SystemAction[] sa = new SystemAction[arr.length];
        
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] instanceof SystemAction) {
                sa[i] = (SystemAction)arr[i];
            }
        }
        
        return sa;
    }
                
                
    
    // Methods for PROPERTIES AND CUSTOMIZER -----------------------------------
    
    public Node.PropertySet[] getPropertySets() {
        Node.PropertySet[] sets = (Node.PropertySet[]) MUTEX.readAccess (new Operation (ProxyLook.GET_PROPERTY_SETS));
        if (sets == null) {
            sets = NO_PROPERTY_SETS;
        }
        
        Node.PropertySet[] all = new Node.PropertySet[ sets.length + 1 ];
        System.arraycopy( sets, 0, all, 0, sets.length );
         
        Sheet.Set set = LookProperties.getLookPropertySet( this );
		/*
        set.setName( LookProperties.LOOK_SHEET_SET_NAME );
        set.setDisplayName( LookProperties.LOOK_SHEET_SET_NAME );
        set.put( new LookProperties.LookProperty( this ) ); 
        */

        all[ all.length - 1] = set;
         
        return all;
    }
    
    public java.awt.Component getCustomizer() {
        return (java.awt.Component) MUTEX.readAccess (new Operation (ProxyLook.GET_CUSTOMIZER));
    }
    
    public boolean hasCustomizer () {
        return ((Boolean) MUTEX.readAccess (new Operation (ProxyLook.HAS_CUSTOMIZER))).booleanValue();
    }
    
    // Methods for CLIPBOARD OPERATIONS ----------------------------------------
     
    public boolean canRename() {
        return ((Boolean) MUTEX.readAccess (new Operation (ProxyLook.CAN_RENAME))).booleanValue();
    }
    
    public boolean canDestroy() {
        return ((Boolean) MUTEX.readAccess (new Operation (ProxyLook.CAN_DESTROY))).booleanValue();
    }
    
    public boolean canCopy() {
        return ((Boolean) MUTEX.readAccess (new Operation (ProxyLook.CAN_COPY))).booleanValue();
    }
    
    public boolean canCut() {
        return ((Boolean) MUTEX.readAccess (new Operation (ProxyLook.CAN_CUT))).booleanValue();
    }
    
    public PasteType[] getPasteTypes( Transferable t) {
        PasteType[] arr = (PasteType[]) MUTEX.readAccess (new Operation (ProxyLook.GET_PASTE_TYPES, t));
        return arr != null ? arr : NO_PASTE_TYPES;
    }
    
    public PasteType getDropType( Transferable t, int action, int index) {
        return (PasteType) MUTEX.readAccess (new Operation (
            ProxyLook.GET_DROP_TYPE, t, new Integer (action), new Integer (index)));
    }
    
    public Transferable clipboardCopy() throws IOException {
        try {
            return (Transferable) MUTEX.readAccess (new OperationException (ProxyLook.CLIPBOARD_COPY));
        } catch (MutexException e) {
            throw (IOException) e.getException ();
        }
    }
    
    public Transferable clipboardCut() throws IOException {
        try {
            return (Transferable) MUTEX.readAccess (new OperationException (ProxyLook.CLIPBOARD_CUT));
        } catch (MutexException e) {
            throw (IOException) e.getException ();
        }
    }
    
    public Transferable drag() throws IOException {
        try {
            return (Transferable) MUTEX.readAccess (new OperationException (ProxyLook.DRAG));
        } catch (MutexException e) {
            throw (IOException) e.getException ();
        }
    }
    
    public void destroy () throws IOException {
        try {
            MUTEX.readAccess (new OperationException (ProxyLook.DESTROY));
        } catch (MutexException e) {
            throw (IOException) e.getException ();
        }
        super.destroy();
    }

/*    
    boolean hasLookNodeParent() {
        Node parent = getParentNode();
        return parent != null && parent instanceof LookNode;
    }
*/    
    // Operation innerclass -----------------------------------------------------

    private final class Operation implements Mutex.Action {
        private long method = 0;
        private Object param1 = null;
        private Object param2 = null;
        private Object param3 = null;
        
        public Operation (long method) {
            this (method, null);
        }
        
        public Operation (long method, Object param1) {
            this (method, param1, null, null);
        }
        
        public Operation (long method, Object param1, Object param2, Object param3) {
            this.method = method;
            this.param1 = param1;
            this.param2 = param2;
            this.param3 = param3;
        }
        
        public Object run () {
            if (method == ProxyLook.GET_CHILD_OBJECTS) {
                return getLook ().getChildObjects (substitute);
            } else if (method == ProxyLook.GET_NAME) {
                return getLook ().getName (substitute);
            } else if (method == ProxyLook.SET_NAME) {
                getLook ().setName (substitute, (String) param1);
                return null;
            } else if (method == ProxyLook.GET_ICON) {
                return getLook ().getIcon (substitute, ((Integer) param1).intValue());
            } else if (method == ProxyLook.GET_HELP_CTX) {
                return getLook ().getHelpCtx (substitute);
            } else if (method == ProxyLook.GET_NEW_TYPES) {
                return getLook ().getNewTypes (substitute);
            } else if (method == ProxyLook.GET_ACTIONS) {
                return getLook ().getActions (substitute);
            } else if (method == ProxyLook.GET_CONTEXT_ACTIONS) {
                return getLook ().getContextActions (substitute);
            } else if (method == ProxyLook.GET_DEFAULT_ACTION) {
                return getLook ().getDefaultAction (substitute);
            } else if (method == ProxyLook.GET_PROPERTY_SETS) {
                return getLook ().getPropertySets (substitute);
            } else if (method == ProxyLook.GET_CUSTOMIZER) {
                return getLook ().getCustomizer (substitute);
            } else if (method == ProxyLook.HAS_CUSTOMIZER) {
                return getLook ().hasCustomizer (substitute) ? Boolean.TRUE : Boolean.FALSE;
            } else if (method == ProxyLook.CAN_RENAME) {
                return getLook ().canRename (substitute) ? Boolean.TRUE : Boolean.FALSE;
            } else if (method == ProxyLook.CAN_DESTROY) {
                return getLook ().canDestroy (substitute) ? Boolean.TRUE : Boolean.FALSE;
            } else if (method == ProxyLook.CAN_COPY) {
                return getLook ().canCopy (substitute) ? Boolean.TRUE : Boolean.FALSE;
            } else if (method == ProxyLook.CAN_CUT) {
                return getLook ().canCut (substitute) ? Boolean.TRUE : Boolean.FALSE;
            } else if (method == ProxyLook.GET_PASTE_TYPES) {
                return getLook ().getPasteTypes (substitute, (Transferable) param1);
            } else if (method == ProxyLook.GET_DROP_TYPE) {
                return getLook ().getDropType (substitute, (Transferable) param1, ((Integer) param2).intValue(), ((Integer) param2).intValue());
            }
            
            throw new IllegalStateException ("Invalid method id " + method); //NOI18N
        }
    }

    private final class OperationException implements Mutex.ExceptionAction {
        private long method = 0;
        
        public OperationException (long method) {
            this.method = method;
        }
        
        public Object run () throws IOException {
            if (method == ProxyLook.CLIPBOARD_COPY) {
                return getLook ().clipboardCopy (substitute);
            } else if (method == ProxyLook.CLIPBOARD_CUT) {
                return getLook ().clipboardCut (substitute);
            } else if (method == ProxyLook.DRAG) {
                return getLook ().drag (substitute);
            } else if (method == ProxyLook.DESTROY) {
                getLook ().destroy (substitute);
                return null;
            }
            
            throw new IllegalStateException ("Invalid method id " + method); //NOI18N
        }
    }
    
    // Interior innerclass -----------------------------------------------------
    
    /** Class passed to the Look methods as parameter. Each LookNode contains 
     * exactly one instance of this class. Metods of the class allow access
     * to the properties and methods od the node needed for the Look.
     */
    static final class SubstituteImpl extends Look.NodeSubstitute
    implements LookupListener {
        /** node we are attached to */
        private LookNode lookNode;
        /** lookup for this substitute */
        private Lookup lookup;
        /** all objects in the lookup, hold to prevent the result
         * to be garbage collected */
        private Lookup.Result result;
        /** selected id for this impl */
        private String id;
        
        /** The constructor of the interior is private to prevent other classes
         * than LookNode and Look from firing events on the node
         */
        SubstituteImpl(LookNode lookNode, Look look) {
            // initializes the lookNode
            this.lookNode = lookNode;
            
            // attaches to the look
            this.attachTo (look);
            
            // initializes the lookup
            this.lookup = look.createLookup (this);
            if (lookup != null) {
                // attach a listener
                result = lookup.lookup (
                    new Lookup.Template (Object.class)
                );
                result.addLookupListener (this);
            }
        }
        
        /** Called when this substitute is not needed anymore
         */
        public void clean () {
            lookNode = null;
        }
        
        /** Method to access the lookup.
         */
        public LookNode getLookNode () {
            return lookNode;
        }

        /** Queries the lookup.
         */
        Object getCookie (Class clazz) {
            if (lookup == null) {
                return null;
            } else {
                if (result == null) {
                    // attache a listener
                    result = lookup.lookup (new Lookup.Template (Object.class));
                    result.addLookupListener (this);
                }
                return lookup.lookup (clazz);
            }
        }
        
        
       
        
        /** Returns the object represented by the node
         * @return Object represented by the node this interior belongs to.
         */
        public Object getRepresentedObject(){
            LookNode l = lookNode;
            return l == null ? null : l.getRepresentedObject ();
        }
        
        /** Fire a property change event on the associated node.
         * @param name name of changed property (from {@link #getPropertySets})
         * @param o old value
         * @param n new value
         */
        public final void firePropertyChange( String name, Object o, Object n ) {
            LookNode l = lookNode;
            if (l != null) {
                l.firePropertyChange( name, o, n );
            }
        }

        /** Fires the Event notificationg about name change.
         */
        public final void fireNameChange( String o, String n ) {
            LookNode l = lookNode;
            if (l != null) {
                l.fireNameChange( o, n );
            }
        }

        /** Fires the Event notificationg about display name change.
         */
        public final void fireDisplayNameChange( String o, String n ) {
            LookNode l = lookNode;
            if (l != null) {
                l.fireDisplayNameChange( o, n );
            }
        }

        /** Fires the Event notificationg about short description change.
         */
        public final void fireShortDescriptionChange(String o, String n) {
            LookNode l = lookNode;
            if (l != null) {
                l.fireShortDescriptionChange( o, n );
            }
        }

        /** Fire a change event for {@link org.openide.nodes.Node#PROP_ICON} on
         * associated node.
         */
        public final void fireIconChange() {
            LookNode l = lookNode;
            if (l != null) {
                l.fireIconChange();
            }
        }

        /** Fire a change event for {@link org.openide.nodes.Node#PROP_OPENED_ICON} on
         * associated node.
         */
        public final void fireOpenedIconChange() {
            LookNode l = lookNode;
            if (l != null) {
                l.fireOpenedIconChange();
            }
        }

        /** Fires a (Bean) property change event (for 
         * {@link org.openide.node.Node#PROP_PROPERTY_SETS}).
         * @param o the old set
         * @param n the new set
         */
        public final void firePropertySetsChange( PropertySet[] o, PropertySet[] n ) {
            LookNode l = lookNode;
            if (l != null) {
                l.firePropertySetsChange( o, n );
            }
        }

        /** Fires a change event for {@link org.openode.nodes.Node#PROP_COOKIE}.
         * The old and new values are set to null.
         */
        public final void resultChanged (LookupEvent ev) {
            LookNode l = lookNode;
            if (l != null) {
                l.fireCookieChange();
            }
        }

        /** To all node listeners fire node destroyed notification.
         */
        public final void fireNodeDestroyed() {
            LookNode l = lookNode;
            if (l != null) {
                l.fireNodeDestroyed();
            }
        }

        /** Tells the node that the children have to be refreshed.
         */
        public final void refreshChildren() {
            LookNode l = lookNode;
            if (l != null) {
                l.refreshChildren(false);
            }
        }
        
        public final String getRepresentationId() {
            return id;
        }
        
    } // end of SubstituteImpl

    /** Handle that stores the map of names to look names and
     * creates look node after then.
     */
    private static final class H implements Node.Handle {
        static final long serialVersionUID = -435781367432893214L;
     
        private Map map;
        private Object repr;
        
        public H (Map map, Object repr) {
            this.map = map;
            this.repr = repr;
        }
        
        public Node getNode () throws IOException {
            LookNode node = new LookNode (repr);
            node.map = map;
            return node;
        }
    }
}
