/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2002 Sun
 * Microsystems, Inc. All Rights Reserved.
 */

package org.netbeans.modules.looks;

import java.beans.*;
import java.util.*;

import javax.naming.*;

import org.openide.util.datatransfer.*;
import org.openide.util.*;
import org.openide.nodes.*;

import org.netbeans.api.looks.Look;
import org.netbeans.spi.looks.ProxyLook;
import org.openide.ErrorManager;
import org.openide.filesystems.FileObject;
import org.openide.filesystems.Repository;

/** A composite look that composes itself from a content of JNDI namespace.
*
* @author Jaroslav Tulach
*/
public final class CompositeLook extends ProxyLook {
    /** attribute that identifies the context in FileObject */
    private static final String CONTEXT = "context"; // NOI18N
    /** a delay of periodic refresh of JNDI content */
    private static final long REFRESH = 15000;

    private static HashMap instances = new HashMap();
    
    /** name in the context */
    private String name;
    /** display name */
    private FileObject file;
    
    /** the current array of looks we delegate to */
    private Look[] arr;
    
    /** the last time we have refreshed the arr */
    private long last;
    
    private CompositeLook (String name, FileObject file) {
        this.name = name;
        this.file = file;
    }
    
    /** Getters for Look.NODES
     */
    public static Look lookNode () {
        return Look.NODES;
    }
    
    /** Getter for Look.BEANS
     */
    public static Look lookObject () {
        return Look.BEANS;
    }
    
    /** Creates new composite look from attributes of a file object.
     * @param fo file object
     */
    public static Look create (FileObject fo) throws java.io.IOException {
        // XXX: fo is from XML layer's filesystem, wee need to keep
        // FileObject from DefaultFileSystem, huh bug??
        FileObject f = Repository.getDefault ().getDefaultFileSystem ().findResource (fo.toString ());
        if (f != null) {
            fo = f;
        }
        
        Object name = fo.getAttribute (CONTEXT);
        if (name instanceof String) {
            Look look = (Look) instances.get(fo);
            if (look == null) {
                look = new CompositeLook ((String)name, fo);
                instances.put(fo, look);
            }
            return look;
        } else {
            throw new java.io.IOException ("Attribute " + CONTEXT + " is not string but: " + name); // NOI18N
        }
    }
        
        
    /** Identifier of the composite look.
     */
    public String getName () {
        return "Composite[" + name; // NOI18N
    }
    
    /** Display name. */
    public String getDisplayName () {
        try {
            return org.openide.loaders.DataObject.find (file).getNodeDelegate().getDisplayName ();
        } catch (org.openide.loaders.DataObjectNotFoundException ex) {
            return file.toString ();
        }
    }

    /** Delegates to all looks in the context.
     */
    protected Look[] delegateTo (long method, NodeSubstitute substitute) {
        if (arr == null || System.currentTimeMillis() - last > REFRESH) {
            arr = readContext (name);
        }
        
        return arr;
    }
    
    /** Reads list of looks from the context.
     */
    private static Look[] readContext (String name) {
        try {
            NamingEnumeration en = org.netbeans.api.naming.NamingSupport.createSFSInitialContext().listBindings (name);

            ArrayList l = new ArrayList ();
            while (en.hasMoreElements()) {
                Binding b = (Binding)en.nextElement();

                Object o = b.getObject ();
                if (o instanceof Look) {
                    l.add (o);
                }
            }

            return (Look[])l.toArray (new Look[0]);
        } catch (NamingException ev) {
            ErrorManager.getDefault ().notify (ev);
            return new Look[0];
        }
    }

    
}


