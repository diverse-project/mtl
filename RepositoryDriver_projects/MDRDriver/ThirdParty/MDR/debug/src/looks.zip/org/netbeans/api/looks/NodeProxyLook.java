/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is Forte for Java, Community Edition. The Initial
 * Developer of the Original Code is Sun Microsystems, Inc. Portions
 * Copyright 1997-2000 Sun Microsystems, Inc. All Rights Reserved.
 */

package org.netbeans.api.looks;

import java.util.Collection;
import java.awt.Image;
import java.awt.datatransfer.Transferable;
import java.io.IOException;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeEvent;
import java.util.ArrayList;

import javax.swing.Action;

import org.openide.nodes.*;
import org.openide.util.HelpCtx;
import org.openide.util.datatransfer.NewType;
import org.openide.util.datatransfer.PasteType;
import org.openide.util.Lookup;
import org.openide.util.WeakSet;
import org.openide.util.lookup.InstanceContent;
import org.openide.util.lookup.AbstractLookup;


import org.netbeans.spi.looks.*;
import org.openide.util.NbBundle;

/** 
 * Utility Class which allows to use LookNodes on existing Nodes. 
 * The class assumes that represented object is a Node. If there is 
 * Node.Interior representing other object than a ndoe the look delegates
 * to {DefaultLook#INSTANCE} i.e. returns neutral values.<BR>
 * Recomended usage of this class is to be used as delegatee.
 * <CODE>
 * public class MyNodeLook extends AcceptorLook {  
 *  
 *     public MyNodeLook() {
 *         super( new NodeProxyLook(), MyNode.Class );
 *         // set mask or do other initializations
 *     }
 * }
 * </CODE>
 * 
 * @author Petr Hrebejk
 */
final class NodeProxyLook extends Look {
    
    /** Creates new NodeProxySupport */
    public NodeProxyLook() {
    }

    // Methods of look itself --------------------------------------------------
    
    /** Specifies the node to which the Look delegates. The default 
     * implementation returns <CODE>substitute.getRepresentedObject()</CODE> 
     * casted to Node in case the represented object is a Node in other cases 
     * it returns null. If you override this method you can provide delegation
     * nodes for different types of object. (E.g. by calling 
     * dataObject.getNodeDelegate() ).
     */
    protected Node getNodeDelegate( Look.NodeSubstitute substitute ) {
        
        if ( substitute.getRepresentedObject() instanceof Node ) {
            return (Node)substitute.getRepresentedObject();
        }
        else {
            return null;
        }
    }
    
    // General methods ---------------------------------------------------------
    
    public Object attachTo (Look.NodeSubstitute substitute) {
        Node dn = getNodeDelegate( substitute );
        if ( dn == null ) {
            return null;
        } else {
            // Register listener to the node to pass events forward
            NodeEventTranslator nt = new NodeEventTranslator(substitute, dn);
            dn.addNodeListener (nt);
            dn.addPropertyChangeListener (new NodePropertyChangeTranslator (substitute, dn));
            return nt;
        }
    }
    
    public Lookup createLookup(Look.NodeSubstitute substitute) {
        // lookup has been created in attachTo method
        Object obj = getAttachedData (substitute);
        if (obj instanceof NodeEventTranslator) {
            NodeEventTranslator nt = (NodeEventTranslator)obj;
            return nt.lookup;
        }
        return null;
    }

    public Look[] availableLooks(Look.NodeSubstitute substitute) {
        Node dn = getNodeDelegate( substitute );
//        if (dn == null) {
            return null;
//        } else {
//            return dn.getHandle();
//        }
    }
    
    // Methods for STYLE -------------------------------------------------------
    
    public String getDisplayName( Look.NodeSubstitute substitute ) {
        Node dn = getNodeDelegate( substitute );
        if (dn == null) {
            return null;
        } else {
            return dn.getDisplayName();
        }
    }
    
    public String getName( Look.NodeSubstitute substitute ) {
        Node dn = getNodeDelegate( substitute );
        if (dn == null) {
            return null;
        } else {
            return dn.getName();
        }
    }
    
    public void setName( Look.NodeSubstitute substitute, String newName ) {
        Node dn = getNodeDelegate( substitute );
        if (dn != null) {
            dn.setName( newName );
        }
    }
    
    public String getShortDescription ( Look.NodeSubstitute substitute ) {
        Node dn = getNodeDelegate( substitute );
        if (dn == null) {
            return null;
        } else {
            return dn.getShortDescription();
        }
    }
    
    public Image getIcon( Look.NodeSubstitute substitute, int type ) {
        Node dn = getNodeDelegate( substitute );
        if (dn == null) {
            return null;
        } else {
            return dn.getIcon( type );
        }
    }
    
    public Image getOpenedIcon( Look.NodeSubstitute substitute, int type ) {
        Node dn = getNodeDelegate( substitute );
        if (dn == null) {
            return null;
        } else {
            return dn.getOpenedIcon( type );
        }
    }
    
    public HelpCtx getHelpCtx( Look.NodeSubstitute substitute ) {
        Node dn = getNodeDelegate( substitute );
        if (dn == null) {
            return null;
        } else {
            return dn.getHelpCtx();
        }
    }
    
    // Methods for CHILDREN ----------------------------------------------------
    
    public Object[] getChildObjects( Look.NodeSubstitute substitute ) {
        Node dn = getNodeDelegate( substitute );
        if (dn == null) {
            return null;
        } else {
            return dn.getChildren().getNodes();
        }
    }
        
    // Methods for ACTIONS & NEW TYPES -----------------------------------------
    
    public NewType[] getNewTypes( Look.NodeSubstitute substitute ) {
        Node dn = getNodeDelegate( substitute );
        if ( dn == null ) {
            return null;
        }
        else {
            return dn.getNewTypes();
        }
    }
    
    public Action[] getActions(Look.NodeSubstitute substitute) {
        Node dn = getNodeDelegate( substitute );
        if ( dn == null ) {
            return null;
        }
        else {
            return dn.getActions();
        }
    }
    
    public Action[] getContextActions(Look.NodeSubstitute substitute) {
        Node dn = getNodeDelegate( substitute );
        if ( dn == null ) {
            return null;
        }
        else {
            return dn.getContextActions();
        }
    }
    
    public Action getDefaultAction(Look.NodeSubstitute substitute) {
        Node dn = getNodeDelegate( substitute );
        if ( dn == null ) {
            return null;
        }
        else {
            return dn.getDefaultAction();
        }
    }
    
    // Methods for PROPERTIES AND CUSTOMIZER -----------------------------------
    
    public Node.PropertySet[] getPropertySets( Look.NodeSubstitute substitute ) {
        Node dn = getNodeDelegate( substitute );
        if ( dn == null ) {
            return null;
        }
        else {
            return dn.getPropertySets();
        }
    }
    
    public java.awt.Component getCustomizer( Look.NodeSubstitute substitute ) {        
        Node dn = getNodeDelegate( substitute );
        if ( dn == null || !dn.hasCustomizer() ) {
            return null;
        }
        else {
            return dn.getCustomizer();
        }
    }

    public boolean hasCustomizer( Look.NodeSubstitute substitute ) {        
        Node dn = getNodeDelegate( substitute );
        return dn != null && dn.hasCustomizer ();
    }
    
    // Methods for CLIPBOARD OPERATIONS ----------------------------------------
     
    public boolean canRename( Look.NodeSubstitute substitute ) {
        Node dn = getNodeDelegate( substitute );
        if ( dn == null ) {
            return false;
        }
        else {
            return dn.canRename();
        }
    }
    
    public boolean canDestroy( Look.NodeSubstitute substitute ) {
        Node dn = getNodeDelegate( substitute );
        if ( dn == null ) {
            return false;
        }
        else {
            return dn.canDestroy();
        }
    }
    
    public boolean canCopy( Look.NodeSubstitute substitute ) {
        Node dn = getNodeDelegate( substitute );
        if ( dn == null ) {
            return false;
        }
        else {
            return dn.canCopy();
        }
    }
    
    public boolean canCut( Look.NodeSubstitute substitute ) {
        Node dn = getNodeDelegate( substitute );
        if ( dn == null ) {
            return false;
        }
        else {
            return dn.canCut();
        }
    }
    
    public PasteType[] getPasteTypes( Look.NodeSubstitute substitute, Transferable t) {
        Node dn = getNodeDelegate( substitute );
        if ( dn == null ) {
            return null;
        }
        else {
            return dn.getPasteTypes( t );
        }
    }
    
    public PasteType getDropType( Look.NodeSubstitute substitute, Transferable t, int action, int index) {
        Node dn = getNodeDelegate( substitute );
        if ( dn == null ) {
            return null;
        }
        else {
            return dn.getDropType( t, action, index );
        }
    }
    
    public Transferable clipboardCopy( Look.NodeSubstitute substitute ) throws IOException {
        Node dn = getNodeDelegate( substitute );
        if ( dn == null ) {
            return null;
        }
        else {
            return dn.clipboardCopy();
        }
    }
    
    public Transferable clipboardCut( Look.NodeSubstitute substitute ) throws IOException {
        Node dn = getNodeDelegate( substitute );
        if ( dn == null ) {
            return null;
        }
        else {
            return dn.clipboardCut();
        }
    }
    
    public Transferable drag( Look.NodeSubstitute substitute ) throws IOException {
        Node dn = getNodeDelegate( substitute );
        if ( dn == null ) {
            return null;
        }
        else {
            return dn.drag();
        }
    }      
    
    public void destroy( Look.NodeSubstitute substitute ) throws IOException {
        Node dn = getNodeDelegate( substitute );
        if ( dn != null ) {
            dn.destroy();
        }
    }
    
    /** The human presentable name of the look.
     * @return human presentable name
     */
    public String getDisplayName() {
        return NbBundle.getMessage (NodeProxyLook.class, "LAB_NodeProxyLook"); // NOI18N
    }    
    
    /** Returns name of the look. This name should identify the look.
     * @return Name of the look.
     */
    public String getName() {
        return "Nodes"; // NOI18N
    }
    
    // Innerclasses ------------------------------------------------------------
    
    private static class NodeEventTranslator  
        extends EventTranslator implements NodeListener {
        
        private Node node;    
        private NodeLookup lookup;
            
        NodeEventTranslator( Look.NodeSubstitute substitute, Node node) {
            super( substitute );
            this.node = node;
            this.lookup = new NodeLookup (node);
        }
            
        public void unregister() {
            node.removeNodeListener( this );
        }
        
        
        public void childrenAdded( NodeMemberEvent e ) {
            getSubstitute().refreshChildren();
        }
         
        public void childrenRemoved( NodeMemberEvent e ) {
            getSubstitute().refreshChildren();
        }
        
        public void childrenReordered( NodeReorderEvent e ) {
            getSubstitute().refreshChildren();
        }
        
        public void nodeDestroyed( NodeEvent e ) {
            getSubstitute().fireNodeDestroyed();
        }
        
        public void propertyChange( PropertyChangeEvent e ) {
        
            if ( Node.PROP_NAME.equals( e.getPropertyName() ) ) {
                getSubstitute().fireNameChange( (String)e.getOldValue(), (String)e.getNewValue() );
            }
            else if ( Node.PROP_DISPLAY_NAME.equals( e.getPropertyName() ) ) {
                getSubstitute().fireDisplayNameChange( (String)e.getOldValue(), (String)e.getNewValue() );
            }
            else if ( Node.PROP_SHORT_DESCRIPTION.equals( e.getPropertyName() ) ) {
                getSubstitute().fireShortDescriptionChange( (String)e.getOldValue(), (String)e.getNewValue() );
            }
            else if ( Node.PROP_ICON.equals( e.getPropertyName() ) ) {
                getSubstitute().fireIconChange();
            }
            else if ( Node.PROP_OPENED_ICON.equals( e.getPropertyName() ) ) {
                getSubstitute().fireOpenedIconChange();
            }
            /*
            else if ( Node.PROP_PARENT_NODE.equals( e.getPropertyName() ) ) {
                property
            }
            */
            else if ( Node.PROP_PROPERTY_SETS.equals( e.getPropertyName() ) ) {
                getSubstitute().firePropertySetsChange( (Node.PropertySet[])e.getOldValue(), 
                                        (Node.PropertySet[])e.getNewValue() );
            }
            else if ( Node.PROP_COOKIE.equals( e.getPropertyName() ) ) {
                lookup.cookieChanged ();
            }
        }
    }
    
    private static class NodePropertyChangeTranslator
        extends EventTranslator implements PropertyChangeListener {
         
        private Node node;    
            
        NodePropertyChangeTranslator( Look.NodeSubstitute substitute, Node node) {
            super( substitute );
            this.node = node;
        }
            
        public void unregister() {
            node.removePropertyChangeListener( this );
        }    
            
        public void propertyChange( PropertyChangeEvent e ) {
            getSubstitute().firePropertyChange( e.getPropertyName(), e.getOldValue(), e.getNewValue() ); 
        }
    }

    /** A lookup to delegate to the node */
    static final class NodeLookup extends AbstractLookup {
        /** node template to query for all registered nodes */
        private static Template TEMPL_NODE = new Template (Node.class);

        /** instance content to add new objects into */
        private InstanceContent ic;
        /** Set of Classes that we have already queried <type>Class</type> */
        private WeakSet queriedCookieClasses = new WeakSet (37);

        /** current objects assigned to the lookup */
        private Node node;

        /** New flat lookup.
         * @param node for given node
         */
        public NodeLookup (Node node) {
            this (new InstanceContent (), node);
        }

        private NodeLookup (InstanceContent ic, Node node) {
            super (ic);

            this.ic = ic;
            this.node = node;
        }

        /** Notifies subclasses that a query is about to be processed.
         * @param template the template 
         */
        protected final void beforeLookup (Template template) {
            Class type = template.getType ();

            if (Node.class == type) {
                return;
            }

            if (Node.Cookie.class.isAssignableFrom (type)) {
                if (!queriedCookieClasses.contains (type)) {
                    queriedCookieClasses.add (type);
                    queryCookie (new Class[] { type }, null);
                }
            }
        }


        /** Performs query on content of cookies in the nodes.
         *
         * @param types the classes to query
         * @param res result to add cookies to
         */
        private final void queryCookie (Class[] types, Collection res) {
            for (int i = 0; i < types.length; i++) {
                Object obj = node.getCookie (types[i]);
                if (obj != null) {
                    if (res != null) {
                        res.add (obj);
                    } else {
                        ic.add (obj);
                    }
                }
            }
        }

        public void cookieChanged () {
            ArrayList a2 = new ArrayList ();
            a2.add (node);

            // if a change in cookie, requery
            Class[] types = (Class[])queriedCookieClasses.toArray (new Class[0]);

            if (types.length != 0) {
                // add all cookies
                queryCookie (types, a2);
            }

            ic.set (a2, null);
        }

    }
    
}
