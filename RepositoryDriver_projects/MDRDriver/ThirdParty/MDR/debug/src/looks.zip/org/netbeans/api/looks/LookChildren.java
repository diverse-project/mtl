/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2000 Sun
 * Microsystems, Inc. All Rights Reserved.
 */

package org.netbeans.api.looks;

import java.util.*;

import org.openide.nodes.*;

/** <B>WARNING</B> - This API is not finished and is subject to change<BR> 
 * Please don't use this API for other purposes than testing.
 * <P>
 * Temporary implementation of Children of a LookNode. The class contains
 * only code wich is necessary for testing looks and may be extended later.
 *
 * @author Petr Hrebejk
 */
final class LookChildren extends Children.Keys {
    /** Use this constant for returning empty KeySets. */
    private static final Object[] NO_KEYS = {};
    
    /** @param brutal needs clean */
    void refreshChildren( boolean brutal ) {            
        if (brutal) {
            setKeys (Collections.EMPTY_LIST);
        }
        
        final Object[] keys = getKeys();
        MUTEX.postWriteRequest(new Runnable() {
            public void run() {
                setKeys( keys );
            }
        });
    }
    
    protected void addNotify() {
        setKeys( getKeys() );
    }
    
    protected void removeNotify() {
        setKeys( Collections.EMPTY_LIST );
    }
    
    protected Node[] createNodes( Object key ) {
        if (key == null) return new Node[0];
        
        Node n = getNode ();
        if (! (n instanceof LookNode)) {
            Look l = (Look)n.getCookie (Look.class);
            
            if (l == null) {
                l = Look.DEFAULT;
            }
            
            return new Node[] { new LookNode (key, l) };
        }
        
        LookNode ln = (LookNode)n;
        LookNode node = new LookNode (key, ln.getBaseLook ());

        // is not there a better look?
        Look l = ln.findLookForChild (node);
        if (l != null && node.getLook () != l) {
            node.setLook (l);
        }
        
        return new Node[] { node };
    }
    
    
    // Private methods ---------------------------------------------------------
    
    private Object[] getKeys() {
        
        Object[] keys = ((LookNode)getNode ()).getChildObjects ();
        if ( keys == null ) {
            return NO_KEYS;
        }
        else {
            return keys;
        }
        
    }
        
}
