/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2000 Sun
 * Microsystems, Inc. All Rights Reserved.
 */

package org.netbeans.api.looks;

import java.util.*;
import java.beans.PropertyEditor;
import java.beans.PropertyEditorSupport;
import javax.swing.JMenuItem;
import javax.swing.JMenu;


import org.openide.nodes.*;
import org.openide.util.NbBundle;
import org.openide.util.actions.*;
import org.openide.awt.Actions;
import java.beans.PropertyChangeListener;
import java.lang.ref.Reference;
import java.awt.Component;
import org.openide.explorer.view.MenuView;
import org.openide.explorer.ExplorerPanel;
import org.openide.explorer.view.ChoiceView;
import java.lang.ref.WeakReference;
import java.lang.ref.SoftReference;
import org.openide.util.WeakListener;


/** <B>WARNING</B> - This API is not finished and is subject to change<BR> 
 * Please don't use this API for other purposes than testing.
 * <P> 
 * Utility class for creating a SheetSet for switching looks. 
 *
 * @author Petr Hrebejk
 */
class LookProperties extends Object {

    private static final ResourceBundle bundle = NbBundle.getBundle( LookProperties.class );

    public static final String LOOK_SHEET_SET_NAME = "Look"; // NOI18N
   
    /** Name of the default look. I.e. when the look on the node is null*/
    private static final String DEFAULT = bundle.getString( "CTL_Default" ); //NOI18N
    
    public static Sheet.Set getLookPropertySet( LookNode node ) {
        
        Sheet.Set set = new Sheet.Set();
        set.setName( LOOK_SHEET_SET_NAME ); // NOI18N
        set.setDisplayName( bundle.getString( "CTL_LookSheetSetName" ) ); //NOI18N
        set.put( new LookProperty( node ) ); 
        return set;
    }
    
    public static SystemAction getSetLookAction () {
        return SystemAction.get (SetLookAction.class);
    }
    
    // INNER CLASSES -----------------------------------------------------------
    
    /** The property for changing look
     */
    static class LookProperty extends PropertySupport.ReadWrite {
        
        private final LookNode lookNode;
        
        LookProperty( LookNode lookNode ) {
            super( bundle.getString( "CTL_LookProperty" ), // NOI18N
				   Look.class, 
                   bundle.getString( "CTL_LookProperty" ), // NOI18N
                   bundle.getString( "CTL_LookPropertyShortDescription" ) // NOI18N
                   ); 
            this.lookNode = lookNode;
        }
        
            
        public Object getValue() {            
            return lookNode.getLook ();
        }
            
        public void setValue( Object value ) {
            lookNode.setLook( (Look) value );
        }
            
        public PropertyEditor getPropertyEditor () {
            return new LookEditor( lookNode );
        }

    }
    
    /** Editor for choosing looks */
    static class LookEditor extends PropertyEditorSupport { 

        /** The node */
        LookNode lookNode = null;
        
        /** Current value */
        private Look look = null;

        /** Creates new editor */
        public LookEditor ( LookNode lookNode ) {
            this.lookNode = lookNode;
        }

        /**
        * @return The property value as a human editable string.
        * <p>   Returns null if the value can't be expressed as an editable string.
        * <p>   If a non-null value is returned, then the PropertyEditor should
        *       be prepared to parse that string back in setAsText().
        */
        public String getAsText () {
            if ( getValue() == null ) {
                return DEFAULT;
            }
            return ((Look)getValue()).getDisplayName ();
        }
        
        /**
        * Set the property value by parsing a given String.
        * @param text  The string to be parsed.
        */
        public void setAsText ( String string ) throws IllegalArgumentException {
            if ( string.equals( DEFAULT ) ) {
                setValue( null );
            }
            
            ArrayList list = new ArrayList ();
            collectLooks (lookNode.getSubstitute(), lookNode.getBaseLook (), list);
            Iterator it = list.iterator ();
            
            while (it.hasNext ()) {
                Look l = (Look)it.next ();
                
                if (l.getDisplayName ().equals (string)) {
                    setValue (l);
                    return;
                }
            }
            throw new IllegalArgumentException( "No such look - " + string ); // NOI18N
        }

        /**
        * @return A fragment of Java code representing an initializer for the
        * current value.
        */
        public String getJavaInitializationString () {
            return (getValue() == null) ? "" : look.getName(); // NOI18N
        }

        /**
        * @return The tag values for this property.
        */
        public String[] getTags () {
            ArrayList list = new ArrayList ();
            collectLooks (lookNode.getSubstitute (), lookNode.getBaseLook (), list);
            
            String names[] = new String [list.size ()];
            for ( int i = 0; i < names.length ; i++ ) {
                Look l = (Look)list.get (i);
                
                names[i] = l.getDisplayName ();
            }            
            return names;
        }

        static void collectLooks (Look.NodeSubstitute subst, Look look, ArrayList list) {
            if (list.contains (look)) return;
            
            list.add (look);
            
            Look[] arr = look.availableLooks (subst);
            if (arr == null) return;
            
            for (int i = 0; i < arr.length; i++) {
                list.add (arr[i]);
            }
        }        
    }
    
    /** Popupmenu action for choosing looks 
     */
    static class SetLookAction extends NodeAction {
        /** name of property of last selected object */
        public static final String PROP_LAST = "last";
        
        /** reference to the last LookNode */
        private Reference last;
        
        public java.lang.String getName() {
            return bundle.getString( "ACT_SetLook" ); //NOI18N
        }

        public org.openide.util.HelpCtx getHelpCtx() {
            return org.openide.util.HelpCtx.DEFAULT_HELP;
        }

        /* Returns a submneu that will present this action in a PopupMenu.
        * @return the JMenuItem representation for this action
        */
        public JMenuItem getPopupPresenter() {            
            JMenu mainItem = new MenuView.Menu (Ch.globalNode ());
            Actions.connect (mainItem, this, true);
//            HelpCtx.setHelpIDString (mainItem, SetLookAction.class.getName ());
            return mainItem;
        }

        /** Presentation in menu */
        public JMenuItem getMenuPresenter () {
            JMenu mainItem = new MenuView.Menu (Ch.globalNode ());
            Actions.connect (mainItem, this, false);
            
            return mainItem;
        }
        
        /** Presentation in toolbar */
        public Component getToolbarPresenter () {
            isEnabled ();
            
            ExplorerPanel ep = new ExplorerPanel ();
            ep.add (new ChoiceView ());
            ep.getExplorerManager().setRootContext (Ch.globalNode ());
            
            return ep;
        }
        
        /** Getter for the last selected item.
         */
        public LookNode getLast () {
            Reference l = last;
            if (l != null) {
                return (LookNode)l.get ();
            } else {
                return null;
            }
        }
        
        protected boolean enable(org.openide.nodes.Node[] node) {
            if (node.length != 1) return false;
            
            LookNode n = (LookNode)node[0].getCookie (LookNode.class);
            
            if (n != getLast ()) {
                // update the last reference
                if (n == null) {
                    last = null;
                } else {
                    last = new WeakReference (n);
                }
                
                firePropertyChange (PROP_LAST, null, null);
            }
            
            return n != null;
        }
        
        protected void performAction(org.openide.nodes.Node[] node) {
            // called when a node presenting look is selected
            for (int i = 0; i < node.length; i++) {
                Object l = node[i].getValue ("look"); // NOI18N
                Object n = node[i].getValue ("node"); // NOI18N
                if (l instanceof Look && n instanceof LookNode) {
                    ((LookNode)n).setLook ((Look)l);
                }
            }
        }
    }        

    /** Children that for a look display nodes for all its sublooks.
     */
    private static final class Ch extends Children.Keys 
    implements PropertyChangeListener {
        /** global node */
        private static Reference globalNode;
        
        private LookNode node;
        private Look look;
        private boolean active;
        
        public Ch (LookNode node, Look l) {
            this.node = node;
            this.look = l;
        }
        

        
        protected void addNotify () {
            active = true;
            
            update ();
        }
        
        protected void removeNotify () {
            setKeys (Collections.EMPTY_LIST);
            
            active = false;
        }

        protected Collection initCollection() {
            return Collections.singleton (create (node, look, false));
        }
                
        
        protected Node[] createNodes(Object key) {
            Look l = (Look)key;
            return new Node[] { create (node, l, true) };
        }
        
        public void propertyChange(java.beans.PropertyChangeEvent ev) {
            if (SetLookAction.PROP_LAST == ev.getPropertyName()) {
                update ();
            }
        }
        
        /** Updates the state acording to current selected node.
         */
        public void update () {
            LookNode n = null;
            Look l = null;
            SetLookAction set = (SetLookAction)SystemAction.get (SetLookAction.class); 
            if (node != null && node.equals (set.getLast())) {      
                n = node;
                l = look;
            }
            else {
                n = set.getLast ();
                l = n == null ? null : n.getBaseLook ();
                node = n;
                look = l;
            }

            if (active) {
                // refresh
                if (l != null && n != null) {
                    setKeys (Collections.EMPTY_LIST);
                    setKeys (l.availableLooks (n.getSubstitute ()));
                } else {
                    setKeys (Collections.EMPTY_LIST);
                }
            }
        }
        
        /** Creates node that represents global state of the system.
         */
        public static synchronized Node globalNode () {
            if (globalNode != null) {
                Node n = (Node)globalNode.get ();
                
                if (n != null) {
                    ((Ch)n.getChildren ()).update ();
                    return n;
                }
            }
            
            Ch ch = new Ch (null, null);
            
            // attach listener to last selected node
            SystemAction action = SystemAction.get (SetLookAction.class);
            action.addPropertyChangeListener(
                WeakListener.propertyChange (ch, action)
            );
            
            Node n = new AbstractNode (ch);
            globalNode = new SoftReference (n);
            return n;
        }
        
        /** Creates new node for a look presentation.
         */
        private static Node create (LookNode subst, Look l, boolean submenu) {
            
            AbstractNode n;
            Look[] arr = l.availableLooks (subst.getSubstitute());
            if (submenu && arr != null && arr.length != 0) {
                n = new AbstractNode (new Ch (subst, l));
            } else {
                n = new AbstractNode (Children.LEAF);
            }
            
            n.setName (l.getName ());
            n.setDisplayName (l.getDisplayName ());
            n.setDefaultAction (SystemAction.get (SetLookAction.class));
            n.setValue("look", l); // NOI18N
            n.setValue("node", subst); // NOI18N
            return n;
        }
    }
}

